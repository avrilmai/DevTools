using System.Collections.Generic;
using UnityEngine;

public class AdventureDbfAsset : ScriptableObject
{
	public List<AdventureDbfRecord> Records = new List<AdventureDbfRecord>();
}
