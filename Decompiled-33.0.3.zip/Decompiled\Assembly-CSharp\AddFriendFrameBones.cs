using System;
using UnityEngine;

[Serializable]
public class AddFriendFrameBones
{
	public Transform m_InputTopLeft;

	public Transform m_InputBottomRight;
}
