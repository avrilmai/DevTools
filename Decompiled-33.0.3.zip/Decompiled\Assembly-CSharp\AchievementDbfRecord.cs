using System;
using System.Collections.Generic;
using Assets;
using Blizzard.T5.Jobs;
using UnityEngine;

[Serializable]
public class AchievementDbfRecord : DbfRecord
{
	[SerializeField]
	private int m_achievementSectionId;

	[SerializeField]
	private int m_sortOrder;

	[SerializeField]
	private bool m_enabled = true;

	[SerializeField]
	private DbfLocValue m_name;

	[SerializeField]
	private DbfLocValue m_description;

	[SerializeField]
	private Assets.Achievement.AchievementVisibility m_achievementVisibility;

	[SerializeField]
	private int m_quota = 1;

	[SerializeField]
	private bool m_allowExceedQuota;

	[SerializeField]
	private int m_triggerId;

	[SerializeField]
	private int m_points;

	[SerializeField]
	private int m_rewardTrackXp;

	[SerializeField]
	private Assets.Achievement.RewardTrackType m_rewardTrackType;

	[SerializeField]
	private int m_rewardListId;

	[SerializeField]
	private int m_nextTierId;

	[SerializeField]
	private bool m_socialToast;

	[DbfField("ACHIEVEMENT_SECTION")]
	public int AchievementSection => m_achievementSectionId;

	public AchievementSectionDbfRecord AchievementSectionRecord => GameDbf.AchievementSection.GetRecord(m_achievementSectionId);

	[DbfField("SORT_ORDER")]
	public int SortOrder => m_sortOrder;

	[DbfField("ENABLED")]
	public bool Enabled => m_enabled;

	[DbfField("NAME")]
	public DbfLocValue Name => m_name;

	[DbfField("DESCRIPTION")]
	public DbfLocValue Description => m_description;

	[DbfField("ACHIEVEMENT_VISIBILITY")]
	public Assets.Achievement.AchievementVisibility AchievementVisibility => m_achievementVisibility;

	[DbfField("QUOTA")]
	public int Quota => m_quota;

	[DbfField("ALLOW_EXCEED_QUOTA")]
	public bool AllowExceedQuota => m_allowExceedQuota;

	[DbfField("POINTS")]
	public int Points => m_points;

	[DbfField("REWARD_TRACK_XP")]
	public int RewardTrackXp => m_rewardTrackXp;

	[DbfField("REWARD_TRACK_TYPE")]
	public Assets.Achievement.RewardTrackType RewardTrackType => m_rewardTrackType;

	[DbfField("REWARD_LIST")]
	public int RewardList => m_rewardListId;

	public RewardListDbfRecord RewardListRecord => GameDbf.RewardList.GetRecord(m_rewardListId);

	[DbfField("NEXT_TIER")]
	public int NextTier => m_nextTierId;

	[DbfField("SOCIAL_TOAST")]
	public bool SocialToast => m_socialToast;

	public override object GetVar(string name)
	{
		switch (name)
		{
		case "ID":
			return base.ID;
		case "ACHIEVEMENT_SECTION":
			return m_achievementSectionId;
		case "SORT_ORDER":
			return m_sortOrder;
		case "ENABLED":
			return m_enabled;
		case "NAME":
			return m_name;
		case "DESCRIPTION":
			return m_description;
		case "ACHIEVEMENT_VISIBILITY":
			return m_achievementVisibility;
		case "QUOTA":
			return m_quota;
		case "ALLOW_EXCEED_QUOTA":
			return m_allowExceedQuota;
		case "TRIGGER":
			return m_triggerId;
		case "POINTS":
			return m_points;
		case "REWARD_TRACK_XP":
			return m_rewardTrackXp;
		case "REWARD_TRACK_TYPE":
			return m_rewardTrackType;
		case "REWARD_LIST":
			return m_rewardListId;
		case "NEXT_TIER":
			return m_nextTierId;
		case "SOCIAL_TOAST":
			return m_socialToast;
		default:
			return null;
		}
	}

	public override void SetVar(string name, object val)
	{
		switch (name)
		{
		case "ID":
			SetID((int)val);
			break;
		case "ACHIEVEMENT_SECTION":
			m_achievementSectionId = (int)val;
			break;
		case "SORT_ORDER":
			m_sortOrder = (int)val;
			break;
		case "ENABLED":
			m_enabled = (bool)val;
			break;
		case "NAME":
			m_name = (DbfLocValue)val;
			break;
		case "DESCRIPTION":
			m_description = (DbfLocValue)val;
			break;
		case "ACHIEVEMENT_VISIBILITY":
			if (val == null)
			{
				m_achievementVisibility = Assets.Achievement.AchievementVisibility.VISIBLE;
			}
			else if (val is Assets.Achievement.AchievementVisibility || val is int)
			{
				m_achievementVisibility = (Assets.Achievement.AchievementVisibility)val;
			}
			else if (val is string)
			{
				m_achievementVisibility = Assets.Achievement.ParseAchievementVisibilityValue((string)val);
			}
			break;
		case "QUOTA":
			m_quota = (int)val;
			break;
		case "ALLOW_EXCEED_QUOTA":
			m_allowExceedQuota = (bool)val;
			break;
		case "TRIGGER":
			m_triggerId = (int)val;
			break;
		case "POINTS":
			m_points = (int)val;
			break;
		case "REWARD_TRACK_XP":
			m_rewardTrackXp = (int)val;
			break;
		case "REWARD_TRACK_TYPE":
			if (val == null)
			{
				m_rewardTrackType = Assets.Achievement.RewardTrackType.NONE;
			}
			else if (val is Assets.Achievement.RewardTrackType || val is int)
			{
				m_rewardTrackType = (Assets.Achievement.RewardTrackType)val;
			}
			else if (val is string)
			{
				m_rewardTrackType = Assets.Achievement.ParseRewardTrackTypeValue((string)val);
			}
			break;
		case "REWARD_LIST":
			m_rewardListId = (int)val;
			break;
		case "NEXT_TIER":
			m_nextTierId = (int)val;
			break;
		case "SOCIAL_TOAST":
			m_socialToast = (bool)val;
			break;
		}
	}

	public override Type GetVarType(string name)
	{
		switch (name)
		{
		case "ID":
			return typeof(int);
		case "ACHIEVEMENT_SECTION":
			return typeof(int);
		case "SORT_ORDER":
			return typeof(int);
		case "ENABLED":
			return typeof(bool);
		case "NAME":
			return typeof(DbfLocValue);
		case "DESCRIPTION":
			return typeof(DbfLocValue);
		case "ACHIEVEMENT_VISIBILITY":
			return typeof(Assets.Achievement.AchievementVisibility);
		case "QUOTA":
			return typeof(int);
		case "ALLOW_EXCEED_QUOTA":
			return typeof(bool);
		case "TRIGGER":
			return typeof(int);
		case "POINTS":
			return typeof(int);
		case "REWARD_TRACK_XP":
			return typeof(int);
		case "REWARD_TRACK_TYPE":
			return typeof(Assets.Achievement.RewardTrackType);
		case "REWARD_LIST":
			return typeof(int);
		case "NEXT_TIER":
			return typeof(int);
		case "SOCIAL_TOAST":
			return typeof(bool);
		default:
			return null;
		}
	}

	public override IEnumerator<IAsyncJobResult> Job_LoadRecordsFromAssetAsync<T>(string resourcePath, Action<List<T>> resultHandler)
	{
		LoadAchievementDbfRecords loadRecords = new LoadAchievementDbfRecords(resourcePath);
		yield return loadRecords;
		resultHandler?.Invoke(loadRecords.GetRecords() as List<T>);
	}

	public override bool LoadRecordsFromAsset<T>(string resourcePath, out List<T> records)
	{
		AchievementDbfAsset achievementDbfAsset = DbfShared.GetAssetBundle().LoadAsset(resourcePath, typeof(AchievementDbfAsset)) as AchievementDbfAsset;
		if (achievementDbfAsset == null)
		{
			records = new List<T>();
			Debug.LogError($"AchievementDbfAsset.LoadRecordsFromAsset() - failed to load records from assetbundle: {resourcePath}");
			return false;
		}
		for (int i = 0; i < achievementDbfAsset.Records.Count; i++)
		{
			achievementDbfAsset.Records[i].StripUnusedLocales();
		}
		records = achievementDbfAsset.Records as List<T>;
		return true;
	}

	public override bool SaveRecordsToAsset<T>(string assetPath, List<T> records, Locale locale)
	{
		return false;
	}

	public override void StripUnusedLocales()
	{
		m_name.StripUnusedLocales();
		m_description.StripUnusedLocales();
	}
}
