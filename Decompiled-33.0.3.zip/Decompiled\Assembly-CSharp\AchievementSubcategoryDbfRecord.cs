using System;
using System.Collections.Generic;
using Blizzard.T5.Jobs;
using UnityEngine;

[Serializable]
public class AchievementSubcategoryDbfRecord : DbfRecord
{
	[SerializeField]
	private int m_achievementCategoryId;

	[SerializeField]
	private DbfLocValue m_name;

	[SerializeField]
	private string m_icon;

	[SerializeField]
	private int m_sortOrder;

	[DbfField("ACHIEVEMENT_CATEGORY_ID")]
	public int AchievementCategoryId => m_achievementCategoryId;

	[DbfField("NAME")]
	public DbfLocValue Name => m_name;

	[DbfField("ICON")]
	public string Icon => m_icon;

	[DbfField("SORT_ORDER")]
	public int SortOrder => m_sortOrder;

	public List<AchievementSectionItemDbfRecord> Sections
	{
		get
		{
			int iD = base.ID;
			List<AchievementSectionItemDbfRecord> list = new List<AchievementSectionItemDbfRecord>();
			List<AchievementSectionItemDbfRecord> records = GameDbf.AchievementSectionItem.GetRecords();
			int i = 0;
			for (int count = records.Count; i < count; i++)
			{
				AchievementSectionItemDbfRecord achievementSectionItemDbfRecord = records[i];
				if (achievementSectionItemDbfRecord.AchievementSubcategoryId == iD)
				{
					list.Add(achievementSectionItemDbfRecord);
				}
			}
			return list;
		}
	}

	public override object GetVar(string name)
	{
		switch (name)
		{
		case "ID":
			return base.ID;
		case "ACHIEVEMENT_CATEGORY_ID":
			return m_achievementCategoryId;
		case "NAME":
			return m_name;
		case "ICON":
			return m_icon;
		case "SORT_ORDER":
			return m_sortOrder;
		default:
			return null;
		}
	}

	public override void SetVar(string name, object val)
	{
		switch (name)
		{
		case "ID":
			SetID((int)val);
			break;
		case "ACHIEVEMENT_CATEGORY_ID":
			m_achievementCategoryId = (int)val;
			break;
		case "NAME":
			m_name = (DbfLocValue)val;
			break;
		case "ICON":
			m_icon = (string)val;
			break;
		case "SORT_ORDER":
			m_sortOrder = (int)val;
			break;
		}
	}

	public override Type GetVarType(string name)
	{
		switch (name)
		{
		case "ID":
			return typeof(int);
		case "ACHIEVEMENT_CATEGORY_ID":
			return typeof(int);
		case "NAME":
			return typeof(DbfLocValue);
		case "ICON":
			return typeof(string);
		case "SORT_ORDER":
			return typeof(int);
		default:
			return null;
		}
	}

	public override IEnumerator<IAsyncJobResult> Job_LoadRecordsFromAssetAsync<T>(string resourcePath, Action<List<T>> resultHandler)
	{
		LoadAchievementSubcategoryDbfRecords loadRecords = new LoadAchievementSubcategoryDbfRecords(resourcePath);
		yield return loadRecords;
		resultHandler?.Invoke(loadRecords.GetRecords() as List<T>);
	}

	public override bool LoadRecordsFromAsset<T>(string resourcePath, out List<T> records)
	{
		AchievementSubcategoryDbfAsset achievementSubcategoryDbfAsset = DbfShared.GetAssetBundle().LoadAsset(resourcePath, typeof(AchievementSubcategoryDbfAsset)) as AchievementSubcategoryDbfAsset;
		if (achievementSubcategoryDbfAsset == null)
		{
			records = new List<T>();
			Debug.LogError($"AchievementSubcategoryDbfAsset.LoadRecordsFromAsset() - failed to load records from assetbundle: {resourcePath}");
			return false;
		}
		for (int i = 0; i < achievementSubcategoryDbfAsset.Records.Count; i++)
		{
			achievementSubcategoryDbfAsset.Records[i].StripUnusedLocales();
		}
		records = achievementSubcategoryDbfAsset.Records as List<T>;
		return true;
	}

	public override bool SaveRecordsToAsset<T>(string assetPath, List<T> records, Locale locale)
	{
		return false;
	}

	public override void StripUnusedLocales()
	{
		m_name.StripUnusedLocales();
	}
}
