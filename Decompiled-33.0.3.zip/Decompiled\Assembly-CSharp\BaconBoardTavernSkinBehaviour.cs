using UnityEngine;

[ExecuteAlways]
public class BaconBoardTavernSkinBehaviour : BaconBoardSkinBehaviour
{
}
