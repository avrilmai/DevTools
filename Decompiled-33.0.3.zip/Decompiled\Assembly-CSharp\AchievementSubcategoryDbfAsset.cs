using System.Collections.Generic;
using UnityEngine;

public class AchievementSubcategoryDbfAsset : ScriptableObject
{
	public List<AchievementSubcategoryDbfRecord> Records = new List<AchievementSubcategoryDbfRecord>();
}
