using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class ActorStateAnimObject
{
	public bool m_Enabled = true;

	public GameObject m_GameObject;

	public AnimationClip m_AnimClip;

	public int m_AnimLayer;

	public float m_CrossFadeSec;

	public bool m_EmitParticles;

	public string m_Comment;

	private bool m_prevParticleEmitValue;

	public void Init()
	{
		if (!(m_GameObject == null) && !(m_AnimClip == null))
		{
			string name = m_AnimClip.name;
			if (!m_GameObject.TryGetComponent<Animation>(out var component))
			{
				component = m_GameObject.AddComponent<Animation>();
			}
			component.playAutomatically = false;
			if (component[name] == null)
			{
				component.AddClip(m_AnimClip, name);
			}
			component[name].layer = m_AnimLayer;
		}
	}

	public void Play()
	{
		if (!m_Enabled || m_GameObject == null || !(m_AnimClip != null))
		{
			return;
		}
		string name = m_AnimClip.name;
		Animation component = m_GameObject.GetComponent<Animation>();
		component[name].enabled = true;
		if (Mathf.Approximately(m_CrossFadeSec, 0f))
		{
			if (!component.Play(name))
			{
				Debug.LogWarning($"ActorStateAnimObject.PlayNow() - FAILED to play clip {name} on {m_GameObject}");
			}
		}
		else
		{
			component.CrossFade(name, m_CrossFadeSec);
		}
	}

	public void Stop()
	{
		if (m_Enabled && !(m_GameObject == null) && m_AnimClip != null)
		{
			Animation component = m_GameObject.GetComponent<Animation>();
			component[m_AnimClip.name].time = 0f;
			component.Sample();
			component[m_AnimClip.name].enabled = false;
		}
	}

	public void Stop(List<ActorState> nextStateList)
	{
		if (!m_Enabled || m_GameObject == null || !(m_AnimClip != null))
		{
			return;
		}
		bool flag = false;
		int num = 0;
		while (!flag && num < nextStateList.Count)
		{
			ActorState actorState = nextStateList[num];
			for (int i = 0; i < actorState.m_ExternalAnimatedObjects.Count; i++)
			{
				ActorStateAnimObject actorStateAnimObject = actorState.m_ExternalAnimatedObjects[i];
				if (m_GameObject == actorStateAnimObject.m_GameObject && m_AnimLayer == actorStateAnimObject.m_AnimLayer)
				{
					flag = true;
					break;
				}
			}
			num++;
		}
		if (!flag)
		{
			m_GameObject.GetComponent<Animation>().Stop(m_AnimClip.name);
		}
	}
}
