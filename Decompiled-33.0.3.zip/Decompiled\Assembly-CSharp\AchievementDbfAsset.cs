using System.Collections.Generic;
using UnityEngine;

public class AchievementDbfAsset : ScriptableObject
{
	public List<AchievementDbfRecord> Records = new List<AchievementDbfRecord>();
}
