public enum BoardDdId
{
	STW = 1,
	ORG,
	MOP,
	STR,
	NAX,
	GVG,
	BRM
}
