using System.Collections.Generic;
using UnityEngine;

public class AdventureLoadoutTreasuresDbfAsset : ScriptableObject
{
	public List<AdventureLoadoutTreasuresDbfRecord> Records = new List<AdventureLoadoutTreasuresDbfRecord>();
}
