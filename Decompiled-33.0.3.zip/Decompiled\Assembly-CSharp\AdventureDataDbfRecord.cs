using System;
using System.Collections.Generic;
using Assets;
using Blizzard.T5.Jobs;
using UnityEngine;

[Serializable]
public class AdventureDataDbfRecord : DbfRecord
{
	[SerializeField]
	private string m_noteDesc;

	[SerializeField]
	private int m_adventureId;

	[SerializeField]
	private int m_modeId;

	[SerializeField]
	private int m_sortOrder;

	[SerializeField]
	private DbfLocValue m_name;

	[SerializeField]
	private DbfLocValue m_shortName;

	[SerializeField]
	private DbfLocValue m_description;

	[SerializeField]
	private DbfLocValue m_shortDescription;

	[SerializeField]
	private DbfLocValue m_lockedShortName;

	[SerializeField]
	private DbfLocValue m_lockedDescription;

	[SerializeField]
	private DbfLocValue m_lockedShortDescription;

	[SerializeField]
	private DbfLocValue m_requirementsDescription;

	[SerializeField]
	private DbfLocValue m_rewardsDescription;

	[SerializeField]
	private DbfLocValue m_completeBannerText;

	[SerializeField]
	private bool m_showPlayableScenariosCount = true;

	[SerializeField]
	private AdventureData.Adventuresubscene m_startingSubscene;

	[SerializeField]
	private string m_subsceneTransitionDirection = "INVALID";

	[SerializeField]
	private string m_adventureSubDefPrefab;

	[SerializeField]
	private int m_gameSaveDataServerKeyId;

	[SerializeField]
	private int m_gameSaveDataClientKeyId;

	[SerializeField]
	private bool m_dungeonCrawlSaveHeroUsingHeroDbId = true;

	[SerializeField]
	private string m_dungeonCrawlBossCardPrefab;

	[SerializeField]
	private bool m_dungeonCrawlPickHeroFirst;

	[SerializeField]
	private bool m_dungeonCrawlSkipHeroSelect;

	[SerializeField]
	private bool m_dungeonCrawlMustPickShrine;

	[SerializeField]
	private bool m_dungeonCrawlSelectChapter;

	[SerializeField]
	private bool m_dungeonCrawlDisplayHeroWinsPerChapter = true;

	[SerializeField]
	private bool m_dungeonCrawlIsRetireSupported;

	[SerializeField]
	private bool m_dungeonCrawlShowBossKillCount = true;

	[SerializeField]
	private bool m_dungeonCrawlDefaultToDeckFromUpcomingScenario;

	[SerializeField]
	private bool m_ignoreHeroUnlockRequirement;

	[SerializeField]
	private int m_bossCardBackId;

	[SerializeField]
	private string m_hasSeenFeaturedModeOption;

	[SerializeField]
	private string m_hasSeenNewModePopupOption;

	[SerializeField]
	private string m_prefabShownOnComplete;

	[SerializeField]
	private int m_anomalyModeDefaultCardId;

	[SerializeField]
	private AdventureData.Adventurebooklocation m_adventureBookMapPageLocation = AdventureData.ParseAdventurebooklocationValue("Beginning");

	[SerializeField]
	private AdventureData.Adventurebooklocation m_adventureBookRewardPageLocation = AdventureData.ParseAdventurebooklocationValue("End");

	[DbfField("ADVENTURE_ID")]
	public int AdventureId => m_adventureId;

	[DbfField("MODE_ID")]
	public int ModeId => m_modeId;

	[DbfField("SORT_ORDER")]
	public int SortOrder => m_sortOrder;

	[DbfField("NAME")]
	public DbfLocValue Name => m_name;

	[DbfField("SHORT_NAME")]
	public DbfLocValue ShortName => m_shortName;

	[DbfField("DESCRIPTION")]
	public DbfLocValue Description => m_description;

	[DbfField("SHORT_DESCRIPTION")]
	public DbfLocValue ShortDescription => m_shortDescription;

	[DbfField("LOCKED_SHORT_NAME")]
	public DbfLocValue LockedShortName => m_lockedShortName;

	[DbfField("LOCKED_DESCRIPTION")]
	public DbfLocValue LockedDescription => m_lockedDescription;

	[DbfField("LOCKED_SHORT_DESCRIPTION")]
	public DbfLocValue LockedShortDescription => m_lockedShortDescription;

	[DbfField("REQUIREMENTS_DESCRIPTION")]
	public DbfLocValue RequirementsDescription => m_requirementsDescription;

	[DbfField("REWARDS_DESCRIPTION")]
	public DbfLocValue RewardsDescription => m_rewardsDescription;

	[DbfField("COMPLETE_BANNER_TEXT")]
	public DbfLocValue CompleteBannerText => m_completeBannerText;

	[DbfField("SHOW_PLAYABLE_SCENARIOS_COUNT")]
	public bool ShowPlayableScenariosCount => m_showPlayableScenariosCount;

	[DbfField("STARTING_SUBSCENE")]
	public AdventureData.Adventuresubscene StartingSubscene => m_startingSubscene;

	[DbfField("SUBSCENE_TRANSITION_DIRECTION")]
	public string SubsceneTransitionDirection => m_subsceneTransitionDirection;

	[DbfField("ADVENTURE_SUB_DEF_PREFAB")]
	public string AdventureSubDefPrefab => m_adventureSubDefPrefab;

	[DbfField("GAME_SAVE_DATA_SERVER_KEY")]
	public int GameSaveDataServerKey => m_gameSaveDataServerKeyId;

	[DbfField("GAME_SAVE_DATA_CLIENT_KEY")]
	public int GameSaveDataClientKey => m_gameSaveDataClientKeyId;

	[DbfField("DUNGEON_CRAWL_SAVE_HERO_USING_HERO_DB_ID")]
	public bool DungeonCrawlSaveHeroUsingHeroDbId => m_dungeonCrawlSaveHeroUsingHeroDbId;

	[DbfField("DUNGEON_CRAWL_BOSS_CARD_PREFAB")]
	public string DungeonCrawlBossCardPrefab => m_dungeonCrawlBossCardPrefab;

	[DbfField("DUNGEON_CRAWL_PICK_HERO_FIRST")]
	public bool DungeonCrawlPickHeroFirst => m_dungeonCrawlPickHeroFirst;

	[DbfField("DUNGEON_CRAWL_SKIP_HERO_SELECT")]
	public bool DungeonCrawlSkipHeroSelect => m_dungeonCrawlSkipHeroSelect;

	[DbfField("DUNGEON_CRAWL_MUST_PICK_SHRINE")]
	public bool DungeonCrawlMustPickShrine => m_dungeonCrawlMustPickShrine;

	[DbfField("DUNGEON_CRAWL_SELECT_CHAPTER")]
	public bool DungeonCrawlSelectChapter => m_dungeonCrawlSelectChapter;

	[DbfField("DUNGEON_CRAWL_DISPLAY_HERO_WINS_PER_CHAPTER")]
	public bool DungeonCrawlDisplayHeroWinsPerChapter => m_dungeonCrawlDisplayHeroWinsPerChapter;

	[DbfField("DUNGEON_CRAWL_IS_RETIRE_SUPPORTED")]
	public bool DungeonCrawlIsRetireSupported => m_dungeonCrawlIsRetireSupported;

	[DbfField("DUNGEON_CRAWL_SHOW_BOSS_KILL_COUNT")]
	public bool DungeonCrawlShowBossKillCount => m_dungeonCrawlShowBossKillCount;

	[DbfField("DUNGEON_CRAWL_DEFAULT_TO_DECK_FROM_UPCOMING_SCENARIO")]
	public bool DungeonCrawlDefaultToDeckFromUpcomingScenario => m_dungeonCrawlDefaultToDeckFromUpcomingScenario;

	[DbfField("IGNORE_HERO_UNLOCK_REQUIREMENT")]
	public bool IgnoreHeroUnlockRequirement => m_ignoreHeroUnlockRequirement;

	[DbfField("BOSS_CARD_BACK")]
	public int BossCardBack => m_bossCardBackId;

	[DbfField("HAS_SEEN_FEATURED_MODE_OPTION")]
	public string HasSeenFeaturedModeOption => m_hasSeenFeaturedModeOption;

	[DbfField("HAS_SEEN_NEW_MODE_POPUP_OPTION")]
	public string HasSeenNewModePopupOption => m_hasSeenNewModePopupOption;

	[DbfField("PREFAB_SHOWN_ON_COMPLETE")]
	public string PrefabShownOnComplete => m_prefabShownOnComplete;

	[DbfField("ANOMALY_MODE_DEFAULT_CARD_ID")]
	public int AnomalyModeDefaultCardId => m_anomalyModeDefaultCardId;

	[DbfField("ADVENTURE_BOOK_MAP_PAGE_LOCATION")]
	public AdventureData.Adventurebooklocation AdventureBookMapPageLocation => m_adventureBookMapPageLocation;

	[DbfField("ADVENTURE_BOOK_REWARD_PAGE_LOCATION")]
	public AdventureData.Adventurebooklocation AdventureBookRewardPageLocation => m_adventureBookRewardPageLocation;

	public override object GetVar(string name)
	{
		switch (name)
		{
		case "ID":
			return base.ID;
		case "NOTE_DESC":
			return m_noteDesc;
		case "ADVENTURE_ID":
			return m_adventureId;
		case "MODE_ID":
			return m_modeId;
		case "SORT_ORDER":
			return m_sortOrder;
		case "NAME":
			return m_name;
		case "SHORT_NAME":
			return m_shortName;
		case "DESCRIPTION":
			return m_description;
		case "SHORT_DESCRIPTION":
			return m_shortDescription;
		case "LOCKED_SHORT_NAME":
			return m_lockedShortName;
		case "LOCKED_DESCRIPTION":
			return m_lockedDescription;
		case "LOCKED_SHORT_DESCRIPTION":
			return m_lockedShortDescription;
		case "REQUIREMENTS_DESCRIPTION":
			return m_requirementsDescription;
		case "REWARDS_DESCRIPTION":
			return m_rewardsDescription;
		case "COMPLETE_BANNER_TEXT":
			return m_completeBannerText;
		case "SHOW_PLAYABLE_SCENARIOS_COUNT":
			return m_showPlayableScenariosCount;
		case "STARTING_SUBSCENE":
			return m_startingSubscene;
		case "SUBSCENE_TRANSITION_DIRECTION":
			return m_subsceneTransitionDirection;
		case "ADVENTURE_SUB_DEF_PREFAB":
			return m_adventureSubDefPrefab;
		case "GAME_SAVE_DATA_SERVER_KEY":
			return m_gameSaveDataServerKeyId;
		case "GAME_SAVE_DATA_CLIENT_KEY":
			return m_gameSaveDataClientKeyId;
		case "DUNGEON_CRAWL_SAVE_HERO_USING_HERO_DB_ID":
			return m_dungeonCrawlSaveHeroUsingHeroDbId;
		case "DUNGEON_CRAWL_BOSS_CARD_PREFAB":
			return m_dungeonCrawlBossCardPrefab;
		case "DUNGEON_CRAWL_PICK_HERO_FIRST":
			return m_dungeonCrawlPickHeroFirst;
		case "DUNGEON_CRAWL_SKIP_HERO_SELECT":
			return m_dungeonCrawlSkipHeroSelect;
		case "DUNGEON_CRAWL_MUST_PICK_SHRINE":
			return m_dungeonCrawlMustPickShrine;
		case "DUNGEON_CRAWL_SELECT_CHAPTER":
			return m_dungeonCrawlSelectChapter;
		case "DUNGEON_CRAWL_DISPLAY_HERO_WINS_PER_CHAPTER":
			return m_dungeonCrawlDisplayHeroWinsPerChapter;
		case "DUNGEON_CRAWL_IS_RETIRE_SUPPORTED":
			return m_dungeonCrawlIsRetireSupported;
		case "DUNGEON_CRAWL_SHOW_BOSS_KILL_COUNT":
			return m_dungeonCrawlShowBossKillCount;
		case "DUNGEON_CRAWL_DEFAULT_TO_DECK_FROM_UPCOMING_SCENARIO":
			return m_dungeonCrawlDefaultToDeckFromUpcomingScenario;
		case "IGNORE_HERO_UNLOCK_REQUIREMENT":
			return m_ignoreHeroUnlockRequirement;
		case "BOSS_CARD_BACK":
			return m_bossCardBackId;
		case "HAS_SEEN_FEATURED_MODE_OPTION":
			return m_hasSeenFeaturedModeOption;
		case "HAS_SEEN_NEW_MODE_POPUP_OPTION":
			return m_hasSeenNewModePopupOption;
		case "PREFAB_SHOWN_ON_COMPLETE":
			return m_prefabShownOnComplete;
		case "ANOMALY_MODE_DEFAULT_CARD_ID":
			return m_anomalyModeDefaultCardId;
		case "ADVENTURE_BOOK_MAP_PAGE_LOCATION":
			return m_adventureBookMapPageLocation;
		case "ADVENTURE_BOOK_REWARD_PAGE_LOCATION":
			return m_adventureBookRewardPageLocation;
		default:
			return null;
		}
	}

	public override void SetVar(string name, object val)
	{
		switch (name)
		{
		case "ID":
			SetID((int)val);
			break;
		case "NOTE_DESC":
			m_noteDesc = (string)val;
			break;
		case "ADVENTURE_ID":
			m_adventureId = (int)val;
			break;
		case "MODE_ID":
			m_modeId = (int)val;
			break;
		case "SORT_ORDER":
			m_sortOrder = (int)val;
			break;
		case "NAME":
			m_name = (DbfLocValue)val;
			break;
		case "SHORT_NAME":
			m_shortName = (DbfLocValue)val;
			break;
		case "DESCRIPTION":
			m_description = (DbfLocValue)val;
			break;
		case "SHORT_DESCRIPTION":
			m_shortDescription = (DbfLocValue)val;
			break;
		case "LOCKED_SHORT_NAME":
			m_lockedShortName = (DbfLocValue)val;
			break;
		case "LOCKED_DESCRIPTION":
			m_lockedDescription = (DbfLocValue)val;
			break;
		case "LOCKED_SHORT_DESCRIPTION":
			m_lockedShortDescription = (DbfLocValue)val;
			break;
		case "REQUIREMENTS_DESCRIPTION":
			m_requirementsDescription = (DbfLocValue)val;
			break;
		case "REWARDS_DESCRIPTION":
			m_rewardsDescription = (DbfLocValue)val;
			break;
		case "COMPLETE_BANNER_TEXT":
			m_completeBannerText = (DbfLocValue)val;
			break;
		case "SHOW_PLAYABLE_SCENARIOS_COUNT":
			m_showPlayableScenariosCount = (bool)val;
			break;
		case "STARTING_SUBSCENE":
			if (val == null)
			{
				m_startingSubscene = AdventureData.Adventuresubscene.CHOOSER;
			}
			else if (val is AdventureData.Adventuresubscene || val is int)
			{
				m_startingSubscene = (AdventureData.Adventuresubscene)val;
			}
			else if (val is string)
			{
				m_startingSubscene = AdventureData.ParseAdventuresubsceneValue((string)val);
			}
			break;
		case "SUBSCENE_TRANSITION_DIRECTION":
			m_subsceneTransitionDirection = (string)val;
			break;
		case "ADVENTURE_SUB_DEF_PREFAB":
			m_adventureSubDefPrefab = (string)val;
			break;
		case "GAME_SAVE_DATA_SERVER_KEY":
			m_gameSaveDataServerKeyId = (int)val;
			break;
		case "GAME_SAVE_DATA_CLIENT_KEY":
			m_gameSaveDataClientKeyId = (int)val;
			break;
		case "DUNGEON_CRAWL_SAVE_HERO_USING_HERO_DB_ID":
			m_dungeonCrawlSaveHeroUsingHeroDbId = (bool)val;
			break;
		case "DUNGEON_CRAWL_BOSS_CARD_PREFAB":
			m_dungeonCrawlBossCardPrefab = (string)val;
			break;
		case "DUNGEON_CRAWL_PICK_HERO_FIRST":
			m_dungeonCrawlPickHeroFirst = (bool)val;
			break;
		case "DUNGEON_CRAWL_SKIP_HERO_SELECT":
			m_dungeonCrawlSkipHeroSelect = (bool)val;
			break;
		case "DUNGEON_CRAWL_MUST_PICK_SHRINE":
			m_dungeonCrawlMustPickShrine = (bool)val;
			break;
		case "DUNGEON_CRAWL_SELECT_CHAPTER":
			m_dungeonCrawlSelectChapter = (bool)val;
			break;
		case "DUNGEON_CRAWL_DISPLAY_HERO_WINS_PER_CHAPTER":
			m_dungeonCrawlDisplayHeroWinsPerChapter = (bool)val;
			break;
		case "DUNGEON_CRAWL_IS_RETIRE_SUPPORTED":
			m_dungeonCrawlIsRetireSupported = (bool)val;
			break;
		case "DUNGEON_CRAWL_SHOW_BOSS_KILL_COUNT":
			m_dungeonCrawlShowBossKillCount = (bool)val;
			break;
		case "DUNGEON_CRAWL_DEFAULT_TO_DECK_FROM_UPCOMING_SCENARIO":
			m_dungeonCrawlDefaultToDeckFromUpcomingScenario = (bool)val;
			break;
		case "IGNORE_HERO_UNLOCK_REQUIREMENT":
			m_ignoreHeroUnlockRequirement = (bool)val;
			break;
		case "BOSS_CARD_BACK":
			m_bossCardBackId = (int)val;
			break;
		case "HAS_SEEN_FEATURED_MODE_OPTION":
			m_hasSeenFeaturedModeOption = (string)val;
			break;
		case "HAS_SEEN_NEW_MODE_POPUP_OPTION":
			m_hasSeenNewModePopupOption = (string)val;
			break;
		case "PREFAB_SHOWN_ON_COMPLETE":
			m_prefabShownOnComplete = (string)val;
			break;
		case "ANOMALY_MODE_DEFAULT_CARD_ID":
			m_anomalyModeDefaultCardId = (int)val;
			break;
		case "ADVENTURE_BOOK_MAP_PAGE_LOCATION":
			if (val == null)
			{
				m_adventureBookMapPageLocation = AdventureData.Adventurebooklocation.BEGINNING;
			}
			else if (val is AdventureData.Adventurebooklocation || val is int)
			{
				m_adventureBookMapPageLocation = (AdventureData.Adventurebooklocation)val;
			}
			else if (val is string)
			{
				m_adventureBookMapPageLocation = AdventureData.ParseAdventurebooklocationValue((string)val);
			}
			break;
		case "ADVENTURE_BOOK_REWARD_PAGE_LOCATION":
			if (val == null)
			{
				m_adventureBookRewardPageLocation = AdventureData.Adventurebooklocation.BEGINNING;
			}
			else if (val is AdventureData.Adventurebooklocation || val is int)
			{
				m_adventureBookRewardPageLocation = (AdventureData.Adventurebooklocation)val;
			}
			else if (val is string)
			{
				m_adventureBookRewardPageLocation = AdventureData.ParseAdventurebooklocationValue((string)val);
			}
			break;
		}
	}

	public override Type GetVarType(string name)
	{
		switch (name)
		{
		case "ID":
			return typeof(int);
		case "NOTE_DESC":
			return typeof(string);
		case "ADVENTURE_ID":
			return typeof(int);
		case "MODE_ID":
			return typeof(int);
		case "SORT_ORDER":
			return typeof(int);
		case "NAME":
			return typeof(DbfLocValue);
		case "SHORT_NAME":
			return typeof(DbfLocValue);
		case "DESCRIPTION":
			return typeof(DbfLocValue);
		case "SHORT_DESCRIPTION":
			return typeof(DbfLocValue);
		case "LOCKED_SHORT_NAME":
			return typeof(DbfLocValue);
		case "LOCKED_DESCRIPTION":
			return typeof(DbfLocValue);
		case "LOCKED_SHORT_DESCRIPTION":
			return typeof(DbfLocValue);
		case "REQUIREMENTS_DESCRIPTION":
			return typeof(DbfLocValue);
		case "REWARDS_DESCRIPTION":
			return typeof(DbfLocValue);
		case "COMPLETE_BANNER_TEXT":
			return typeof(DbfLocValue);
		case "SHOW_PLAYABLE_SCENARIOS_COUNT":
			return typeof(bool);
		case "STARTING_SUBSCENE":
			return typeof(AdventureData.Adventuresubscene);
		case "SUBSCENE_TRANSITION_DIRECTION":
			return typeof(string);
		case "ADVENTURE_SUB_DEF_PREFAB":
			return typeof(string);
		case "GAME_SAVE_DATA_SERVER_KEY":
			return typeof(int);
		case "GAME_SAVE_DATA_CLIENT_KEY":
			return typeof(int);
		case "DUNGEON_CRAWL_SAVE_HERO_USING_HERO_DB_ID":
			return typeof(bool);
		case "DUNGEON_CRAWL_BOSS_CARD_PREFAB":
			return typeof(string);
		case "DUNGEON_CRAWL_PICK_HERO_FIRST":
			return typeof(bool);
		case "DUNGEON_CRAWL_SKIP_HERO_SELECT":
			return typeof(bool);
		case "DUNGEON_CRAWL_MUST_PICK_SHRINE":
			return typeof(bool);
		case "DUNGEON_CRAWL_SELECT_CHAPTER":
			return typeof(bool);
		case "DUNGEON_CRAWL_DISPLAY_HERO_WINS_PER_CHAPTER":
			return typeof(bool);
		case "DUNGEON_CRAWL_IS_RETIRE_SUPPORTED":
			return typeof(bool);
		case "DUNGEON_CRAWL_SHOW_BOSS_KILL_COUNT":
			return typeof(bool);
		case "DUNGEON_CRAWL_DEFAULT_TO_DECK_FROM_UPCOMING_SCENARIO":
			return typeof(bool);
		case "IGNORE_HERO_UNLOCK_REQUIREMENT":
			return typeof(bool);
		case "BOSS_CARD_BACK":
			return typeof(int);
		case "HAS_SEEN_FEATURED_MODE_OPTION":
			return typeof(string);
		case "HAS_SEEN_NEW_MODE_POPUP_OPTION":
			return typeof(string);
		case "PREFAB_SHOWN_ON_COMPLETE":
			return typeof(string);
		case "ANOMALY_MODE_DEFAULT_CARD_ID":
			return typeof(int);
		case "ADVENTURE_BOOK_MAP_PAGE_LOCATION":
			return typeof(AdventureData.Adventurebooklocation);
		case "ADVENTURE_BOOK_REWARD_PAGE_LOCATION":
			return typeof(AdventureData.Adventurebooklocation);
		default:
			return null;
		}
	}

	public override IEnumerator<IAsyncJobResult> Job_LoadRecordsFromAssetAsync<T>(string resourcePath, Action<List<T>> resultHandler)
	{
		LoadAdventureDataDbfRecords loadRecords = new LoadAdventureDataDbfRecords(resourcePath);
		yield return loadRecords;
		resultHandler?.Invoke(loadRecords.GetRecords() as List<T>);
	}

	public override bool LoadRecordsFromAsset<T>(string resourcePath, out List<T> records)
	{
		AdventureDataDbfAsset adventureDataDbfAsset = DbfShared.GetAssetBundle().LoadAsset(resourcePath, typeof(AdventureDataDbfAsset)) as AdventureDataDbfAsset;
		if (adventureDataDbfAsset == null)
		{
			records = new List<T>();
			Debug.LogError($"AdventureDataDbfAsset.LoadRecordsFromAsset() - failed to load records from assetbundle: {resourcePath}");
			return false;
		}
		for (int i = 0; i < adventureDataDbfAsset.Records.Count; i++)
		{
			adventureDataDbfAsset.Records[i].StripUnusedLocales();
		}
		records = adventureDataDbfAsset.Records as List<T>;
		return true;
	}

	public override bool SaveRecordsToAsset<T>(string assetPath, List<T> records, Locale locale)
	{
		return false;
	}

	public override void StripUnusedLocales()
	{
		m_name.StripUnusedLocales();
		m_shortName.StripUnusedLocales();
		m_description.StripUnusedLocales();
		m_shortDescription.StripUnusedLocales();
		m_lockedShortName.StripUnusedLocales();
		m_lockedDescription.StripUnusedLocales();
		m_lockedShortDescription.StripUnusedLocales();
		m_requirementsDescription.StripUnusedLocales();
		m_rewardsDescription.StripUnusedLocales();
		m_completeBannerText.StripUnusedLocales();
	}
}
