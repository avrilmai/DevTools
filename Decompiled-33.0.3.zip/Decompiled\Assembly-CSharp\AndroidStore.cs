using System.ComponentModel;

public enum AndroidStore
{
	[Description("None")]
	NONE,
	[Description("Blizzard")]
	BLIZZARD,
	[Description("Google")]
	GOOGLE,
	[Description("Amazon")]
	AMAZON,
	[Description("Huawei")]
	HUAWEI,
	[Description("OneStore")]
	ONE_STORE
}
