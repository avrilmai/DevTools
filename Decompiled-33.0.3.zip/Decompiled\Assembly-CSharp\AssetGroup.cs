using System.Collections.Generic;
using UnityEngine;

public class AssetGroup : ScriptableObject
{
	public List<string> assetGuids;
}
