using System.Collections.Generic;
using UnityEngine;

public class AdventureHeroPowerDbfAsset : ScriptableObject
{
	public List<AdventureHeroPowerDbfRecord> Records = new List<AdventureHeroPowerDbfRecord>();
}
