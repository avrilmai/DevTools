public class ArenaCheatResource : CheatResource
{
	public int? Win;

	public int? Loss;
}
