using System.Collections.Generic;
using UnityEngine;

public class AdventureMissionDbfAsset : ScriptableObject
{
	public List<AdventureMissionDbfRecord> Records = new List<AdventureMissionDbfRecord>();
}
