using System.Collections.Generic;
using UnityEngine;

public class AchievementSectionDbfAsset : ScriptableObject
{
	public List<AchievementSectionDbfRecord> Records = new List<AchievementSectionDbfRecord>();
}
