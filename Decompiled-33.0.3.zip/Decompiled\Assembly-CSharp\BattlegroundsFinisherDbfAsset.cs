using System.Collections.Generic;
using UnityEngine;

public class BattlegroundsFinisherDbfAsset : ScriptableObject
{
	public List<BattlegroundsFinisherDbfRecord> Records = new List<BattlegroundsFinisherDbfRecord>();
}
