using UnityEngine;

public class BaconCollectionSkin : CollectibleSkin
{
	protected bool m_showingFavorited;

	public GameObject m_nameWrapper;

	public GameObject m_phoneUINameWrapper;

	public GameObject m_favoriteStateTextWrapper;

	public UberText m_favoriteStateUberText;

	public GameObject m_favoriteNameBackground;

	public GameObject m_nonFavoriteNameBackground;

	protected virtual string GetFavoritedText()
	{
		return GameStrings.Get("GLUE_BACON_COLLECTION_FAVORITE");
	}

	public override void ShowFavoriteBanner(bool show)
	{
		m_showingFavorited = show;
		PopulateNameText();
	}

	protected override void PopulateNameText()
	{
		if (null != m_favoriteNameBackground)
		{
			m_favoriteNameBackground.SetActive(m_showingFavorited && base.ShowName);
		}
		if (null != m_nonFavoriteNameBackground)
		{
			m_nonFavoriteNameBackground.SetActive(!m_showingFavorited && base.ShowName);
		}
		if (m_showingFavorited)
		{
			GetActiveNameWrapper().SetActive(value: false);
			m_favoriteStateTextWrapper.SetActive(value: true);
			m_favoriteStateUberText.Text = GetFavoritedText();
		}
		else
		{
			GetActiveNameWrapper().SetActive(value: true);
			m_favoriteStateTextWrapper.SetActive(value: false);
			base.PopulateNameText();
		}
	}

	protected GameObject GetActiveNameWrapper()
	{
		if (!UniversalInputManager.UsePhoneUI)
		{
			return m_nameWrapper;
		}
		return m_phoneUINameWrapper;
	}
}
