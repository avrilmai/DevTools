using UnityEngine;

public static class AssetLoaderDebug
{
	public static Rect LayoutUI(Rect space)
	{
		return space;
	}

	public static string HandleCheat(string func, string[] args, string rawArgs)
	{
		return string.Empty;
	}
}
