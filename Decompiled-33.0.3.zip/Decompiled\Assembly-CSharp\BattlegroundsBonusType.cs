public enum BattlegroundsBonusType
{
	UNDEFINED,
	DISCOVER_HERO,
	EARLY_ACCESS_HEROES
}
