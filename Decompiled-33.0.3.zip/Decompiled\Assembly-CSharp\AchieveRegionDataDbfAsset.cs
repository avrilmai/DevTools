using System.Collections.Generic;
using UnityEngine;

public class AchieveRegionDataDbfAsset : ScriptableObject
{
	public List<AchieveRegionDataDbfRecord> Records = new List<AchieveRegionDataDbfRecord>();
}
