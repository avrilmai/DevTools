[CustomEditClass]
public static class BaconHeroSkinUtils
{
	public enum RotationType
	{
		Active,
		Resting,
		Preview
	}

	public static bool CanFavoriteBattlegroundsHeroSkin(EntityDef entityDef)
	{
		if (!CollectionManager.Get().IsBattlegroundsHeroCard(entityDef.GetCardId()))
		{
			return false;
		}
		int num = GameUtils.TranslateCardIdToDbId(entityDef.GetCardId());
		if (CollectionManager.Get().IsBattlegroundsBaseHeroCardWithSkin(num))
		{
			if (CollectionManager.Get().GetFavoriteBattlegroundsHeroSkin(num, out var _))
			{
				return true;
			}
			return false;
		}
		if (CollectionManager.Get().IsBattlegroundsHeroSkinCard(num))
		{
			if (!CollectionManager.Get().OwnsBattlegroundsHeroSkin(entityDef.GetCardId()))
			{
				return false;
			}
			if (!CollectionManager.Get().GetBattlegroundsHeroSkinIdForSkinCardId(num, out var skinId))
			{
				return false;
			}
			if (!CollectionManager.Get().GetBattlegroundsBaseCardIdForHeroSkinId(skinId, out var baseHeroCardId))
			{
				return false;
			}
			if (CollectionManager.Get().GetFavoriteBattlegroundsHeroSkin(baseHeroCardId, out var favoriteSkinId2))
			{
				return skinId != favoriteSkinId2;
			}
			return true;
		}
		return false;
	}

	public static bool IsBattlegroundsHeroSkinFavorited(EntityDef entityDef)
	{
		if (!CollectionManager.Get().IsBattlegroundsHeroCard(entityDef.GetCardId()))
		{
			return false;
		}
		int num = GameUtils.TranslateCardIdToDbId(entityDef.GetCardId());
		if (CollectionManager.Get().IsBattlegroundsBaseHeroCardWithSkin(num))
		{
			if (!CollectionManager.Get().GetFavoriteBattlegroundsHeroSkin(num, out var _))
			{
				return CollectionManager.Get().OwnsAssociatedBattlegroundsHeroSkin(num);
			}
			return false;
		}
		if (CollectionManager.Get().IsBattlegroundsHeroSkinCard(num))
		{
			if (!CollectionManager.Get().GetBattlegroundsHeroSkinIdForSkinCardId(num, out var skinId))
			{
				return false;
			}
			if (!CollectionManager.Get().GetBattlegroundsBaseCardIdForHeroSkinId(skinId, out var baseHeroCardId))
			{
				return false;
			}
			if (CollectionManager.Get().GetFavoriteBattlegroundsHeroSkin(baseHeroCardId, out var favoriteSkinId2))
			{
				return skinId == favoriteSkinId2;
			}
			return false;
		}
		return false;
	}

	public static bool CanFavoriteBattlegroundsGuideSkin(EntityDef entityDef)
	{
		if (!CollectionManager.Get().IsBattlegroundsGuideCardId(entityDef.GetCardId()))
		{
			return false;
		}
		int skinCardId = GameUtils.TranslateCardIdToDbId(entityDef.GetCardId());
		if (CollectionManager.Get().GetBattlegroundsGuideSkinIdForCardId(skinCardId, out var skinId))
		{
			if (!CollectionManager.Get().OwnsBattlegroundsGuideSkin(skinCardId))
			{
				return false;
			}
			if (CollectionManager.Get().GetFavoriteBattlegroundsGuideSkin(out var favoriteSkinId))
			{
				return favoriteSkinId != skinId;
			}
			return true;
		}
		return CollectionManager.Get().HasFavoriteBattlegroundsGuideSkin();
	}

	public static bool IsBattlegroundsGuideSkinFavorited(EntityDef entityDef)
	{
		if (!CollectionManager.Get().IsBattlegroundsGuideCardId(entityDef.GetCardId()))
		{
			return false;
		}
		int skinCardId = GameUtils.TranslateCardIdToDbId(entityDef.GetCardId());
		if (CollectionManager.Get().GetBattlegroundsGuideSkinIdForCardId(skinCardId, out var skinId))
		{
			if (CollectionManager.Get().GetFavoriteBattlegroundsGuideSkin(out var favoriteSkinId))
			{
				return favoriteSkinId == skinId;
			}
			return false;
		}
		if (!CollectionManager.Get().HasFavoriteBattlegroundsGuideSkin())
		{
			return CollectionManager.Get().OwnsAnyBattlegroundsGuideSkin();
		}
		return false;
	}

	public static RotationType GetBattleGroundsHeroRotationType(CardDbfRecord cardRecord, EntityDef cardDef)
	{
		if (!cardDef.HasTag(GAME_TAG.BACON_HERO_CAN_BE_DRAFTED) || !SpecialEventManager.Get().IsEventActive(cardRecord.BattlegroundsActiveEvent, activeIfDoesNotExist: false))
		{
			return RotationType.Resting;
		}
		if (SpecialEventManager.Get().IsEventActive(cardRecord.BattlegroundsEarlyAccessEvent, activeIfDoesNotExist: false))
		{
			return RotationType.Preview;
		}
		return RotationType.Active;
	}
}
