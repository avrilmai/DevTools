using UnityEngine;

[ExecuteAlways]
public class BaconBoardCombatSkinBehaviour : BaconBoardSkinBehaviour
{
}
