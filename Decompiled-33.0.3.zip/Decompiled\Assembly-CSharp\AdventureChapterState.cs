public enum AdventureChapterState
{
	LOCKED,
	UNLOCKED,
	COMPLETED
}
