using System.Collections.Generic;
using UnityEngine;

public class AdventureGuestHeroesDbfAsset : ScriptableObject
{
	public List<AdventureGuestHeroesDbfRecord> Records = new List<AdventureGuestHeroesDbfRecord>();
}
