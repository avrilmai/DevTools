public enum AdventureBookPageType
{
	INVALID,
	MAP,
	CHAPTER,
	REWARD
}
