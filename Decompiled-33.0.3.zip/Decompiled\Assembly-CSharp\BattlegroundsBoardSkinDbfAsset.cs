using System.Collections.Generic;
using UnityEngine;

public class BattlegroundsBoardSkinDbfAsset : ScriptableObject
{
	public List<BattlegroundsBoardSkinDbfRecord> Records = new List<BattlegroundsBoardSkinDbfRecord>();
}
