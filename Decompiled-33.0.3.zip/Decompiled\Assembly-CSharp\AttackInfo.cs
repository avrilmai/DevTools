public class AttackInfo
{
	public Entity m_attacker;

	public Entity m_defender;

	public Entity m_proposedAttacker;

	public Entity m_proposedDefender;

	public bool m_repeatProposed;

	public int? m_attackerTagValue;

	public int? m_defenderTagValue;

	public int? m_proposedAttackerTagValue;

	public int? m_proposedDefenderTagValue;
}
