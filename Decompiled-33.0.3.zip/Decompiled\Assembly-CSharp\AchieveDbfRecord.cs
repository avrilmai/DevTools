using System;
using System.Collections.Generic;
using Assets;
using Blizzard.T5.Jobs;
using UnityEngine;

[Serializable]
public class AchieveDbfRecord : DbfRecord
{
	[SerializeField]
	private string m_noteDesc;

	[SerializeField]
	private Achieve.Type m_achType = Achieve.ParseTypeValue("invalid");

	[SerializeField]
	private bool m_enabled = true;

	[SerializeField]
	private string m_parentAch;

	[SerializeField]
	private string m_linkTo;

	[SerializeField]
	private int m_sharedAchieveId;

	[SerializeField]
	private Achieve.ClientFlags m_clientFlags;

	[SerializeField]
	private Achieve.Trigger m_triggered = Achieve.ParseTriggerValue("none");

	[SerializeField]
	private int m_achQuota;

	[SerializeField]
	private Achieve.GameMode m_gameMode = Achieve.ParseGameModeValue("any");

	[SerializeField]
	private int m_raceId;

	[SerializeField]
	private int m_cardSetId;

	[SerializeField]
	private int m_myHeroClassId;

	[SerializeField]
	private int m_enemyHeroClassId;

	[SerializeField]
	private int m_maxDefense;

	[SerializeField]
	private Achieve.PlayerType m_playerType = Achieve.ParsePlayerTypeValue("any");

	[SerializeField]
	private int m_leagueVersionMin;

	[SerializeField]
	private int m_leagueVersionMax;

	[SerializeField]
	private int m_scenarioId;

	[SerializeField]
	private int m_adventureId;

	[SerializeField]
	private int m_adventureModeId;

	[SerializeField]
	private int m_adventureWingId;

	[SerializeField]
	private int m_boosterId;

	[SerializeField]
	private Achieve.RewardTiming m_rewardTiming = Achieve.ParseRewardTimingValue("immediate");

	[SerializeField]
	private string m_reward = "none";

	[SerializeField]
	private long m_rewardData1;

	[SerializeField]
	private long m_rewardData2;

	[SerializeField]
	private Achieve.Unlocks m_unlocks = Achieve.ParseUnlocksValue("none");

	[SerializeField]
	private DbfLocValue m_name;

	[SerializeField]
	private DbfLocValue m_description;

	[SerializeField]
	private Achieve.AltTextPredicate m_altTextPredicate = Achieve.ParseAltTextPredicateValue("none");

	[SerializeField]
	private DbfLocValue m_altName;

	[SerializeField]
	private DbfLocValue m_altDescription;

	[SerializeField]
	private string m_customVisualWidget;

	[SerializeField]
	private bool m_useGenericRewardVisual;

	[SerializeField]
	private Achieve.ShowToReturningPlayer m_showToReturningPlayer = Achieve.ParseShowToReturningPlayerValue("always");

	[SerializeField]
	private int m_questDialogId;

	[SerializeField]
	private bool m_autoDestroy;

	[SerializeField]
	private string m_questTilePrefab;

	[SerializeField]
	private Achieve.AttentionBlocker m_attentionBlocker = Achieve.ParseAttentionBlockerValue("NONE");

	[SerializeField]
	private bool m_enabledWithProgression = true;

	[DbfField("NOTE_DESC")]
	public string NoteDesc => m_noteDesc;

	[DbfField("ACH_TYPE")]
	public Achieve.Type AchType => m_achType;

	[DbfField("ENABLED")]
	public bool Enabled => m_enabled;

	[DbfField("PARENT_ACH")]
	public string ParentAch => m_parentAch;

	[DbfField("LINK_TO")]
	public string LinkTo => m_linkTo;

	[DbfField("SHARED_ACHIEVE_ID")]
	public int SharedAchieveId => m_sharedAchieveId;

	[DbfField("CLIENT_FLAGS")]
	public Achieve.ClientFlags ClientFlags => m_clientFlags;

	[DbfField("TRIGGERED")]
	public Achieve.Trigger Triggered => m_triggered;

	[DbfField("ACH_QUOTA")]
	public int AchQuota => m_achQuota;

	[DbfField("GAME_MODE")]
	public Achieve.GameMode GameMode => m_gameMode;

	[DbfField("RACE")]
	public int Race => m_raceId;

	[DbfField("CARD_SET")]
	public int CardSet => m_cardSetId;

	[DbfField("MY_HERO_CLASS_ID")]
	public int MyHeroClassId => m_myHeroClassId;

	[DbfField("ENEMY_HERO_CLASS_ID")]
	public int EnemyHeroClassId => m_enemyHeroClassId;

	[DbfField("MAX_DEFENSE")]
	public int MaxDefense => m_maxDefense;

	[DbfField("PLAYER_TYPE")]
	public Achieve.PlayerType PlayerType => m_playerType;

	[DbfField("ADVENTURE_ID")]
	public int AdventureId => m_adventureId;

	[DbfField("ADVENTURE_MODE_ID")]
	public int AdventureModeId => m_adventureModeId;

	[DbfField("ADVENTURE_WING_ID")]
	public int AdventureWingId => m_adventureWingId;

	[DbfField("BOOSTER")]
	public int Booster => m_boosterId;

	[DbfField("REWARD_TIMING")]
	public Achieve.RewardTiming RewardTiming => m_rewardTiming;

	[DbfField("REWARD")]
	public string Reward => m_reward;

	[DbfField("REWARD_DATA1")]
	public long RewardData1 => m_rewardData1;

	[DbfField("REWARD_DATA2")]
	public long RewardData2 => m_rewardData2;

	[DbfField("UNLOCKS")]
	public Achieve.Unlocks Unlocks => m_unlocks;

	[DbfField("NAME")]
	public DbfLocValue Name => m_name;

	[DbfField("DESCRIPTION")]
	public DbfLocValue Description => m_description;

	[DbfField("ALT_TEXT_PREDICATE")]
	public Achieve.AltTextPredicate AltTextPredicate => m_altTextPredicate;

	[DbfField("ALT_NAME")]
	public DbfLocValue AltName => m_altName;

	[DbfField("ALT_DESCRIPTION")]
	public DbfLocValue AltDescription => m_altDescription;

	[DbfField("CUSTOM_VISUAL_WIDGET")]
	public string CustomVisualWidget => m_customVisualWidget;

	[DbfField("USE_GENERIC_REWARD_VISUAL")]
	public bool UseGenericRewardVisual => m_useGenericRewardVisual;

	[DbfField("SHOW_TO_RETURNING_PLAYER")]
	public Achieve.ShowToReturningPlayer ShowToReturningPlayer => m_showToReturningPlayer;

	[DbfField("QUEST_DIALOG_ID")]
	public int QuestDialogId => m_questDialogId;

	[DbfField("AUTO_DESTROY")]
	public bool AutoDestroy => m_autoDestroy;

	[DbfField("QUEST_TILE_PREFAB")]
	public string QuestTilePrefab => m_questTilePrefab;

	[DbfField("ATTENTION_BLOCKER")]
	public Achieve.AttentionBlocker AttentionBlocker => m_attentionBlocker;

	[DbfField("ENABLED_WITH_PROGRESSION")]
	public bool EnabledWithProgression => m_enabledWithProgression;

	public override object GetVar(string name)
	{
		switch (name)
		{
		case "ID":
			return base.ID;
		case "NOTE_DESC":
			return m_noteDesc;
		case "ACH_TYPE":
			return m_achType;
		case "ENABLED":
			return m_enabled;
		case "PARENT_ACH":
			return m_parentAch;
		case "LINK_TO":
			return m_linkTo;
		case "SHARED_ACHIEVE_ID":
			return m_sharedAchieveId;
		case "CLIENT_FLAGS":
			return m_clientFlags;
		case "TRIGGERED":
			return m_triggered;
		case "ACH_QUOTA":
			return m_achQuota;
		case "GAME_MODE":
			return m_gameMode;
		case "RACE":
			return m_raceId;
		case "CARD_SET":
			return m_cardSetId;
		case "MY_HERO_CLASS_ID":
			return m_myHeroClassId;
		case "ENEMY_HERO_CLASS_ID":
			return m_enemyHeroClassId;
		case "MAX_DEFENSE":
			return m_maxDefense;
		case "PLAYER_TYPE":
			return m_playerType;
		case "LEAGUE_VERSION_MIN":
			return m_leagueVersionMin;
		case "LEAGUE_VERSION_MAX":
			return m_leagueVersionMax;
		case "SCENARIO_ID":
			return m_scenarioId;
		case "ADVENTURE_ID":
			return m_adventureId;
		case "ADVENTURE_MODE_ID":
			return m_adventureModeId;
		case "ADVENTURE_WING_ID":
			return m_adventureWingId;
		case "BOOSTER":
			return m_boosterId;
		case "REWARD_TIMING":
			return m_rewardTiming;
		case "REWARD":
			return m_reward;
		case "REWARD_DATA1":
			return m_rewardData1;
		case "REWARD_DATA2":
			return m_rewardData2;
		case "UNLOCKS":
			return m_unlocks;
		case "NAME":
			return m_name;
		case "DESCRIPTION":
			return m_description;
		case "ALT_TEXT_PREDICATE":
			return m_altTextPredicate;
		case "ALT_NAME":
			return m_altName;
		case "ALT_DESCRIPTION":
			return m_altDescription;
		case "CUSTOM_VISUAL_WIDGET":
			return m_customVisualWidget;
		case "USE_GENERIC_REWARD_VISUAL":
			return m_useGenericRewardVisual;
		case "SHOW_TO_RETURNING_PLAYER":
			return m_showToReturningPlayer;
		case "QUEST_DIALOG_ID":
			return m_questDialogId;
		case "AUTO_DESTROY":
			return m_autoDestroy;
		case "QUEST_TILE_PREFAB":
			return m_questTilePrefab;
		case "ATTENTION_BLOCKER":
			return m_attentionBlocker;
		case "ENABLED_WITH_PROGRESSION":
			return m_enabledWithProgression;
		default:
			return null;
		}
	}

	public override void SetVar(string name, object val)
	{
		switch (name)
		{
		case "ID":
			SetID((int)val);
			break;
		case "NOTE_DESC":
			m_noteDesc = (string)val;
			break;
		case "ACH_TYPE":
			if (val == null)
			{
				m_achType = Achieve.Type.INVALID;
			}
			else if (val is Achieve.Type || val is int)
			{
				m_achType = (Achieve.Type)val;
			}
			else if (val is string)
			{
				m_achType = Achieve.ParseTypeValue((string)val);
			}
			break;
		case "ENABLED":
			m_enabled = (bool)val;
			break;
		case "PARENT_ACH":
			m_parentAch = (string)val;
			break;
		case "LINK_TO":
			m_linkTo = (string)val;
			break;
		case "SHARED_ACHIEVE_ID":
			m_sharedAchieveId = (int)val;
			break;
		case "CLIENT_FLAGS":
			if (val == null)
			{
				m_clientFlags = Achieve.ClientFlags.NONE;
			}
			else if (val is Achieve.ClientFlags || val is int)
			{
				m_clientFlags = (Achieve.ClientFlags)val;
			}
			else if (val is string)
			{
				m_clientFlags = Achieve.ParseClientFlagsValue((string)val);
			}
			break;
		case "TRIGGERED":
			if (val == null)
			{
				m_triggered = Achieve.Trigger.UNKNOWN;
			}
			else if (val is Achieve.Trigger || val is int)
			{
				m_triggered = (Achieve.Trigger)val;
			}
			else if (val is string)
			{
				m_triggered = Achieve.ParseTriggerValue((string)val);
			}
			break;
		case "ACH_QUOTA":
			m_achQuota = (int)val;
			break;
		case "GAME_MODE":
			if (val == null)
			{
				m_gameMode = Achieve.GameMode.ANY;
			}
			else if (val is Achieve.GameMode || val is int)
			{
				m_gameMode = (Achieve.GameMode)val;
			}
			else if (val is string)
			{
				m_gameMode = Achieve.ParseGameModeValue((string)val);
			}
			break;
		case "RACE":
			m_raceId = (int)val;
			break;
		case "CARD_SET":
			m_cardSetId = (int)val;
			break;
		case "MY_HERO_CLASS_ID":
			m_myHeroClassId = (int)val;
			break;
		case "ENEMY_HERO_CLASS_ID":
			m_enemyHeroClassId = (int)val;
			break;
		case "MAX_DEFENSE":
			m_maxDefense = (int)val;
			break;
		case "PLAYER_TYPE":
			if (val == null)
			{
				m_playerType = Achieve.PlayerType.ANY;
			}
			else if (val is Achieve.PlayerType || val is int)
			{
				m_playerType = (Achieve.PlayerType)val;
			}
			else if (val is string)
			{
				m_playerType = Achieve.ParsePlayerTypeValue((string)val);
			}
			break;
		case "LEAGUE_VERSION_MIN":
			m_leagueVersionMin = (int)val;
			break;
		case "LEAGUE_VERSION_MAX":
			m_leagueVersionMax = (int)val;
			break;
		case "SCENARIO_ID":
			m_scenarioId = (int)val;
			break;
		case "ADVENTURE_ID":
			m_adventureId = (int)val;
			break;
		case "ADVENTURE_MODE_ID":
			m_adventureModeId = (int)val;
			break;
		case "ADVENTURE_WING_ID":
			m_adventureWingId = (int)val;
			break;
		case "BOOSTER":
			m_boosterId = (int)val;
			break;
		case "REWARD_TIMING":
			if (val == null)
			{
				m_rewardTiming = Achieve.RewardTiming.IMMEDIATE;
			}
			else if (val is Achieve.RewardTiming || val is int)
			{
				m_rewardTiming = (Achieve.RewardTiming)val;
			}
			else if (val is string)
			{
				m_rewardTiming = Achieve.ParseRewardTimingValue((string)val);
			}
			break;
		case "REWARD":
			m_reward = (string)val;
			break;
		case "REWARD_DATA1":
			m_rewardData1 = (long)val;
			break;
		case "REWARD_DATA2":
			m_rewardData2 = (long)val;
			break;
		case "UNLOCKS":
			if (val == null)
			{
				m_unlocks = Achieve.Unlocks.FORGE;
			}
			else if (val is Achieve.Unlocks || val is int)
			{
				m_unlocks = (Achieve.Unlocks)val;
			}
			else if (val is string)
			{
				m_unlocks = Achieve.ParseUnlocksValue((string)val);
			}
			break;
		case "NAME":
			m_name = (DbfLocValue)val;
			break;
		case "DESCRIPTION":
			m_description = (DbfLocValue)val;
			break;
		case "ALT_TEXT_PREDICATE":
			if (val == null)
			{
				m_altTextPredicate = Achieve.AltTextPredicate.NONE;
			}
			else if (val is Achieve.AltTextPredicate || val is int)
			{
				m_altTextPredicate = (Achieve.AltTextPredicate)val;
			}
			else if (val is string)
			{
				m_altTextPredicate = Achieve.ParseAltTextPredicateValue((string)val);
			}
			break;
		case "ALT_NAME":
			m_altName = (DbfLocValue)val;
			break;
		case "ALT_DESCRIPTION":
			m_altDescription = (DbfLocValue)val;
			break;
		case "CUSTOM_VISUAL_WIDGET":
			m_customVisualWidget = (string)val;
			break;
		case "USE_GENERIC_REWARD_VISUAL":
			m_useGenericRewardVisual = (bool)val;
			break;
		case "SHOW_TO_RETURNING_PLAYER":
			if (val == null)
			{
				m_showToReturningPlayer = Achieve.ShowToReturningPlayer.ALWAYS;
			}
			else if (val is Achieve.ShowToReturningPlayer || val is int)
			{
				m_showToReturningPlayer = (Achieve.ShowToReturningPlayer)val;
			}
			else if (val is string)
			{
				m_showToReturningPlayer = Achieve.ParseShowToReturningPlayerValue((string)val);
			}
			break;
		case "QUEST_DIALOG_ID":
			m_questDialogId = (int)val;
			break;
		case "AUTO_DESTROY":
			m_autoDestroy = (bool)val;
			break;
		case "QUEST_TILE_PREFAB":
			m_questTilePrefab = (string)val;
			break;
		case "ATTENTION_BLOCKER":
			if (val == null)
			{
				m_attentionBlocker = Achieve.AttentionBlocker.NONE;
			}
			else if (val is Achieve.AttentionBlocker || val is int)
			{
				m_attentionBlocker = (Achieve.AttentionBlocker)val;
			}
			else if (val is string)
			{
				m_attentionBlocker = Achieve.ParseAttentionBlockerValue((string)val);
			}
			break;
		case "ENABLED_WITH_PROGRESSION":
			m_enabledWithProgression = (bool)val;
			break;
		}
	}

	public override Type GetVarType(string name)
	{
		switch (name)
		{
		case "ID":
			return typeof(int);
		case "NOTE_DESC":
			return typeof(string);
		case "ACH_TYPE":
			return typeof(Achieve.Type);
		case "ENABLED":
			return typeof(bool);
		case "PARENT_ACH":
			return typeof(string);
		case "LINK_TO":
			return typeof(string);
		case "SHARED_ACHIEVE_ID":
			return typeof(int);
		case "CLIENT_FLAGS":
			return typeof(Achieve.ClientFlags);
		case "TRIGGERED":
			return typeof(Achieve.Trigger);
		case "ACH_QUOTA":
			return typeof(int);
		case "GAME_MODE":
			return typeof(Achieve.GameMode);
		case "RACE":
			return typeof(int);
		case "CARD_SET":
			return typeof(int);
		case "MY_HERO_CLASS_ID":
			return typeof(int);
		case "ENEMY_HERO_CLASS_ID":
			return typeof(int);
		case "MAX_DEFENSE":
			return typeof(int);
		case "PLAYER_TYPE":
			return typeof(Achieve.PlayerType);
		case "LEAGUE_VERSION_MIN":
			return typeof(int);
		case "LEAGUE_VERSION_MAX":
			return typeof(int);
		case "SCENARIO_ID":
			return typeof(int);
		case "ADVENTURE_ID":
			return typeof(int);
		case "ADVENTURE_MODE_ID":
			return typeof(int);
		case "ADVENTURE_WING_ID":
			return typeof(int);
		case "BOOSTER":
			return typeof(int);
		case "REWARD_TIMING":
			return typeof(Achieve.RewardTiming);
		case "REWARD":
			return typeof(string);
		case "REWARD_DATA1":
			return typeof(long);
		case "REWARD_DATA2":
			return typeof(long);
		case "UNLOCKS":
			return typeof(Achieve.Unlocks);
		case "NAME":
			return typeof(DbfLocValue);
		case "DESCRIPTION":
			return typeof(DbfLocValue);
		case "ALT_TEXT_PREDICATE":
			return typeof(Achieve.AltTextPredicate);
		case "ALT_NAME":
			return typeof(DbfLocValue);
		case "ALT_DESCRIPTION":
			return typeof(DbfLocValue);
		case "CUSTOM_VISUAL_WIDGET":
			return typeof(string);
		case "USE_GENERIC_REWARD_VISUAL":
			return typeof(bool);
		case "SHOW_TO_RETURNING_PLAYER":
			return typeof(Achieve.ShowToReturningPlayer);
		case "QUEST_DIALOG_ID":
			return typeof(int);
		case "AUTO_DESTROY":
			return typeof(bool);
		case "QUEST_TILE_PREFAB":
			return typeof(string);
		case "ATTENTION_BLOCKER":
			return typeof(Achieve.AttentionBlocker);
		case "ENABLED_WITH_PROGRESSION":
			return typeof(bool);
		default:
			return null;
		}
	}

	public override IEnumerator<IAsyncJobResult> Job_LoadRecordsFromAssetAsync<T>(string resourcePath, Action<List<T>> resultHandler)
	{
		LoadAchieveDbfRecords loadRecords = new LoadAchieveDbfRecords(resourcePath);
		yield return loadRecords;
		resultHandler?.Invoke(loadRecords.GetRecords() as List<T>);
	}

	public override bool LoadRecordsFromAsset<T>(string resourcePath, out List<T> records)
	{
		AchieveDbfAsset achieveDbfAsset = DbfShared.GetAssetBundle().LoadAsset(resourcePath, typeof(AchieveDbfAsset)) as AchieveDbfAsset;
		if (achieveDbfAsset == null)
		{
			records = new List<T>();
			Debug.LogError($"AchieveDbfAsset.LoadRecordsFromAsset() - failed to load records from assetbundle: {resourcePath}");
			return false;
		}
		for (int i = 0; i < achieveDbfAsset.Records.Count; i++)
		{
			achieveDbfAsset.Records[i].StripUnusedLocales();
		}
		records = achieveDbfAsset.Records as List<T>;
		return true;
	}

	public override bool SaveRecordsToAsset<T>(string assetPath, List<T> records, Locale locale)
	{
		return false;
	}

	public override void StripUnusedLocales()
	{
		m_name.StripUnusedLocales();
		m_description.StripUnusedLocales();
		m_altName.StripUnusedLocales();
		m_altDescription.StripUnusedLocales();
	}
}
