using System.Collections.Generic;
using UnityEngine;

public class BattlegroundsEmoteDbfAsset : ScriptableObject
{
	public List<BattlegroundsEmoteDbfRecord> Records = new List<BattlegroundsEmoteDbfRecord>();
}
