using System.Collections;
using UnityEngine;

public class BaconCollectionHeroSkin : BaconCollectionSkin
{
	private BaconHeroSkinUtils.RotationType m_rotationType;

	private bool m_playerHasEarlyAccessHeroes;

	public GameObject m_heroPowerParent;

	private Actor m_heroPowerActor;

	public GameObject m_unownedStateTextWrapper;

	public UberText m_unownedStateUberText;

	public override void Awake()
	{
		base.Awake();
		if (base.gameObject.GetComponent<Actor>() != null)
		{
			AssetLoader.Get().InstantiatePrefab("Card_Bacon_Collection_HeroPower.prefab:cba9305dae5005f45814f741f72e532d", OnHeroPowerActorLoaded, null, AssetLoadingOptions.IgnorePrefabPosition);
		}
	}

	public void SetHeroPower(string heroPowerCardId)
	{
		DefLoader.Get().LoadFullDef(heroPowerCardId, OnHeroPowerFullDefLoaded);
	}

	private void OnHeroPowerActorLoaded(AssetReference assetRef, GameObject go, object callbackData)
	{
		if (go == null)
		{
			Debug.LogWarning($"CollectionDeckInfo.OnHeroPowerActorLoaded() - FAILED to load actor \"{assetRef}\"");
			return;
		}
		m_heroPowerActor = go.GetComponent<Actor>();
		if (m_heroPowerActor == null)
		{
			Debug.LogWarning($"BaconCollectionHeroSkin.OnHeroPowerActorLoaded() - ERROR actor \"{assetRef}\" has no Actor component");
			return;
		}
		m_heroPowerActor.SetUnlit();
		m_heroPowerActor.transform.parent = m_heroPowerParent.transform;
		m_heroPowerActor.transform.localScale = Vector3.one;
		m_heroPowerActor.transform.localPosition = Vector3.zero;
		if (UniversalInputManager.Get().IsTouchMode())
		{
			m_heroPowerActor.TurnOffCollider();
		}
	}

	private void OnHeroPowerFullDefLoaded(string cardID, DefLoader.DisposableFullDef def, object userData)
	{
		StartCoroutine(SetHeroPowerInfoWhenReady(cardID, def, TAG_PREMIUM.NORMAL));
	}

	private IEnumerator SetHeroPowerInfoWhenReady(string heroPowerCardID, DefLoader.DisposableFullDef def, TAG_PREMIUM premium)
	{
		using (def)
		{
			while (m_heroPowerActor == null)
			{
				yield return null;
			}
			SetHeroPowerInfo(heroPowerCardID, def, premium);
		}
	}

	public void AddHeroPowerGhosting(EntityDef def)
	{
		StartCoroutine(AddHeroPowerGhostingWhenReady(def));
	}

	private IEnumerator AddHeroPowerGhostingWhenReady(EntityDef def)
	{
		while (m_heroPowerActor == null)
		{
			yield return null;
		}
		Actor component = base.gameObject.GetComponent<Actor>();
		m_heroPowerActor.gameObject.GetComponent<BaconCollectionHeroPower>()?.HideItemsForGhostView();
		if (def.IsHeroSkin() && HeroSkinUtils.CanBuyHeroSkinFromCollectionManager(def.GetCardId()))
		{
			component.GhostCardEffect(GhostCard.Type.MISSING);
		}
		else
		{
			component.MissingCardEffect();
		}
	}

	private void SetHeroPowerInfo(string heroPowerCardID, DefLoader.DisposableFullDef def, TAG_PREMIUM premium)
	{
		m_heroPowerActor.Show();
		m_heroPowerActor.SetFullDef(def);
		m_heroPowerActor.SetUnlit();
		m_heroPowerActor.UpdateAllComponents();
		m_heroPowerActor.GetCostTextObject()?.SetActive(value: false);
		m_heroPowerActor.m_manaObject?.SetActive(value: false);
	}

	protected override void PopulateNameText()
	{
		if (m_rotationType == BaconHeroSkinUtils.RotationType.Resting)
		{
			GetActiveNameWrapper().SetActive(value: false);
			m_favoriteStateTextWrapper.SetActive(value: false);
			m_unownedStateTextWrapper.SetActive(value: true);
			m_unownedStateUberText.Text = GameStrings.Get("GLUE_BACON_COLLECTION_RESTING");
		}
		else if (!m_playerHasEarlyAccessHeroes && m_rotationType == BaconHeroSkinUtils.RotationType.Preview)
		{
			GetActiveNameWrapper().SetActive(value: false);
			m_favoriteStateTextWrapper.SetActive(value: false);
			m_unownedStateTextWrapper.SetActive(value: true);
			m_unownedStateUberText.Text = GameStrings.Get("GLUE_BACON_COLLECTION_PREVIEWING");
		}
		else
		{
			m_unownedStateTextWrapper.SetActive(value: false);
			base.PopulateNameText();
		}
	}

	public void SetCardStateDisplay(CollectibleCard card, EntityDef entityDef, bool playerHasEarlyAccessHeroes)
	{
		string battlegroundsBaseHeroCardId = CollectionManager.Get().GetBattlegroundsBaseHeroCardId(card.CardId);
		CardDbfRecord cardRecord = GameUtils.GetCardRecord(battlegroundsBaseHeroCardId);
		EntityDef entityDef2 = DefLoader.Get().GetEntityDef(battlegroundsBaseHeroCardId);
		m_rotationType = BaconHeroSkinUtils.GetBattleGroundsHeroRotationType(cardRecord, entityDef2);
		m_playerHasEarlyAccessHeroes = playerHasEarlyAccessHeroes;
		CollectionManager.Get().GetCollectibleDisplay();
		bool flag = m_rotationType == BaconHeroSkinUtils.RotationType.Resting;
		bool flag2 = !playerHasEarlyAccessHeroes && m_rotationType == BaconHeroSkinUtils.RotationType.Preview;
		if (card.OwnedCount == 0 || flag || flag2)
		{
			AddHeroPowerGhosting(entityDef);
		}
		PopulateNameText();
	}
}
