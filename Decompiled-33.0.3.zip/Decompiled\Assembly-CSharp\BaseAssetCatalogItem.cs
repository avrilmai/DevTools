using System;

[Serializable]
public class BaseAssetCatalogItem
{
	public string guid;

	public int bundleId = -1;
}
