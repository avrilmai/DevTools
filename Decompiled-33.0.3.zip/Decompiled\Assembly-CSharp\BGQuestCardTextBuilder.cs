public class BGQuestCardTextBuilder : CardTextBuilder
{
	public BGQuestCardTextBuilder()
	{
		m_useEntityForTextInPlay = true;
	}

	public static string GetRaceString(TAG_RACE race, int count)
	{
		if (count > 1)
		{
			return GameStrings.GetRaceNameBattlegrounds(race);
		}
		return GameStrings.GetRaceName(race);
	}

	public override string BuildCardTextInHand(Entity entity)
	{
		return BuildText(entity);
	}

	public override string BuildCardTextInHistory(Entity entity)
	{
		return BuildText(entity);
	}

	private static string BuildText(Entity entity)
	{
		string rawCardTextInHand = CardTextBuilder.GetRawCardTextInHand(entity.GetCardId());
		int tag = entity.GetTag(GAME_TAG.QUEST_PROGRESS_TOTAL);
		int tag2 = entity.GetTag(GAME_TAG.QUEST_REWARD_DATABASE_ID);
		string text = string.Empty;
		string text2 = string.Empty;
		string text3 = string.Empty;
		if (tag2 != 0)
		{
			CardDbfRecord record = GameDbf.Card.GetRecord(tag2);
			if (record != null)
			{
				text = record.Name;
			}
		}
		if (entity.GetTag(GAME_TAG.TAG_SCRIPT_DATA_NUM_1) != 0)
		{
			text2 = GetRaceString((TAG_RACE)entity.GetTag(GAME_TAG.TAG_SCRIPT_DATA_NUM_1), tag);
		}
		if (entity.GetTag(GAME_TAG.TAG_SCRIPT_DATA_NUM_2) != 0)
		{
			text3 = GetRaceString((TAG_RACE)entity.GetTag(GAME_TAG.TAG_SCRIPT_DATA_NUM_2), tag);
		}
		string text4 = string.Format(rawCardTextInHand, tag, text, text2, text3);
		int num = text4.IndexOf('@');
		if (num >= 0)
		{
			text4 = ((tag2 != 0) ? text4.Remove(num, 1) : text4.Substring(0, num));
		}
		return TextUtils.TransformCardText(entity, text4);
	}
}
