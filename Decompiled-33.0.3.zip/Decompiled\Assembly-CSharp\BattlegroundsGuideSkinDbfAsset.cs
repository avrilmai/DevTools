using System.Collections.Generic;
using UnityEngine;

public class BattlegroundsGuideSkinDbfAsset : ScriptableObject
{
	public List<BattlegroundsGuideSkinDbfRecord> Records = new List<BattlegroundsGuideSkinDbfRecord>();
}
