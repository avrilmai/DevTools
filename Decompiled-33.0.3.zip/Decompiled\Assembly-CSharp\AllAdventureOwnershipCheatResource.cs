public class AllAdventureOwnershipCheatResource : CheatResource
{
}
