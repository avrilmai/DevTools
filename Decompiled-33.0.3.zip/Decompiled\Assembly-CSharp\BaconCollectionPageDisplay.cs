using System.Collections;
using System.Collections.Generic;
using Hearthstone;
using Hearthstone.DataModels;
using Hearthstone.UI;
using PegasusShared;
using UnityEngine;

public class BaconCollectionPageDisplay : CollectiblePageDisplay
{
	public enum HEADER_CLASS
	{
		INVALID = -1,
		HEROSKINS,
		GUIDESKINS,
		BOARDSKINS,
		FINISHERS,
		EMOTES
	}

	public GameObject m_favoriteBanner;

	public GameObject m_heroSkinsDecor;

	public GameObject[] m_heroSkinFrames;

	public GameObject m_guideSkinsDecor;

	public GameObject[] m_guideSkinFrames;

	public GameObject m_noMatchFoundObject;

	public UberText m_noMatchExplanationText;

	public Widget m_BoardSkinsWidget;

	public AsyncReference m_boardDisplayReference;

	public Widget m_FinishersWidget;

	public AsyncReference m_finisherDisplayReference;

	public Widget m_EmotesWidget;

	public AsyncReference m_emoteDisplayReference;

	private Widget m_BoardSkinsWidgetInstance;

	private Widget m_FinishersWidgetInstance;

	private Widget m_EmotesWidgetInstance;

	public void Start()
	{
		m_boardDisplayReference.RegisterReadyListener<Widget>(OnBoardDisplayReady);
		m_finisherDisplayReference.RegisterReadyListener<Widget>(OnFinisherDisplayReady);
		m_emoteDisplayReference.RegisterReadyListener<Widget>(OnEmoteDisplayReady);
	}

	public override void UpdateCollectionItems(List<CollectionCardActors> actorList, List<ICollectible> nonActorCollectibles, CollectionUtils.ViewMode mode)
	{
		base.UpdateCollectionItems(actorList, nonActorCollectibles, mode);
		for (int i = 0; i < actorList.Count && i < CollectiblePageDisplay.GetMaxCardsPerPage(); i++)
		{
			CollectionCardVisual collectionCardVisual = GetCollectionCardVisual(i);
			if (mode == CollectionUtils.ViewMode.BATTLEGROUNDS_HERO_SKINS || mode == CollectionUtils.ViewMode.BATTLEGROUNDS_GUIDE_SKINS)
			{
				collectionCardVisual.SetHeroSkinBoxCollider();
			}
			else
			{
				collectionCardVisual.SetDefaultBoxCollider();
			}
		}
		List<CollectibleBattlegroundsBoard> list = new List<CollectibleBattlegroundsBoard>();
		foreach (ICollectible nonActorCollectible in nonActorCollectibles)
		{
			CollectibleBattlegroundsBoard collectibleBattlegroundsBoard = nonActorCollectible as CollectibleBattlegroundsBoard;
			if (collectibleBattlegroundsBoard != null)
			{
				list.Add(collectibleBattlegroundsBoard);
			}
		}
		List<CollectibleBattlegroundsFinisher> list2 = new List<CollectibleBattlegroundsFinisher>();
		foreach (ICollectible nonActorCollectible2 in nonActorCollectibles)
		{
			CollectibleBattlegroundsFinisher collectibleBattlegroundsFinisher = nonActorCollectible2 as CollectibleBattlegroundsFinisher;
			if (collectibleBattlegroundsFinisher != null)
			{
				list2.Add(collectibleBattlegroundsFinisher);
			}
		}
		List<CollectibleBattlegroundsEmote> list3 = new List<CollectibleBattlegroundsEmote>();
		foreach (ICollectible nonActorCollectible3 in nonActorCollectibles)
		{
			CollectibleBattlegroundsEmote collectibleBattlegroundsEmote = nonActorCollectible3 as CollectibleBattlegroundsEmote;
			if (collectibleBattlegroundsEmote != null)
			{
				list3.Add(collectibleBattlegroundsEmote);
			}
		}
		UpdateFavoriteHeroSkins(mode);
		UpdateFavoriteGuideSkins(mode);
		UpdateCollectionBoards(list, mode);
		UpdateCollectionFinishers(list2, mode);
		UpdateCollectionEmotes(list3, mode);
		UpdateHeroSkinNames(mode);
		UpdateGuideSkinNames(mode);
		UpdateHeroSkinHeroPowers(mode);
	}

	public void UpdateCollectionBoards(List<CollectibleBattlegroundsBoard> boardList, CollectionUtils.ViewMode mode, BookPageManager.PageTransitionType transitionType = BookPageManager.PageTransitionType.NONE)
	{
		bool flag = mode == CollectionUtils.ViewMode.BATTLEGROUNDS_BOARD_SKINS;
		m_BoardSkinsWidget.gameObject.SetActive(flag);
		if (!flag)
		{
			m_BoardSkinsWidget.UnbindDataModel(565);
			return;
		}
		BattlegroundsBoardSkinCollectionPageDataModel orCreateBoardCollectionPageDataModel = GetOrCreateBoardCollectionPageDataModel();
		if (orCreateBoardCollectionPageDataModel == null)
		{
			Log.All.PrintError("BaconCollectionPageDisplay.UpdateCollectionBoards - could not find data model!");
			return;
		}
		m_BoardSkinsWidget.BindDataModel(orCreateBoardCollectionPageDataModel);
		DataModelList<BattlegroundsBoardSkinDataModel> dataModelList = new DataModelList<BattlegroundsBoardSkinDataModel>();
		if (dataModelList != null)
		{
			foreach (CollectibleBattlegroundsBoard board in boardList)
			{
				BattlegroundsBoardSkinDataModel item = board.CreateBoardDataModel();
				dataModelList.Add(item);
			}
		}
		orCreateBoardCollectionPageDataModel.BoardSkinList = dataModelList;
	}

	public void UpdateCollectionFinishers(List<CollectibleBattlegroundsFinisher> finisherList, CollectionUtils.ViewMode mode, BookPageManager.PageTransitionType transitionType = BookPageManager.PageTransitionType.NONE)
	{
		bool flag = mode == CollectionUtils.ViewMode.BATTLEGROUNDS_FINISHERS;
		m_FinishersWidget.gameObject.SetActive(flag);
		if (!flag)
		{
			m_FinishersWidget.UnbindDataModel(568);
			return;
		}
		BattlegroundsFinisherCollectionPageDataModel orCreateFinisherCollectionPageDataModel = GetOrCreateFinisherCollectionPageDataModel();
		if (orCreateFinisherCollectionPageDataModel == null)
		{
			Log.All.PrintError("BaconCollectionPageDisplay.UpdateCollectionFinishers - could not find data model!");
			return;
		}
		m_FinishersWidget.BindDataModel(orCreateFinisherCollectionPageDataModel);
		DataModelList<BattlegroundsFinisherDataModel> dataModelList = new DataModelList<BattlegroundsFinisherDataModel>();
		if (dataModelList != null)
		{
			foreach (CollectibleBattlegroundsFinisher finisher in finisherList)
			{
				BattlegroundsFinisherDataModel item = finisher.CreateFinisherDataModel();
				dataModelList.Add(item);
			}
		}
		orCreateFinisherCollectionPageDataModel.FinisherList = dataModelList;
	}

	public void UpdateCollectionEmotes(List<CollectibleBattlegroundsEmote> emoteList, CollectionUtils.ViewMode mode, BookPageManager.PageTransitionType transitionType = BookPageManager.PageTransitionType.NONE)
	{
		bool flag = mode == CollectionUtils.ViewMode.BATTLEGROUNDS_EMOTES;
		m_EmotesWidget.gameObject.SetActive(flag);
		if (!flag)
		{
			m_EmotesWidget.UnbindDataModel(639);
			return;
		}
		BattlegroundsEmoteCollectionPageDataModel orCreateEmoteCollectionPageDataModel = GetOrCreateEmoteCollectionPageDataModel();
		if (orCreateEmoteCollectionPageDataModel == null)
		{
			Log.All.PrintError("BaconCollectionPageDisplay.UpdateCollectionEmotes - could not find data model!");
			return;
		}
		m_EmotesWidget.BindDataModel(orCreateEmoteCollectionPageDataModel);
		DataModelList<BattlegroundsEmoteDataModel> dataModelList = new DataModelList<BattlegroundsEmoteDataModel>();
		if (dataModelList != null)
		{
			foreach (CollectibleBattlegroundsEmote emote in emoteList)
			{
				BattlegroundsEmoteDataModel item = emote.CreateEmoteDataModel();
				dataModelList.Add(item);
			}
		}
		orCreateEmoteCollectionPageDataModel.EmoteList = dataModelList;
	}

	private BattlegroundsBoardSkinCollectionPageDataModel GetOrCreateBoardCollectionPageDataModel()
	{
		if (!m_BoardSkinsWidget.GetDataModel(565, out var model))
		{
			model = new BattlegroundsBoardSkinCollectionPageDataModel();
		}
		return model as BattlegroundsBoardSkinCollectionPageDataModel;
	}

	private BattlegroundsFinisherCollectionPageDataModel GetOrCreateFinisherCollectionPageDataModel()
	{
		if (!m_FinishersWidget.GetDataModel(568, out var model))
		{
			model = new BattlegroundsFinisherCollectionPageDataModel();
		}
		return model as BattlegroundsFinisherCollectionPageDataModel;
	}

	private BattlegroundsEmoteCollectionPageDataModel GetOrCreateEmoteCollectionPageDataModel()
	{
		if (!m_EmotesWidget.GetDataModel(639, out var model))
		{
			model = new BattlegroundsEmoteCollectionPageDataModel();
		}
		return model as BattlegroundsEmoteCollectionPageDataModel;
	}

	public override void UpdateCurrentPageCardLocks(bool playSound = false)
	{
		base.UpdateCurrentPageCardLocks(playSound);
		foreach (CollectionCardVisual collectionCardVisual in m_collectionCardVisuals)
		{
			collectionCardVisual.ShowLock(CollectionCardVisual.LockType.NONE);
		}
	}

	public void UpdateFavoriteHeroSkins(CollectionUtils.ViewMode mode)
	{
		bool flag = mode == CollectionUtils.ViewMode.BATTLEGROUNDS_HERO_SKINS;
		if (m_heroSkinsDecor != null)
		{
			m_heroSkinsDecor.SetActive(flag);
		}
		if (!flag)
		{
			return;
		}
		int num = 0;
		foreach (CollectionCardVisual collectionCardVisual in m_collectionCardVisuals)
		{
			if (collectionCardVisual.IsShown())
			{
				Actor actor = collectionCardVisual.GetActor();
				BaconCollectionHeroSkin component = actor.GetComponent<BaconCollectionHeroSkin>();
				if (component == null)
				{
					continue;
				}
				component.ShowShadow(actor.IsShown());
				EntityDef entityDef = actor.GetEntityDef();
				if (entityDef != null)
				{
					component.ShowFavoriteBanner(BaconHeroSkinUtils.IsBattlegroundsHeroSkinFavorited(entityDef));
				}
			}
			if (num < m_heroSkinFrames.Length)
			{
				m_heroSkinFrames[num++].SetActive(collectionCardVisual.IsShown());
			}
		}
	}

	public void UpdateFavoriteGuideSkins(CollectionUtils.ViewMode mode)
	{
		bool flag = mode == CollectionUtils.ViewMode.BATTLEGROUNDS_GUIDE_SKINS;
		if (m_guideSkinsDecor != null)
		{
			m_guideSkinsDecor.SetActive(flag);
		}
		if (!flag)
		{
			return;
		}
		int num = 0;
		foreach (CollectionCardVisual collectionCardVisual in m_collectionCardVisuals)
		{
			if (collectionCardVisual.IsShown())
			{
				Actor actor = collectionCardVisual.GetActor();
				BaconCollectionGuideSkin component = actor.GetComponent<BaconCollectionGuideSkin>();
				if (component == null)
				{
					continue;
				}
				component.ShowShadow(actor.IsShown());
				EntityDef entityDef = actor.GetEntityDef();
				if (entityDef != null)
				{
					component.ShowFavoriteBanner(BaconHeroSkinUtils.IsBattlegroundsGuideSkinFavorited(entityDef));
				}
			}
			if (num < m_guideSkinFrames.Length)
			{
				m_guideSkinFrames[num++].SetActive(collectionCardVisual.IsShown());
			}
		}
	}

	public void UpdateFavoriteBoardSkins(CollectionUtils.ViewMode mode)
	{
		if (mode != CollectionUtils.ViewMode.BATTLEGROUNDS_BOARD_SKINS)
		{
			return;
		}
		foreach (BattlegroundsBoardSkinDataModel boardSkin in m_BoardSkinsWidget.GetDataModel<BattlegroundsBoardSkinCollectionPageDataModel>().BoardSkinList)
		{
			boardSkin.IsFavorite = CollectionManager.Get().IsFavoriteBattlegroundsBoardSkin(BattlegroundsBoardSkinId.FromTrustedValue(boardSkin.BoardDbiId));
		}
	}

	public void UpdateFavoriteFinisherSkins(CollectionUtils.ViewMode mode)
	{
		if (mode != CollectionUtils.ViewMode.BATTLEGROUNDS_FINISHERS)
		{
			return;
		}
		foreach (BattlegroundsFinisherDataModel finisher in m_FinishersWidget.GetDataModel<BattlegroundsFinisherCollectionPageDataModel>().FinisherList)
		{
			finisher.IsFavorite = CollectionManager.Get().IsFavoriteBattlegroundsFinisher(BattlegroundsFinisherId.FromTrustedValue(finisher.FinisherDbiId));
		}
	}

	public void UpdateHeroSkinHeroPowers(CollectionUtils.ViewMode mode)
	{
		if (mode != CollectionUtils.ViewMode.BATTLEGROUNDS_HERO_SKINS)
		{
			return;
		}
		foreach (CollectionCardVisual collectionCardVisual in m_collectionCardVisuals)
		{
			if (!collectionCardVisual.IsShown())
			{
				continue;
			}
			Actor actor = collectionCardVisual.GetActor();
			BaconCollectionHeroSkin component = actor.GetComponent<BaconCollectionHeroSkin>();
			if (!(component == null))
			{
				EntityDef entityDef = actor.GetEntityDef();
				if (entityDef != null)
				{
					string heroPowerCardIdFromHero = GameUtils.GetHeroPowerCardIdFromHero(entityDef.GetCardId());
					component.SetHeroPower(heroPowerCardIdFromHero);
				}
			}
		}
	}

	public void UpdateHeroSkinNames(CollectionUtils.ViewMode mode)
	{
		if (mode == CollectionUtils.ViewMode.BATTLEGROUNDS_HERO_SKINS)
		{
			StartCoroutine(WaitThenUpdateHeroSkinNames(mode));
		}
	}

	private IEnumerator WaitThenUpdateHeroSkinNames(CollectionUtils.ViewMode mode)
	{
		yield return null;
		foreach (CollectionCardVisual collectionCardVisual in m_collectionCardVisuals)
		{
			if (collectionCardVisual.IsShown())
			{
				CollectionHeroSkin component = collectionCardVisual.GetActor().GetComponent<CollectionHeroSkin>();
				if (!(component == null))
				{
					component.ShowCollectionManagerText();
				}
			}
		}
	}

	public void UpdateGuideSkinNames(CollectionUtils.ViewMode mode)
	{
		if (mode == CollectionUtils.ViewMode.BATTLEGROUNDS_GUIDE_SKINS)
		{
			StartCoroutine(WaitThenUpdateGuideSkinNames(mode));
		}
	}

	public void SetEmoteEquippedState(BattlegroundsEmoteId emoteId, bool isEquipped)
	{
		foreach (BattlegroundsEmoteDataModel emote in GetOrCreateEmoteCollectionPageDataModel().EmoteList)
		{
			if (emote.EmoteDbiId.Equals(emoteId.ToValue()))
			{
				emote.IsEquipped = isEquipped;
			}
		}
	}

	private IEnumerator WaitThenUpdateGuideSkinNames(CollectionUtils.ViewMode mode)
	{
		yield return null;
		foreach (CollectionCardVisual collectionCardVisual in m_collectionCardVisuals)
		{
			if (collectionCardVisual.IsShown())
			{
				BaconCollectionGuideSkin component = collectionCardVisual.GetActor().GetComponent<BaconCollectionGuideSkin>();
				if (!(component == null))
				{
					component.ShowCollectionManagerText();
				}
			}
		}
	}

	public override void ShowNoMatchesFound(bool show, CollectionManager.FindCardsResult findResults = null, bool showHints = true)
	{
		m_noMatchFoundObject.SetActive(show);
		string key = "GLUE_COLLECTION_NO_RESULTS";
		m_noMatchExplanationText.Text = GameStrings.Get(key);
	}

	public override void SetPageType(FormatType inputFormatType)
	{
	}

	public void SetHeroSkins()
	{
		SetPageNameText(GameStrings.Get("GLUE_COLLECTION_MANAGER_HERO_SKINS_TITLE"));
		SetPageFlavorTextures(m_pageFlavorHeader, HEADER_CLASS.HEROSKINS);
	}

	public void SetGuideSkins()
	{
		SetPageNameText(GameStrings.Get("GLUE_BACON_COLLECTION_MANAGER_GUIDE_SKINS_TITLE"));
		SetPageFlavorTextures(m_pageFlavorHeader, HEADER_CLASS.GUIDESKINS);
	}

	public void SetBoardSkins()
	{
		SetPageNameText(GameStrings.Get("GLUE_BACON_COLLECTION_MANAGER_BOARD_SKINS_TITLE"));
		SetPageFlavorTextures(m_pageFlavorHeader, HEADER_CLASS.BOARDSKINS);
	}

	public void SetFinishers()
	{
		SetPageNameText(GameStrings.Get("GLUE_BACON_COLLECTION_MANAGER_FINISHERS_TITLE"));
		SetPageFlavorTextures(m_pageFlavorHeader, HEADER_CLASS.FINISHERS);
	}

	public void SetEmotes()
	{
		SetPageNameText(GameStrings.Get("GLUE_BACON_COLLECTION_MANAGER_EMOTES_TITLE"));
		SetPageFlavorTextures(m_pageFlavorHeader, HEADER_CLASS.EMOTES);
	}

	private void BoardSkinDisplayEventListener(string eventName)
	{
		EventDataModel dataModel = m_BoardSkinsWidgetInstance.GetDataModel<EventDataModel>();
		if (dataModel == null)
		{
			Log.All.PrintError("No event data model attached to BaconCollectionPageDisplay");
			return;
		}
		BattlegroundsBoardSkinDataModel battlegroundsBoardSkinDataModel = (BattlegroundsBoardSkinDataModel)dataModel.Payload;
		if (!(eventName == "BOARD_SKIN_clicked"))
		{
			if (eventName == "BOARD_SKIN_hover_end")
			{
				MarkBoardSeen(battlegroundsBoardSkinDataModel);
			}
			return;
		}
		BattlegroundsBoardSkinCollectionPageDataModel orCreateBoardCollectionPageDataModel = GetOrCreateBoardCollectionPageDataModel();
		BaconCollectionDisplay obj = CollectionManager.Get().GetCollectibleDisplay() as BaconCollectionDisplay;
		if (obj == null)
		{
			Log.CollectionManager.PrintError("BaconCollectionPageDisplay.BOARD_SKIN_clicked - BaconCollectionDisplay is null!");
		}
		obj.ShowBoardDetailsDisplay(battlegroundsBoardSkinDataModel, orCreateBoardCollectionPageDataModel);
		MarkBoardSeen(battlegroundsBoardSkinDataModel);
	}

	private void FinisherDisplayEventListener(string eventName)
	{
		EventDataModel dataModel = m_FinishersWidgetInstance.GetDataModel<EventDataModel>();
		if (dataModel == null)
		{
			Log.All.PrintError("No event data model attached to BaconCollectionPageDisplay");
			return;
		}
		BattlegroundsFinisherDataModel battlegroundsFinisherDataModel = (BattlegroundsFinisherDataModel)dataModel.Payload;
		if (!(eventName == "FINISHER_clicked"))
		{
			if (eventName == "FINISHER_hover_end")
			{
				MarkFinisherSeen(battlegroundsFinisherDataModel);
			}
			return;
		}
		BattlegroundsFinisherCollectionPageDataModel orCreateFinisherCollectionPageDataModel = GetOrCreateFinisherCollectionPageDataModel();
		BaconCollectionDisplay baconCollectionDisplay = CollectionManager.Get().GetCollectibleDisplay() as BaconCollectionDisplay;
		if (baconCollectionDisplay == null)
		{
			Log.CollectionManager.PrintError("BaconCollectionPageDisplay.FINISHER_clicked - BaconCollectionDisplay is null!");
			return;
		}
		baconCollectionDisplay.ShowFinisherDetailsDisplay(battlegroundsFinisherDataModel, orCreateFinisherCollectionPageDataModel);
		MarkFinisherSeen(battlegroundsFinisherDataModel);
	}

	private void EmoteDisplayEventListener(string eventName)
	{
		switch (eventName)
		{
		case "EMOTE_clicked":
		{
			if (CollectionInputMgr.Get().HasHeldEmote())
			{
				break;
			}
			BattlegroundsEmoteCollectionPageDataModel orCreateEmoteCollectionPageDataModel = GetOrCreateEmoteCollectionPageDataModel();
			BaconCollectionDisplay baconCollectionDisplay = CollectionManager.Get().GetCollectibleDisplay() as BaconCollectionDisplay;
			if (baconCollectionDisplay == null)
			{
				Log.CollectionManager.PrintError("BaconCollectionPageDisplay.EMOTE_clicked - BaconCollectionDisplay is null!");
				break;
			}
			BattlegroundsEmoteDataModel eventEmoteDataModel2 = GetEventEmoteDataModel();
			if (eventEmoteDataModel2 == null)
			{
				Log.CollectionManager.PrintError("Unable to retrieve emote from event");
				break;
			}
			baconCollectionDisplay.ShowEmoteDetailsDisplay(eventEmoteDataModel2, orCreateEmoteCollectionPageDataModel);
			MarkEmoteSeen(eventEmoteDataModel2);
			break;
		}
		case "EMOTE_hover_end":
		{
			BattlegroundsEmoteDataModel eventEmoteDataModel = GetEventEmoteDataModel();
			if (eventEmoteDataModel == null)
			{
				Log.CollectionManager.PrintError("Unable to retrieve emote from event");
			}
			else
			{
				MarkEmoteSeen(eventEmoteDataModel);
			}
			break;
		}
		case "EMOTE_drag_started":
			OnEmoteDragStart();
			break;
		case "EMOTE_drag_released":
			CollectionInputMgr.Get().DropBattlegroundsEmote(dragCanceled: false);
			break;
		}
	}

	public override void MarkAllShownCardsSeen()
	{
		base.MarkAllShownCardsSeen();
		MarkAllShownBoardsSeen();
		MarkAllShownFinishersSeen();
		MarkAllShownEmotesSeen();
	}

	private static void MarkBoardSeen(BattlegroundsBoardSkinDataModel boardData)
	{
		if (boardData == null)
		{
			Error.AddDevFatal("BaconCollectionPageDisplay.MarkBoardSeen - null board data model!");
			return;
		}
		boardData.IsNew = false;
		CollectionManager.Get().MarkBattlegroundsBoardSkinSeen(BattlegroundsBoardSkinId.FromTrustedValue(boardData.BoardDbiId));
	}

	private static void MarkFinisherSeen(BattlegroundsFinisherDataModel finisherData)
	{
		if (finisherData == null)
		{
			Error.AddDevFatal("BaconCollectionPageDisplay.MarkFinisherSeen - null finisher data model");
			return;
		}
		finisherData.IsNew = false;
		CollectionManager.Get().MarkBattlegroundsFinisherSeen(BattlegroundsFinisherId.FromTrustedValue(finisherData.FinisherDbiId));
	}

	private static void MarkEmoteSeen(BattlegroundsEmoteDataModel emoteData)
	{
		if (emoteData == null)
		{
			Error.AddDevFatal("BaconCollectionPageDisplay.MarkEmoteSeen - null emote data model");
			return;
		}
		emoteData.IsNew = false;
		CollectionManager.Get().MarkBattlegroundsEmoteSeen(BattlegroundsEmoteId.FromTrustedValue(emoteData.EmoteDbiId));
	}

	private void OnBoardDisplayReady(Widget widget)
	{
		if (widget != null)
		{
			widget.RegisterEventListener(BoardSkinDisplayEventListener);
		}
		m_BoardSkinsWidgetInstance = widget;
	}

	private void OnFinisherDisplayReady(Widget widget)
	{
		if (widget != null)
		{
			widget.RegisterEventListener(FinisherDisplayEventListener);
		}
		m_FinishersWidgetInstance = widget;
	}

	private void OnEmoteDisplayReady(Widget widget)
	{
		if (widget != null)
		{
			widget.RegisterEventListener(EmoteDisplayEventListener);
		}
		m_EmotesWidgetInstance = widget;
	}

	private void MarkAllShownBoardsSeen()
	{
		if (!m_BoardSkinsWidget.GetDataModel(565, out var model))
		{
			return;
		}
		BattlegroundsBoardSkinCollectionPageDataModel battlegroundsBoardSkinCollectionPageDataModel = model as BattlegroundsBoardSkinCollectionPageDataModel;
		if (battlegroundsBoardSkinCollectionPageDataModel == null)
		{
			Log.All.PrintError("BaconCollectionPageDisplay.MarkAllShownBoardsSeen - data model of unexpected type!");
			return;
		}
		if (battlegroundsBoardSkinCollectionPageDataModel.BoardSkinList == null)
		{
			Log.All.PrintError("BaconCollectionPageDisplay.MarkAllShownBoardsSeen - data model list was null!");
			return;
		}
		foreach (BattlegroundsBoardSkinDataModel boardSkin in battlegroundsBoardSkinCollectionPageDataModel.BoardSkinList)
		{
			MarkBoardSeen(boardSkin);
		}
	}

	private void MarkAllShownFinishersSeen()
	{
		if (!m_FinishersWidget.GetDataModel(568, out var model))
		{
			return;
		}
		BattlegroundsFinisherCollectionPageDataModel battlegroundsFinisherCollectionPageDataModel = model as BattlegroundsFinisherCollectionPageDataModel;
		if (battlegroundsFinisherCollectionPageDataModel == null)
		{
			Log.All.PrintError("BaconCollectionPageDisplay.MarkAllShownFinishersSeen - data model of unexpected type!");
			return;
		}
		if (battlegroundsFinisherCollectionPageDataModel.FinisherList == null)
		{
			Log.All.PrintError("BaconCollectionPageDisplay.MarkAllShownFinishersSeen - data model list was null!");
			return;
		}
		foreach (BattlegroundsFinisherDataModel finisher in battlegroundsFinisherCollectionPageDataModel.FinisherList)
		{
			MarkFinisherSeen(finisher);
		}
	}

	private void MarkAllShownEmotesSeen()
	{
		if (!m_EmotesWidget.GetDataModel(639, out var model))
		{
			return;
		}
		BattlegroundsEmoteCollectionPageDataModel battlegroundsEmoteCollectionPageDataModel = model as BattlegroundsEmoteCollectionPageDataModel;
		if (battlegroundsEmoteCollectionPageDataModel == null)
		{
			Log.All.PrintError("BaconCollectionPageDisplay.MarkAllShownEmotesSeen - data model of unexpected type!");
			return;
		}
		if (battlegroundsEmoteCollectionPageDataModel.EmoteList == null)
		{
			Log.All.PrintError("BaconCollectionPageDisplay.MarkAllShownEmotesSeen - data model list was null!");
			return;
		}
		foreach (BattlegroundsEmoteDataModel emote in battlegroundsEmoteCollectionPageDataModel.EmoteList)
		{
			MarkEmoteSeen(emote);
		}
	}

	private void OnEmoteDragStart()
	{
		if (m_EmotesWidgetInstance == null)
		{
			return;
		}
		BaconCollectionDisplay baconCollectionDisplay = CollectionManager.Get().GetCollectibleDisplay() as BaconCollectionDisplay;
		if (!(baconCollectionDisplay != null) || !baconCollectionDisplay.IsEmoteDetailsShowing())
		{
			BattlegroundsEmoteDataModel eventEmoteDataModel = GetEventEmoteDataModel();
			if (eventEmoteDataModel == null)
			{
				Log.CollectionManager.PrintError("Unable to retrieve emote from event");
			}
			else if (!eventEmoteDataModel.IsOwned)
			{
				Log.CollectionManager.PrintError("Emote not owned");
			}
			else
			{
				CollectionInputMgr.Get().GrabBattlegroundsEmote(eventEmoteDataModel, CollectionUtils.BattlegroundsModeDraggableType.CollectionEmote);
			}
		}
	}

	private BattlegroundsEmoteDataModel GetEventEmoteDataModel()
	{
		EventDataModel dataModel = m_EmotesWidgetInstance.GetDataModel<EventDataModel>();
		if (dataModel == null)
		{
			Log.CollectionManager.PrintError("No event data model attached to BaconCollectionPageDisplay");
			return null;
		}
		return dataModel.Payload as BattlegroundsEmoteDataModel;
	}

	public static void SetPageFlavorTextures(GameObject header, HEADER_CLASS headerClass)
	{
		if (!(header == null))
		{
			float x = (float)((int)headerClass / 8) * 0.5f;
			float y = (float)headerClass / -8f;
			CollectiblePageDisplay.SetPageFlavorTextures(header, new UnityEngine.Vector2(x, y));
		}
	}
}
