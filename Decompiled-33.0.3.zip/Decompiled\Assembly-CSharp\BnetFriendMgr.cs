using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Blizzard.GameService.SDK.Client.Integration;
using Hearthstone;
using PegasusClient;
using PegasusShared;
using UnityEngine;

public class BnetFriendMgr
{
	public delegate void ChangeCallback(BnetFriendChangelist changelist, object userData);

	private class ChangeListener : EventListener<ChangeCallback>
	{
		public void Fire(BnetFriendChangelist changelist)
		{
			m_callback(changelist, m_userData);
		}
	}

	private static BnetFriendMgr s_instance;

	private int m_maxFriends;

	private int m_maxReceivedInvites;

	private int m_maxSentInvites;

	private List<BnetPlayer> m_friends = new List<BnetPlayer>();

	private List<BnetInvitation> m_receivedInvites = new List<BnetInvitation>();

	private List<BnetInvitation> m_sentInvites = new List<BnetInvitation>();

	private List<ChangeListener> m_changeListeners = new List<ChangeListener>();

	private PendingBnetFriendChangelist m_pendingChangelist = new PendingBnetFriendChangelist();

	private bool m_isRegisteredToFriendHandler;

	private bool m_isFriendInviteFeatureEnabled;

	private static ulong nextIdToken;

	public bool IsFriendInviteFeatureEnabled => m_isFriendInviteFeatureEnabled;

	public static BnetFriendMgr Get()
	{
		if (s_instance == null)
		{
			s_instance = new BnetFriendMgr();
			HearthstoneApplication.Get().WillReset += s_instance.Clear;
		}
		return s_instance;
	}

	public void Initialize()
	{
		FriendMgr.Get().Initialize();
		Network.Get().OnDisconnectedFromBattleNet += OnDisconnectedFromBattleNet;
		RegisterFriendHandler();
		InitMaximums();
	}

	public void SetFriendInviteFeatureStatus(bool isEnabled)
	{
		m_isFriendInviteFeatureEnabled = isEnabled;
		Log.Privacy.PrintDebug("BnetFriendMgr SetFriendInviteFeatureStatus m_isFriendInviteFeatureEnabled " + $" {m_isFriendInviteFeatureEnabled}, m_isRegisteredToFriendHandler {m_isRegisteredToFriendHandler}");
		if (!m_isRegisteredToFriendHandler)
		{
			RegisterFriendHandler();
		}
		if (m_isFriendInviteFeatureEnabled)
		{
			BnetFriendChangelist bnetFriendChangelist = new BnetFriendChangelist();
			foreach (BnetInvitation receivedInvite in m_receivedInvites)
			{
				bnetFriendChangelist.AddAddedReceivedInvite(receivedInvite);
			}
			if (!bnetFriendChangelist.IsEmpty())
			{
				FireChangeEvent(bnetFriendChangelist);
			}
			return;
		}
		BnetFriendChangelist bnetFriendChangelist2 = new BnetFriendChangelist();
		foreach (BnetInvitation receivedInvite2 in m_receivedInvites)
		{
			bnetFriendChangelist2.AddRemovedReceivedInvite(receivedInvite2);
		}
		if (!bnetFriendChangelist2.IsEmpty())
		{
			FireChangeEvent(bnetFriendChangelist2);
		}
	}

	private void RegisterFriendHandler()
	{
		if (!m_isRegisteredToFriendHandler)
		{
			Log.Privacy.PrintDebug("BnetFriendMgr RegisterFriendHandler");
			m_isRegisteredToFriendHandler = true;
			Network.Get().SetFriendsHandler(OnFriendsUpdate);
			Network.Get().AddBnetErrorListener(BnetFeature.Friends, OnBnetError);
		}
	}

	public BnetPlayer FindFriend(BnetAccountId id)
	{
		BnetPlayer bnetPlayer = FindNonPendingFriend(id);
		if (bnetPlayer != null)
		{
			return bnetPlayer;
		}
		bnetPlayer = FindPendingFriend(id);
		if (bnetPlayer != null)
		{
			return bnetPlayer;
		}
		return null;
	}

	public bool IsFriend(BnetPlayer player)
	{
		if (IsNonPendingFriend(player))
		{
			return true;
		}
		if (IsPendingFriend(player))
		{
			return true;
		}
		return false;
	}

	public bool IsFriend(BnetAccountId id)
	{
		if (IsNonPendingFriend(id))
		{
			return true;
		}
		if (IsPendingFriend(id))
		{
			return true;
		}
		return false;
	}

	public bool IsFriend(BnetGameAccountId id)
	{
		if (IsNonPendingFriend(id))
		{
			return true;
		}
		if (IsPendingFriend(id))
		{
			return true;
		}
		return false;
	}

	public List<BnetPlayer> GetFriends()
	{
		return m_friends;
	}

	public bool HasOnlineFriends()
	{
		foreach (BnetPlayer friend in m_friends)
		{
			if (friend.IsOnline())
			{
				return true;
			}
		}
		return false;
	}

	public int GetOnlineFriendCount()
	{
		int num = 0;
		foreach (BnetPlayer friend in m_friends)
		{
			if (friend.IsOnline() || friend.IsAway())
			{
				num++;
			}
		}
		return num;
	}

	public BnetPlayer FindNonPendingFriend(BnetAccountId id)
	{
		foreach (BnetPlayer friend in m_friends)
		{
			if (friend.GetAccountId() == id)
			{
				return friend;
			}
		}
		return null;
	}

	public BnetPlayer FindNonPendingFriend(BnetGameAccountId id)
	{
		foreach (BnetPlayer friend in m_friends)
		{
			if (friend.HasGameAccount(id))
			{
				return friend;
			}
		}
		return null;
	}

	public bool IsNonPendingFriend(BnetPlayer player)
	{
		if (player == null)
		{
			return false;
		}
		if (m_friends.Contains(player))
		{
			return true;
		}
		BnetAccountId accountId = player.GetAccountId();
		if (accountId != null)
		{
			return IsFriend(accountId);
		}
		foreach (BnetGameAccountId key in player.GetGameAccounts().Keys)
		{
			if (IsFriend(key))
			{
				return true;
			}
		}
		return false;
	}

	public bool IsNonPendingFriend(BnetAccountId id)
	{
		return FindNonPendingFriend(id) != null;
	}

	public bool IsNonPendingFriend(BnetGameAccountId id)
	{
		return FindNonPendingFriend(id) != null;
	}

	public BnetPlayer FindPendingFriend(BnetAccountId id)
	{
		return m_pendingChangelist.FindFriend(id);
	}

	public bool IsPendingFriend(BnetPlayer player)
	{
		return m_pendingChangelist.IsFriend(player);
	}

	public bool IsPendingFriend(BnetAccountId id)
	{
		return m_pendingChangelist.IsFriend(id);
	}

	public bool IsPendingFriend(BnetGameAccountId id)
	{
		return m_pendingChangelist.IsFriend(id);
	}

	public List<BnetInvitation> GetReceivedInvites()
	{
		if (m_isFriendInviteFeatureEnabled)
		{
			return m_receivedInvites;
		}
		return null;
	}

	public void AcceptInvite(BnetInvitation invite)
	{
		Network.AcceptFriendInvite(invite.GetId());
		BnetRecentPlayerMgr.Get().AddPendingFriend(invite.GetInviterId());
	}

	public void IgnoreInvite(BnetInvitationId inviteId)
	{
		Network.IgnoreFriendInvite(inviteId);
	}

	public bool SendInvite(string name)
	{
		Log.Privacy.PrintDebug($"BnetFriendMgr m_isFriendInviteFeatureEnabled {m_isFriendInviteFeatureEnabled}");
		if (!m_isFriendInviteFeatureEnabled)
		{
			return true;
		}
		if (name.Contains("@"))
		{
			return SendInviteByEmail(name);
		}
		if (name.Contains("#"))
		{
			return SendInviteByBattleTag(name);
		}
		return false;
	}

	public bool SendInviteByEmail(string email)
	{
		if (!new Regex("^\\S[^@]+@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)+$").IsMatch(email))
		{
			return false;
		}
		Network.SendFriendInviteByEmail(BnetPresenceMgr.Get().GetMyPlayer().GetFullName(), email);
		return true;
	}

	public bool SendInviteByBattleTag(string battleTagString)
	{
		if (!new Regex("^[^\\W\\d_][^\\W_]{1,11}#\\d+$").IsMatch(battleTagString))
		{
			return false;
		}
		Network.SendFriendInviteByBattleTag(BnetPresenceMgr.Get().GetMyPlayer().GetBattleTag()
			.GetString(), battleTagString);
		BnetRecentPlayerMgr.Get().AddPendingFriend(battleTagString);
		return true;
	}

	public bool RemoveFriend(BnetPlayer friend)
	{
		bool flag = false;
		for (int i = 0; i < m_friends.Count; i++)
		{
			if (m_friends[i].GetAccountId().Equals(friend.GetAccountId()))
			{
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			return false;
		}
		Network.RemoveFriend(friend.GetAccountId());
		return true;
	}

	public bool AddChangeListener(ChangeCallback callback)
	{
		return AddChangeListener(callback, null);
	}

	public bool AddChangeListener(ChangeCallback callback, object userData)
	{
		ChangeListener changeListener = new ChangeListener();
		changeListener.SetCallback(callback);
		changeListener.SetUserData(userData);
		if (m_changeListeners.Contains(changeListener))
		{
			return false;
		}
		m_changeListeners.Add(changeListener);
		return true;
	}

	public bool RemoveChangeListener(ChangeCallback callback)
	{
		return RemoveChangeListener(callback, null);
	}

	private bool RemoveChangeListener(ChangeCallback callback, object userData)
	{
		ChangeListener changeListener = new ChangeListener();
		changeListener.SetCallback(callback);
		changeListener.SetUserData(userData);
		return m_changeListeners.Remove(changeListener);
	}

	public static bool RemoveChangeListenerFromInstance(ChangeCallback callback, object userData = null)
	{
		if (s_instance == null)
		{
			return false;
		}
		return s_instance.RemoveChangeListener(callback, userData);
	}

	private void InitMaximums()
	{
		FriendsInfo info = default(FriendsInfo);
		BattleNet.GetFriendsInfo(ref info);
		m_maxFriends = info.maxFriends;
		m_maxReceivedInvites = info.maxRecvInvites;
		m_maxSentInvites = info.maxSentInvites;
	}

	private void ProcessPendingFriends()
	{
		bool flag = false;
		foreach (BnetPlayer friend in m_pendingChangelist.GetFriends())
		{
			if (friend.IsDisplayable())
			{
				flag = true;
				m_friends.Add(friend);
			}
		}
		if (flag)
		{
			FirePendingFriendsChangedEvent();
		}
	}

	private void OnDisconnectedFromBattleNet(BattleNetErrors error)
	{
		Clear();
	}

	private void OnFriendsUpdate(FriendsUpdate[] updates)
	{
		BnetFriendChangelist bnetFriendChangelist = new BnetFriendChangelist();
		for (int i = 0; i < updates.Length; i++)
		{
			FriendsUpdate src = updates[i];
			switch (src.action)
			{
			case 1:
			{
				BnetAccountId accountId = BnetAccountId.CreateFromBnetEntityId(src.entity1);
				BnetPlayer bnetPlayer = BnetPresenceMgr.Get().RegisterPlayer(BnetPlayerSource.FRIENDLIST, accountId);
				if (bnetPlayer.IsDisplayable())
				{
					m_friends.Add(bnetPlayer);
					bnetFriendChangelist.AddAddedFriend(bnetPlayer);
				}
				else
				{
					AddPendingFriend(bnetPlayer);
				}
				break;
			}
			case 2:
			{
				BnetAccountId bnetAccountId = BnetAccountId.CreateFromBnetEntityId(src.entity1);
				BnetPlayer player = BnetPresenceMgr.Get().GetPlayer(bnetAccountId);
				m_friends.Remove(player);
				bnetFriendChangelist.AddRemovedFriend(player);
				RemovePendingFriend(player);
				BnetPresenceMgr.Get().CheckSubscriptionsAndClearTransientStatus(bnetAccountId);
				break;
			}
			case 3:
			{
				BnetInvitation bnetInvitation4 = BnetInvitation.CreateFromFriendsUpdate(src);
				m_receivedInvites.Add(bnetInvitation4);
				bnetFriendChangelist.AddAddedReceivedInvite(bnetInvitation4);
				break;
			}
			case 4:
			{
				BnetInvitation bnetInvitation3 = BnetInvitation.CreateFromFriendsUpdate(src);
				m_receivedInvites.Remove(bnetInvitation3);
				bnetFriendChangelist.AddRemovedReceivedInvite(bnetInvitation3);
				break;
			}
			case 5:
			{
				BnetInvitation bnetInvitation2 = BnetInvitation.CreateFromFriendsUpdate(src);
				m_sentInvites.Add(bnetInvitation2);
				bnetFriendChangelist.AddAddedSentInvite(bnetInvitation2);
				break;
			}
			case 6:
			{
				BnetInvitation bnetInvitation = BnetInvitation.CreateFromFriendsUpdate(src);
				m_sentInvites.Remove(bnetInvitation);
				bnetFriendChangelist.AddRemovedSentInvite(bnetInvitation);
				break;
			}
			}
		}
		if (bnetFriendChangelist.IsEmpty())
		{
			return;
		}
		if (m_isFriendInviteFeatureEnabled)
		{
			FireChangeEvent(bnetFriendChangelist);
			return;
		}
		foreach (BnetInvitation receivedInvite in m_receivedInvites)
		{
			bnetFriendChangelist.AddRemovedReceivedInvite(receivedInvite);
			bnetFriendChangelist.RemoveAddedReceivedInvite(receivedInvite);
		}
		FireChangeEvent(bnetFriendChangelist);
	}

	private void OnPendingPlayersChanged(BnetPlayerChangelist changelist, object userData)
	{
		ProcessPendingFriends();
	}

	private bool OnBnetError(BnetErrorInfo info, object userData)
	{
		return true;
	}

	private void Clear()
	{
		m_friends.Clear();
		m_receivedInvites.Clear();
		m_sentInvites.Clear();
		m_pendingChangelist.Clear();
		BnetPresenceMgr.Get().RemovePlayersChangedListener(OnPendingPlayersChanged);
	}

	private void FireChangeEvent(BnetFriendChangelist changelist)
	{
		ChangeListener[] array = m_changeListeners.ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].Fire(changelist);
		}
	}

	private void AddPendingFriend(BnetPlayer friend)
	{
		if (m_pendingChangelist.Add(friend) && m_pendingChangelist.GetCount() == 1)
		{
			BnetPresenceMgr.Get().AddPlayersChangedListener(OnPendingPlayersChanged);
		}
	}

	private void RemovePendingFriend(BnetPlayer friend)
	{
		if (m_pendingChangelist.Remove(friend))
		{
			if (m_pendingChangelist.GetCount() == 0)
			{
				BnetPresenceMgr.Get().RemovePlayersChangedListener(OnPendingPlayersChanged);
			}
			else
			{
				ProcessPendingFriends();
			}
		}
	}

	private void FirePendingFriendsChangedEvent()
	{
		BnetFriendChangelist changelist = m_pendingChangelist.CreateChangelist();
		if (m_pendingChangelist.GetCount() == 0)
		{
			BnetPresenceMgr.Get().RemovePlayersChangedListener(OnPendingPlayersChanged);
		}
		FireChangeEvent(changelist);
	}

	public BnetPlayer Cheat_CreatePlayer(string fullName, int leagueId, int starLevel, BnetProgramId programId, bool isFriend, bool isOnline, bool isAway = false)
	{
		BnetBattleTag bnetBattleTag = new BnetBattleTag();
		bnetBattleTag.SetString($"friend#{nextIdToken}");
		BnetAccountId id = new BnetAccountId(nextIdToken++, nextIdToken++);
		BnetAccount bnetAccount = new BnetAccount();
		bnetAccount.SetId(id);
		bnetAccount.SetFullName(fullName);
		bnetAccount.SetBattleTag(bnetBattleTag);
		BnetGameAccountId id2 = new BnetGameAccountId(nextIdToken++, nextIdToken++);
		BnetGameAccount bnetGameAccount = new BnetGameAccount();
		bnetGameAccount.SetId(id2);
		bnetGameAccount.SetBattleTag(bnetBattleTag);
		bnetGameAccount.SetOnline(isOnline);
		bnetGameAccount.SetAway(isAway);
		bnetGameAccount.SetProgramId(programId);
		GamePresenceRank gamePresenceRank = new GamePresenceRank();
		foreach (FormatType value in Enum.GetValues(typeof(FormatType)))
		{
			if (value != 0)
			{
				GamePresenceRankData item = new GamePresenceRankData
				{
					FormatType = value,
					LeagueId = leagueId,
					StarLevel = starLevel,
					LegendRank = UnityEngine.Random.Range(1, 99999)
				};
				gamePresenceRank.Values.Add(item);
			}
		}
		byte[] val = ProtobufUtil.ToByteArray(gamePresenceRank);
		bnetGameAccount.SetGameField(18u, val);
		BnetPlayer bnetPlayer = new BnetPlayer(BnetPlayerSource.CREATED_BY_CHEAT);
		bnetPlayer.SetAccount(bnetAccount);
		bnetPlayer.AddGameAccount(bnetGameAccount);
		bnetPlayer.IsCheatPlayer = true;
		if (isFriend)
		{
			m_friends.Add(bnetPlayer);
		}
		return bnetPlayer;
	}

	public BnetPlayer Cheat_CreateFriend(string fullName, int leagueId, int starLevel, BnetProgramId programId, bool isOnline, bool isAway)
	{
		return Cheat_CreatePlayer(fullName, leagueId, starLevel, programId, isFriend: true, isOnline, isAway);
	}

	public int Cheat_RemoveCheatFriends()
	{
		int num = 0;
		for (int num2 = m_friends.Count - 1; num2 >= 0; num2--)
		{
			if (m_friends[num2].IsCheatPlayer)
			{
				m_friends.RemoveAt(num2);
				num++;
			}
		}
		return num;
	}
}
