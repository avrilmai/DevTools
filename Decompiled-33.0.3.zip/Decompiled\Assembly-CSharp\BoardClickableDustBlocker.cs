using UnityEngine;

public class BoardClickableDustBlocker : MonoBehaviour
{
}
