using System.Collections.Generic;
using UnityEngine;

public class AchieveDbfAsset : ScriptableObject
{
	public List<AchieveDbfRecord> Records = new List<AchieveDbfRecord>();
}
