using System;
using UnityEngine;

public class BigCardBoneLayout : MonoBehaviour
{
	[Serializable]
	public class ScaleSettings
	{
		[Range(0.1f, 5f)]
		public float m_BigCardScale_Minion = 1f;

		[Range(0.1f, 5f)]
		public float m_BigCardScale_LettuceAbility = 1f;
	}

	public GameObject m_OuterLeftBone;

	public GameObject m_InnerLeftBone;

	public GameObject m_InnerRightBone;

	public GameObject m_OuterRightBone;

	public ScaleSettings m_scaleSettings = new ScaleSettings();

	private void Awake()
	{
		if (m_scaleSettings.m_BigCardScale_Minion <= 0f)
		{
			GameObject gameObject = base.gameObject;
			while (base.gameObject.transform.parent.gameObject != null)
			{
				gameObject = base.gameObject.transform.parent.gameObject;
			}
			Debug.LogError($"{m_scaleSettings.m_BigCardScale_Minion} on object \"{base.gameObject.name}\" is an invalid value for the scale of a big card. Parent-most object is called \"{gameObject.name}\". " + "This should be a positive number.  Value is being set to 1.");
			m_scaleSettings.m_BigCardScale_Minion = 1f;
		}
		if (m_scaleSettings.m_BigCardScale_LettuceAbility <= 0f)
		{
			GameObject gameObject2 = base.gameObject;
			while (base.gameObject.transform.parent.gameObject != null)
			{
				gameObject2 = base.gameObject.transform.parent.gameObject;
			}
			Debug.LogError($"{m_scaleSettings.m_BigCardScale_LettuceAbility} on object \"{base.gameObject.name}\" is an invalid value for the scale of a big card. Parent-most object is called \"{gameObject2.name}\". " + "This should be a positive number.  Value is being set to 1.");
			m_scaleSettings.m_BigCardScale_LettuceAbility = 1f;
		}
	}

	public bool HasAllBones()
	{
		if (m_OuterLeftBone != null && m_InnerLeftBone != null && m_InnerRightBone != null)
		{
			return m_OuterRightBone != null;
		}
		return false;
	}
}
