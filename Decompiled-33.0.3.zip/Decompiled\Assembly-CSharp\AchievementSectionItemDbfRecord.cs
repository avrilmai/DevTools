using System;
using System.Collections.Generic;
using Blizzard.T5.Jobs;
using UnityEngine;

[Serializable]
public class AchievementSectionItemDbfRecord : DbfRecord
{
	[SerializeField]
	private int m_achievementSubcategoryId;

	[SerializeField]
	private int m_achievementSectionId;

	[SerializeField]
	private int m_sortOrder;

	[DbfField("ACHIEVEMENT_SUBCATEGORY_ID")]
	public int AchievementSubcategoryId => m_achievementSubcategoryId;

	public AchievementSectionDbfRecord AchievementSectionRecord => GameDbf.AchievementSection.GetRecord(m_achievementSectionId);

	[DbfField("SORT_ORDER")]
	public int SortOrder => m_sortOrder;

	public override object GetVar(string name)
	{
		switch (name)
		{
		case "ID":
			return base.ID;
		case "ACHIEVEMENT_SUBCATEGORY_ID":
			return m_achievementSubcategoryId;
		case "ACHIEVEMENT_SECTION":
			return m_achievementSectionId;
		case "SORT_ORDER":
			return m_sortOrder;
		default:
			return null;
		}
	}

	public override void SetVar(string name, object val)
	{
		switch (name)
		{
		case "ID":
			SetID((int)val);
			break;
		case "ACHIEVEMENT_SUBCATEGORY_ID":
			m_achievementSubcategoryId = (int)val;
			break;
		case "ACHIEVEMENT_SECTION":
			m_achievementSectionId = (int)val;
			break;
		case "SORT_ORDER":
			m_sortOrder = (int)val;
			break;
		}
	}

	public override Type GetVarType(string name)
	{
		switch (name)
		{
		case "ID":
			return typeof(int);
		case "ACHIEVEMENT_SUBCATEGORY_ID":
			return typeof(int);
		case "ACHIEVEMENT_SECTION":
			return typeof(int);
		case "SORT_ORDER":
			return typeof(int);
		default:
			return null;
		}
	}

	public override IEnumerator<IAsyncJobResult> Job_LoadRecordsFromAssetAsync<T>(string resourcePath, Action<List<T>> resultHandler)
	{
		LoadAchievementSectionItemDbfRecords loadRecords = new LoadAchievementSectionItemDbfRecords(resourcePath);
		yield return loadRecords;
		resultHandler?.Invoke(loadRecords.GetRecords() as List<T>);
	}

	public override bool LoadRecordsFromAsset<T>(string resourcePath, out List<T> records)
	{
		AchievementSectionItemDbfAsset achievementSectionItemDbfAsset = DbfShared.GetAssetBundle().LoadAsset(resourcePath, typeof(AchievementSectionItemDbfAsset)) as AchievementSectionItemDbfAsset;
		if (achievementSectionItemDbfAsset == null)
		{
			records = new List<T>();
			Debug.LogError($"AchievementSectionItemDbfAsset.LoadRecordsFromAsset() - failed to load records from assetbundle: {resourcePath}");
			return false;
		}
		for (int i = 0; i < achievementSectionItemDbfAsset.Records.Count; i++)
		{
			achievementSectionItemDbfAsset.Records[i].StripUnusedLocales();
		}
		records = achievementSectionItemDbfAsset.Records as List<T>;
		return true;
	}

	public override bool SaveRecordsToAsset<T>(string assetPath, List<T> records, Locale locale)
	{
		return false;
	}

	public override void StripUnusedLocales()
	{
	}
}
