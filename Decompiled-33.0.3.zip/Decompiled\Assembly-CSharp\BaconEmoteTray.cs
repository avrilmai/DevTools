using System;
using System.Collections;
using System.Collections.Generic;
using Hearthstone;
using Hearthstone.DataModels;
using Hearthstone.UI;
using UnityEngine;

[RequireComponent(typeof(VisualController))]
public class BaconEmoteTray : MonoBehaviour
{
	[SerializeField]
	private Widget[] m_emoteWidgets;

	[Tooltip("Pointers for each tray slot's nested BattlegroundsImageWidget")]
	[SerializeField]
	private AsyncReference[] m_asyncImageWidgetReferences;

	private readonly Widget[] m_nestedImageWidgets = new Widget[6];

	private List<Vector3> m_emotePositions;

	[SerializeField]
	private iTween.EaseType m_shuffleEase;

	[SerializeField]
	private float m_shuffleTime;

	protected VisualController m_vc;

	protected Widget m_widget;

	private BattlegroundsEmoteLoadoutDataModel m_loadoutToSave;

	private const int INVALID_EMOTE_INDEX = -1;

	private const int LOADOUT_SIZE = 6;

	private int m_draggedIndex = -1;

	private int m_hoveredEmoteIndex = -1;

	private int m_readyImageWidgets;

	private bool m_trayHovered;

	public void Start()
	{
		m_vc = base.gameObject.GetComponent<VisualController>();
		if (m_vc == null)
		{
			Log.CollectionManager.PrintError("BaconEmoteTray was initialized without a visual controller defined.");
			return;
		}
		m_widget = m_vc.Owner;
		if (m_widget == null)
		{
			Log.CollectionManager.PrintError("BaconEmoteTray was initialized without a widget defined.");
			return;
		}
		m_widget.BindDataModel(CollectionManager.Get().CreateEmoteLoadoutDataModel());
		m_widget.RegisterEventListener(EmoteDisplayEventListener);
		m_emotePositions = new List<Vector3>();
		Widget[] emoteWidgets = m_emoteWidgets;
		foreach (Widget widget2 in emoteWidgets)
		{
			m_emotePositions.Add(widget2.transform.localPosition);
		}
		if (m_asyncImageWidgetReferences.Length != 6)
		{
			Log.CollectionManager.PrintError($"BaconEmoteTray was initialized with incorrect number of async image widget references. Expected {6}, found {m_asyncImageWidgetReferences.Length}");
			return;
		}
		for (int j = 0; j < m_asyncImageWidgetReferences.Length; j++)
		{
			int imageIndex = j;
			m_asyncImageWidgetReferences[j].RegisterReadyListener(delegate(Widget widget)
			{
				m_nestedImageWidgets[imageIndex] = widget;
				m_readyImageWidgets++;
			});
		}
	}

	public void Show(BattlegroundsEmoteLoadoutDataModel dataModel)
	{
		if (m_widget == null)
		{
			Log.CollectionManager.PrintError("BaconEmoteTray was shown without a widget defined.");
			return;
		}
		SetLoadoutDataModel(dataModel);
		StartCoroutine(ShowWhenReady(dataModel));
	}

	private IEnumerator ShowWhenReady(BattlegroundsEmoteLoadoutDataModel dataModel)
	{
		yield return new WaitUntil(() => m_readyImageWidgets == m_asyncImageWidgetReferences.Length);
		UpdateImageWidgetVisibility(dataModel);
		m_widget.TriggerEvent("SHOW");
	}

	public void UpdateImageWidgetVisibility(BattlegroundsEmoteLoadoutDataModel dataModel)
	{
		for (int i = 0; i < dataModel.EmoteList.Count; i++)
		{
			if (dataModel.EmoteList[i].EmoteDbiId == 0)
			{
				m_nestedImageWidgets[i].Hide();
			}
			else
			{
				m_nestedImageWidgets[i].Show();
			}
		}
	}

	public void Hide()
	{
		if (m_widget == null)
		{
			Log.CollectionManager.PrintError("BaconEmoteTray was hidden without a widget defined.");
			return;
		}
		if (GetLoadoutDataModel() != null)
		{
			Network.Get().SetBattlegroundsEmoteLoadout(BattlegroundsEmoteLoadout.MakeFromDatamodel(GetLoadoutDataModel()));
			m_widget.UnbindDataModel(645);
		}
		m_widget.TriggerEvent("HIDE");
	}

	public void OnDestroy()
	{
		if (m_loadoutToSave != null)
		{
			Network network = Network.Get();
			if (network != null)
			{
				network.SetBattlegroundsEmoteLoadout(BattlegroundsEmoteLoadout.MakeFromDatamodel(m_loadoutToSave));
			}
			else
			{
				Debug.Log("Unable to set new BGS emote loadout on network.");
			}
		}
	}

	public void Unload()
	{
		if (m_widget == null)
		{
			Log.CollectionManager.PrintError("BaconEmoteTray was unloaded without a widget defined.");
		}
		else
		{
			m_widget.RemoveEventListener(EmoteDisplayEventListener);
		}
	}

	public void SetLoadoutDataModel(BattlegroundsEmoteLoadoutDataModel dataModel)
	{
		if (dataModel == null)
		{
			Log.CollectionManager.PrintError("BaconEmoteTray.SetLoadoutDataModel - received null datamodel");
			return;
		}
		m_widget.BindDataModel(dataModel);
		m_loadoutToSave = dataModel;
		m_widget.TriggerEvent("UPDATE");
	}

	public void DropOverEmoteTray(BattlegroundsEmoteDataModel dataModel)
	{
		if (IsShufflingEmotes())
		{
			return;
		}
		BattlegroundsEmoteLoadoutDataModel loadoutDataModel = GetLoadoutDataModel();
		if (loadoutDataModel == null)
		{
			Log.CollectionManager.PrintError("BaconEmoteTray - No bound datamodel for emote operations.");
			return;
		}
		if (loadoutDataModel.EmoteList == null)
		{
			Log.CollectionManager.PrintError("BaconEmoteTray - Bound datamodel doesn't contain a valid emote loadout.");
			return;
		}
		if (dataModel == null)
		{
			Log.CollectionManager.PrintError("BaconEmoteTray - New Emote datamodel is null.");
			return;
		}
		int newEmoteIndex = m_hoveredEmoteIndex;
		if (newEmoteIndex == -1)
		{
			DataModelList<BattlegroundsEmoteDataModel> emoteList = GetLoadoutDataModel().EmoteList;
			for (int i = 0; i < emoteList.Count; i++)
			{
				if (emoteList[i].EmoteDbiId == 0 || emoteList[i].EmoteDbiId == dataModel.EmoteDbiId)
				{
					newEmoteIndex = i;
					break;
				}
			}
		}
		if (newEmoteIndex != -1)
		{
			if (!m_widget.GetDataModel(645, out var model))
			{
				Debug.LogWarning("BaconEmoteTray - no valid data model bound to the widget");
				return;
			}
			BattlegroundsEmoteLoadoutDataModel battlegroundsEmoteLoadoutDataModel = (BattlegroundsEmoteLoadoutDataModel)model;
			m_emoteWidgets[newEmoteIndex].TriggerEvent("DROP_EFFECTS");
			if (m_draggedIndex != -1)
			{
				bool isFillingEmptySlot = battlegroundsEmoteLoadoutDataModel.EmoteList[newEmoteIndex].EmoteDbiId == 0;
				int draggedEmoteIndex = m_draggedIndex;
				SwapEmoteDatamodels(newEmoteIndex, m_draggedIndex, battlegroundsEmoteLoadoutDataModel);
				m_widget.RegisterDoneChangingStatesListener(delegate
				{
					FinishSwappingEmoteImages(isFillingEmptySlot, draggedEmoteIndex, newEmoteIndex);
				}, null, callImmediatelyIfSet: true, doOnce: true);
			}
			else
			{
				BaconCollectionPageManager baconCollectionPageManager = CollectionManager.Get().GetCollectibleDisplay().GetPageManager() as BaconCollectionPageManager;
				if (baconCollectionPageManager != null)
				{
					if (battlegroundsEmoteLoadoutDataModel.EmoteList[newEmoteIndex] != null)
					{
						baconCollectionPageManager.SetEmoteEquippedState(BattlegroundsEmoteId.FromTrustedValue(battlegroundsEmoteLoadoutDataModel.EmoteList[newEmoteIndex].EmoteDbiId), isEquipped: false);
					}
					baconCollectionPageManager.SetEmoteEquippedState(BattlegroundsEmoteId.FromTrustedValue(dataModel.EmoteDbiId), isEquipped: true);
				}
				battlegroundsEmoteLoadoutDataModel.EmoteList[newEmoteIndex] = dataModel;
				SetLoadoutDataModel(battlegroundsEmoteLoadoutDataModel);
				m_emoteWidgets[newEmoteIndex].RegisterDoneChangingStatesListener(delegate
				{
					m_nestedImageWidgets[newEmoteIndex].Show();
				}, null, callImmediatelyIfSet: true, doOnce: true);
			}
		}
		m_draggedIndex = -1;
	}

	private void FinishSwappingEmoteImages(bool isFillingEmptySlot, int draggedIndex, int hoveredIndex)
	{
		if (!isFillingEmptySlot)
		{
			m_nestedImageWidgets[draggedIndex].Show();
			iTween.Stop(m_emoteWidgets[draggedIndex].gameObject);
			m_emoteWidgets[draggedIndex].transform.localPosition = m_emotePositions[hoveredIndex];
			iTween.MoveTo(m_emoteWidgets[draggedIndex].gameObject, iTween.Hash("position", m_emotePositions[draggedIndex], "time", m_shuffleTime, "easeType", m_shuffleEase, "islocal", true));
		}
		else
		{
			m_nestedImageWidgets[draggedIndex].Hide();
			m_nestedImageWidgets[hoveredIndex].Show();
		}
	}

	public bool IsEmoteOverTray()
	{
		if (!m_trayHovered)
		{
			return m_hoveredEmoteIndex != -1;
		}
		return true;
	}

	public bool IsLoadoutValid()
	{
		return GetLoadoutDataModel() != null;
	}

	public bool IsEmoteInLoadout(int emoteId)
	{
		foreach (BattlegroundsEmoteDataModel emote in GetLoadoutDataModel().EmoteList)
		{
			if (emote.EmoteDbiId == emoteId)
			{
				return true;
			}
		}
		return false;
	}

	public void RemoveEmote(BattlegroundsEmoteDataModel dataModel)
	{
		if (m_draggedIndex == -1)
		{
			Debug.LogError("Tried to remove emote from loadout without a held emote index saved.");
			return;
		}
		m_nestedImageWidgets[m_draggedIndex].Hide();
		if (!m_widget.GetDataModel(645, out var model))
		{
			Log.CollectionManager.PrintError("BaconEmoteTray - no valid data model bound to the widget");
			return;
		}
		BattlegroundsEmoteLoadoutDataModel battlegroundsEmoteLoadoutDataModel = (BattlegroundsEmoteLoadoutDataModel)model;
		BaconCollectionPageManager baconCollectionPageManager = CollectionManager.Get().GetCollectibleDisplay().GetPageManager() as BaconCollectionPageManager;
		if (baconCollectionPageManager != null && battlegroundsEmoteLoadoutDataModel.EmoteList[m_draggedIndex] != null)
		{
			baconCollectionPageManager.SetEmoteEquippedState(BattlegroundsEmoteId.FromTrustedValue(battlegroundsEmoteLoadoutDataModel.EmoteList[m_draggedIndex].EmoteDbiId), isEquipped: false);
		}
		battlegroundsEmoteLoadoutDataModel.EmoteList[m_draggedIndex] = new BattlegroundsEmoteDataModel();
		m_widget.BindDataModel(battlegroundsEmoteLoadoutDataModel);
		m_loadoutToSave = battlegroundsEmoteLoadoutDataModel;
		m_draggedIndex = -1;
	}

	public void UpdateTrayHighlight(bool trayHovered)
	{
		if (m_trayHovered != trayHovered)
		{
			m_trayHovered = trayHovered;
			string eventName = (trayHovered ? "SHOW_TRAY_HIGHLIGHT" : "HIDE_TRAY_HIGHLIGHT");
			Widget[] emoteWidgets = m_emoteWidgets;
			for (int i = 0; i < emoteWidgets.Length; i++)
			{
				emoteWidgets[i].TriggerEvent(eventName);
			}
		}
	}

	private void EmoteDisplayEventListener(string eventName)
	{
		switch (eventName)
		{
		case "EMOTE_drag_started":
			OnEmoteDragStart();
			break;
		case "EMOTE_drag_released":
			CollectionInputMgr.Get().DropBattlegroundsEmote(dragCanceled: false);
			break;
		case "EMOTE_mouse_over":
			OnEmoteMouseOver();
			break;
		case "EMOTE_mouse_out":
			OnEmoteMouseOut();
			break;
		}
	}

	private void OnEmoteDragStart()
	{
		if (IsShufflingEmotes())
		{
			return;
		}
		EventDataModel dataModel = m_widget.GetDataModel<EventDataModel>();
		if (dataModel == null)
		{
			Log.CollectionManager.PrintError("No event data model attached to BaconEmoteTray");
			return;
		}
		BattlegroundsEmoteDataModel battlegroundsEmoteDataModel = (BattlegroundsEmoteDataModel)dataModel.Payload;
		if (battlegroundsEmoteDataModel == null || battlegroundsEmoteDataModel.EmoteDbiId == 0)
		{
			return;
		}
		m_draggedIndex = -1;
		DataModelList<BattlegroundsEmoteDataModel> emoteList = GetLoadoutDataModel().EmoteList;
		for (int i = 0; i < emoteList.Count; i++)
		{
			if (emoteList[i].EmoteDbiId == battlegroundsEmoteDataModel.EmoteDbiId)
			{
				m_draggedIndex = i;
				break;
			}
		}
		if (m_draggedIndex == -1)
		{
			Debug.LogError("Unable to determine which emote was dragged.");
		}
		else
		{
			CollectionInputMgr.Get().GrabBattlegroundsEmote(battlegroundsEmoteDataModel, CollectionUtils.BattlegroundsModeDraggableType.TrayEmote, null, m_nestedImageWidgets[m_draggedIndex]);
		}
	}

	private void OnEmoteMouseOver()
	{
		EventDataModel dataModel = m_widget.GetDataModel<EventDataModel>();
		if (dataModel == null)
		{
			Log.CollectionManager.PrintError("No event data model attached to BaconEmoteTray");
			return;
		}
		IConvertible value;
		if ((value = dataModel.Payload as IConvertible) != null)
		{
			m_hoveredEmoteIndex = Convert.ToInt32(value);
			return;
		}
		Log.CollectionManager.PrintError("Unrecognized event payload in OnEmoteMouseOver().");
		m_hoveredEmoteIndex = -1;
	}

	private void OnEmoteMouseOut()
	{
		EventDataModel dataModel = m_widget.GetDataModel<EventDataModel>();
		IConvertible value;
		if (dataModel == null)
		{
			Log.CollectionManager.PrintError("No event data model attached to BaconEmoteTray");
		}
		else if ((value = dataModel.Payload as IConvertible) != null)
		{
			if (Convert.ToInt32(value) == m_hoveredEmoteIndex)
			{
				m_hoveredEmoteIndex = -1;
			}
		}
		else
		{
			Log.CollectionManager.PrintError("Unrecognized event payload in OnEmoteMouseOver().");
		}
	}

	private void SwapEmoteDatamodels(int slot1, int slot2, BattlegroundsEmoteLoadoutDataModel dataModel)
	{
		if (slot1 < 0 || slot1 >= 6 || slot2 < 0 || slot2 >= 6)
		{
			Log.CollectionManager.PrintError("BaconEmoteTray - Attempted to swap emote at invalid index");
			return;
		}
		if (dataModel == null)
		{
			Log.CollectionManager.PrintError("BaconEmoteTray - Attempted to swap emote with null datamodel.");
			return;
		}
		BattlegroundsEmoteDataModel value = dataModel.EmoteList[slot1];
		dataModel.EmoteList[slot1] = dataModel.EmoteList[slot2];
		dataModel.EmoteList[slot2] = value;
		SetLoadoutDataModel(dataModel);
	}

	public BattlegroundsEmoteLoadoutDataModel GetLoadoutDataModel()
	{
		m_widget.GetDataModel(645, out var model);
		return model as BattlegroundsEmoteLoadoutDataModel;
	}

	public void ShuffleEmotePositions(List<int> newIndices)
	{
		for (int i = 0; i < m_emoteWidgets.Length; i++)
		{
			if (i != newIndices[i])
			{
				iTween.Stop(m_emoteWidgets[i].gameObject);
				m_emoteWidgets[i].transform.localPosition = m_emotePositions[newIndices[i]];
				iTween.MoveTo(m_emoteWidgets[i].gameObject, iTween.Hash("position", m_emotePositions[i], "time", m_shuffleTime, "easeType", m_shuffleEase, "islocal", true));
			}
		}
	}

	private bool IsShufflingEmotes()
	{
		Widget[] emoteWidgets = m_emoteWidgets;
		for (int i = 0; i < emoteWidgets.Length; i++)
		{
			if (iTween.Count(emoteWidgets[i].gameObject) > 0)
			{
				return true;
			}
		}
		return false;
	}
}
