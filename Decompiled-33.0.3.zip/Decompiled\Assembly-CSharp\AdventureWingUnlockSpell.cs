using UnityEngine;

public class AdventureWingUnlockSpell : MonoBehaviour
{
	[CustomEditField(Label = "Post Animation Unlock Delay")]
	public float m_UnlockDelay = 1f;
}
