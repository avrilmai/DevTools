using System.Collections;
using System.Text;
using Blizzard.T5.AssetManager;
using Hearthstone.UI;
using UnityEngine;

[CustomEditClass]
public class BaconHeroSkinInfoManager : BaconBaseSkinInfoManager
{
	private static readonly Vector3 HERO_POWER_START_SCALE = new Vector3(0.1f, 0.1f, 0.1f);

	private const float HERO_POWER_TWEEN_TIME = 0.5f;

	public GameObject m_heroPowerParent;

	public GameObject m_heroPowerStartBone;

	public GameObject m_defaultFrame;

	private GameObject m_frameMesh;

	private Actor m_heroActor;

	private Actor m_heroPowerActor;

	private static BaconHeroSkinInfoManager s_instance;

	private static bool s_isReadyingInstance;

	public static BaconHeroSkinInfoManager Get()
	{
		return s_instance;
	}

	public static void EnterPreviewWhenReady(CollectionCardVisual cardVisual)
	{
		BaconHeroSkinInfoManager baconHeroSkinInfoManager = Get();
		if (baconHeroSkinInfoManager != null)
		{
			baconHeroSkinInfoManager.EnterPreview(cardVisual);
			return;
		}
		if (s_isReadyingInstance)
		{
			Debug.LogWarning("BaconHeroSkinInfoManager:EnterPreviewWhenReady called while the info manager instance was being readied");
			return;
		}
		string assetString = "BaconHeroSkinInfoManager.prefab:5cf5b98d116cb2543b44577a4b5ab97c";
		Widget widget = WidgetInstance.Create(assetString);
		if (widget == null)
		{
			Debug.LogError("BaconHeroSkinInfoManager:EnterPreviewWhenReady failed to create widget instance");
			return;
		}
		s_isReadyingInstance = true;
		widget.RegisterReadyListener(delegate
		{
			s_instance = widget.GetComponentInChildren<BaconHeroSkinInfoManager>();
			s_isReadyingInstance = false;
			if (s_instance == null)
			{
				Debug.LogError("BaconHeroSkinInfoManager:EnterPreviewWhenReady created widget instance but failed to get BaconHeroSkinInfoManager component");
			}
			else
			{
				s_instance.EnterPreview(cardVisual);
			}
		});
	}

	public static bool IsLoadedAndShowingPreview()
	{
		if (!s_instance)
		{
			return false;
		}
		return s_instance.IsShowingPreview;
	}

	private void OnDestroy()
	{
		m_currentHeroCardDef?.Dispose();
		m_currentHeroCardDef = null;
		AssetHandle.SafeDispose(ref m_currentHeroGoldenAnimation);
		CancelPreview();
		s_instance = null;
	}

	public override void EnterPreview(CollectionCardVisual cardVisual)
	{
		if (m_animating)
		{
			return;
		}
		base.EnterPreview(cardVisual);
		if (m_currentEntityDef == null)
		{
			return;
		}
		string heroPowerCardIdFromHero = GameUtils.GetHeroPowerCardIdFromHero(m_currentEntityDef.GetCardId());
		SetHeroPower(heroPowerCardIdFromHero);
		m_heroActor = cardVisual.GetActor();
		if (m_heroActor != null && m_heroActor.HasCardDef)
		{
			LoadFrameMesh();
			if (m_heroActor != null && m_heroActor.LegendaryHeroSkinConfig != null)
			{
				string pickedLine = m_heroActor.LegendaryHeroSkinConfig.GetPickedLine();
				if (pickedLine != null)
				{
					SoundManager.Get().LoadAndPlay(pickedLine);
				}
			}
		}
		else
		{
			InstantiateFrameMesh(m_defaultFrame);
			StartCoroutine(WaitForCardDef());
		}
	}

	protected override void Awake()
	{
		base.Awake();
		AssetLoader.Get().InstantiatePrefab("BaconCollectionDetails_HeroPower.prefab:effbe7f7919e2f34b9535d11fe149d0f", OnHeroPowerActorLoaded, null, AssetLoadingOptions.IgnorePrefabPosition);
	}

	private IEnumerator WaitForCardDef()
	{
		while (m_heroActor != null && !m_heroActor.HasCardDef)
		{
			yield return null;
		}
		LoadFrameMesh();
	}

	private void LoadFrameMesh()
	{
		if (!(m_heroActor == null))
		{
			DefLoader.DisposableCardDef disposableCardDef = m_heroActor.ShareDisposableCardDef();
			if (disposableCardDef != null && disposableCardDef.CardDef.m_FrameMeshOverride != null)
			{
				InstantiateFrameMesh(disposableCardDef.CardDef.m_FrameMeshOverride);
			}
			else
			{
				InstantiateFrameMesh(m_defaultFrame);
			}
		}
	}

	private void InstantiateFrameMesh(GameObject frameObject)
	{
		if (m_frameMesh != null)
		{
			Object.Destroy(m_frameMesh);
		}
		m_frameMesh = Object.Instantiate(frameObject, m_vanillaHeroFrame.transform);
		LayerUtils.SetLayer(m_frameMesh, GameLayer.IgnoreFullScreenEffects);
	}

	private void OnHeroPowerActorLoaded(AssetReference assetRef, GameObject go, object callbackData)
	{
		if (go == null)
		{
			Log.CollectionManager.PrintError($"CollectionDeckInfo.OnHeroPowerActorLoaded() - FAILED to load actor \"{assetRef}\"");
			return;
		}
		m_heroPowerActor = go.GetComponent<Actor>();
		if (m_heroPowerActor == null)
		{
			Log.CollectionManager.PrintError($"BaconHeroSkinInfoManager.OnHeroPowerActorLoaded() - ERROR actor \"{assetRef}\" has no Actor component");
			return;
		}
		m_heroPowerActor.SetUnlit();
		m_heroPowerActor.transform.parent = m_heroPowerParent.transform;
		RecursivelyCopyLayer(m_heroPowerParent, go);
		m_heroPowerActor.transform.localScale = Vector3.one;
		m_heroPowerActor.transform.localPosition = Vector3.zero;
		go.GetComponent<TokyoDrift>().enabled = true;
		if (UniversalInputManager.Get().IsTouchMode())
		{
			m_heroPowerActor.TurnOffCollider();
		}
	}

	private void RecursivelyCopyLayer(GameObject source, GameObject dest)
	{
		dest.layer = source.layer;
		foreach (Transform item in dest.transform)
		{
			RecursivelyCopyLayer(dest, item.gameObject);
		}
	}

	private void SetHeroPower(string heroPowerCardId)
	{
		DefLoader.Get().LoadFullDef(heroPowerCardId, OnHeroPowerFullDefLoaded);
	}

	private void OnHeroPowerFullDefLoaded(string cardID, DefLoader.DisposableFullDef def, object userData)
	{
		StartCoroutine(SetHeroPowerInfoWhenReady(cardID, def, TAG_PREMIUM.NORMAL));
	}

	private IEnumerator SetHeroPowerInfoWhenReady(string heroPowerCardID, DefLoader.DisposableFullDef def, TAG_PREMIUM premium)
	{
		using (def)
		{
			while (m_heroPowerActor == null)
			{
				yield return null;
			}
			SetHeroPowerInfo(heroPowerCardID, def, premium);
		}
	}

	private void SetHeroPowerInfo(string heroPowerCardID, DefLoader.DisposableFullDef def, TAG_PREMIUM premium)
	{
		m_heroPowerActor.Show();
		m_heroPowerActor.SetFullDef(def);
		m_heroPowerActor.UpdateAllComponents();
		m_heroPowerActor.ActivateSpellBirthState(SpellType.COIN_MANA_GEM);
		m_heroPowerActor.SetUnlit();
		Transform obj = m_heroPowerParent.transform;
		Vector3 localPosition = obj.localPosition;
		Vector3 localScale = obj.localScale;
		obj.position = m_heroPowerStartBone.transform.position;
		obj.localScale = HERO_POWER_START_SCALE;
		iTween.MoveTo(m_heroPowerParent, iTween.Hash("position", localPosition, "isLocal", true, "time", 0.5f));
		iTween.ScaleTo(m_heroPowerParent, iTween.Hash("scale", localScale, "isLocal", true, "time", 0.5f));
	}

	protected override void PushNavigateBack()
	{
		Navigation.PushUnique(OnNavigateBack);
	}

	protected override void RemoveNavigateBack()
	{
		Navigation.RemoveHandler(OnNavigateBack);
	}

	private static bool OnNavigateBack()
	{
		BaconHeroSkinInfoManager baconHeroSkinInfoManager = Get();
		if (baconHeroSkinInfoManager != null)
		{
			baconHeroSkinInfoManager.CancelPreview();
		}
		return true;
	}

	protected override void SetFavoriteHero()
	{
		int num = GameUtils.TranslateCardIdToDbId(m_currentEntityDef.GetCardId());
		if (CollectionManager.Get().IsBattlegroundsBaseHeroCardWithSkin(num) && CollectionManager.Get().GetFavoriteBattlegroundsHeroSkin(num, out var favoriteSkinId))
		{
			Network.Get().ClearBattlegroundsFavoriteHeroSkin(favoriteSkinId);
		}
		if (CollectionManager.Get().IsBattlegroundsHeroSkinCard(num) && CollectionManager.Get().GetBattlegroundsHeroSkinIdForSkinCardId(num, out var skinId))
		{
			Network.Get().SetBattlegroundsFavoriteHeroSkin(skinId);
		}
	}

	protected override bool CanToggleFavorite()
	{
		return BaconHeroSkinUtils.CanFavoriteBattlegroundsHeroSkin(m_currentEntityDef);
	}

	protected override void AppendDebugTextForCurrentCard(StringBuilder builder)
	{
		base.AppendDebugTextForCurrentCard(builder);
		int skinCardId = GameUtils.TranslateCardIdToDbId(m_currentEntityDef.GetCardId());
		if (CollectionManager.Get().GetBattlegroundsHeroSkinIdForSkinCardId(skinCardId, out var skinId))
		{
			builder.Append("Hero Skin Id: ");
			builder.Append(skinId.ToValue());
			builder.AppendLine();
		}
		else
		{
			builder.AppendLine("No Hero Skin Id");
		}
	}
}
