using System.Collections.Generic;
using UnityEngine;

public class AchievementSectionItemDbfAsset : ScriptableObject
{
	public List<AchievementSectionItemDbfRecord> Records = new List<AchievementSectionItemDbfRecord>();
}
