using UnityEngine;

public class AudioSourceSettings
{
	public bool m_bypassEffects;

	public bool m_loop;

	public int m_priority;

	public float m_volume;

	public float m_pitch;

	public float m_stereoPan;

	public float m_spatialBlend;

	public float m_reverbZoneMix;

	public AudioRolloffMode m_rolloffMode;

	public float m_dopplerLevel;

	public float m_minDistance;

	public float m_maxDistance;

	public float m_spread;

	public AudioSourceSettings()
	{
		LoadDefaults();
	}

	public void LoadDefaults()
	{
		m_bypassEffects = false;
		m_loop = false;
		m_priority = 128;
		m_volume = 1f;
		m_pitch = 1f;
		m_stereoPan = 0f;
		m_spatialBlend = 1f;
		m_reverbZoneMix = 1f;
		m_rolloffMode = AudioRolloffMode.Linear;
		m_dopplerLevel = 1f;
		m_minDistance = 100f;
		m_maxDistance = 500f;
		m_spread = 0f;
	}
}
