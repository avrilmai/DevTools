public enum AspectRatio
{
	Unknown,
	_1x1,
	_5x4,
	_4x3,
	_3x2,
	_16x10,
	_16x9,
	_21x9,
	ExtraWide
}
