using System.Collections.Generic;
using UnityEngine;

public class AdventureDataDbfAsset : ScriptableObject
{
	public List<AdventureDataDbfRecord> Records = new List<AdventureDataDbfRecord>();
}
