using UnityEngine;

public class BigCardTooltipDisplayBones : MonoBehaviour
{
	public enum BoneVerification
	{
		PRIMARY_ONLY,
		ALL_BONES
	}

	public GameObject_MobileOverride m_BoneRigs;

	public TooltipBoneLayout GetRigForCurrentPlatform()
	{
		if (m_BoneRigs == null)
		{
			return null;
		}
		GameObject valueForScreen = m_BoneRigs.GetValueForScreen(PlatformSettings.Screen, null);
		if (valueForScreen == null)
		{
			return null;
		}
		TooltipBoneLayout component = valueForScreen.GetComponent<TooltipBoneLayout>();
		if (component == null)
		{
			return null;
		}
		return component;
	}

	public bool HasBonesForCurrentPlatform(BoneVerification bonesToCheck)
	{
		TooltipBoneLayout rigForCurrentPlatform = GetRigForCurrentPlatform();
		if (rigForCurrentPlatform == null)
		{
			return false;
		}
		if (bonesToCheck == BoneVerification.PRIMARY_ONLY)
		{
			return rigForCurrentPlatform.HasPrimaryBones();
		}
		return rigForCurrentPlatform.HasAllBones();
	}
}
