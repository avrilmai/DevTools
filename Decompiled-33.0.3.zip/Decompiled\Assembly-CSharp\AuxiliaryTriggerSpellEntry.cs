using System;

[Serializable]
public class AuxiliaryTriggerSpellEntry
{
	public GAME_TAG m_TriggerKeyword;

	public Spell m_Spell;
}
