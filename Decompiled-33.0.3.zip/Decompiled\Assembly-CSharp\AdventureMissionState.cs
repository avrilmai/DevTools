public enum AdventureMissionState
{
	LOCKED,
	UNLOCKED,
	COMPLETED
}
