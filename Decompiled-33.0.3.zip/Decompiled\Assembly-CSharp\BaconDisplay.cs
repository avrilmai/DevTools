using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Assets;
using Blizzard.GameService.SDK.Client.Integration;
using Blizzard.T5.Core.Utils;
using Hearthstone.Commerce;
using Hearthstone.DataModels;
using Hearthstone.Progression;
using Hearthstone.UI;
using PegasusShared;
using UnityEngine;

[RequireComponent(typeof(WidgetTemplate))]
public class BaconDisplay : AbsSceneDisplay
{
	public AsyncReference m_PlayButtonReference;

	public AsyncReference m_PlayButtonPhoneReference;

	public AsyncReference m_BackButtonReference;

	public AsyncReference m_BackButtonPhoneReference;

	public AsyncReference m_StatsButtonReference;

	public AsyncReference m_StatsButtonPhoneReference;

	public AsyncReference m_StatsPageReference;

	public AsyncReference m_StatsPagePhoneReference;

	public AsyncReference m_luckyDrawButtonReference;

	public AsyncReference m_LobbyReference;

	public AsyncReference m_PartyReference;

	public AsyncReference m_LobbyPhoneReference;

	public AsyncReference m_PartyPhoneReference;

	public Transform m_OffScreenBonePC;

	public Transform m_OnScreenBonePC;

	public Transform m_OffScreenBoneMobile;

	public Transform m_OnScreenBoneMobile;

	private bool m_playButtonFinishedLoading;

	private bool m_backButtonFinishedLoading;

	private bool m_statsButtonFinishedLoading;

	private bool m_luckyDrawButtonFinishedLoading;

	private bool m_partyFinishedLoading;

	private bool m_partyPhoneFinishedLoading;

	private WidgetTemplate m_OwningWidget;

	private PlayButton m_playButton;

	private UIBButton m_statsButton;

	private Clickable m_statsButtonClickable;

	private LuckyDrawButton m_luckyDrawButton;

	private RewardPresenter m_rewardPresenter = new RewardPresenter();

	private const float LUCKY_DRAW_BUTTON_FANFARE_FX_DELAY_SEC = 0.5f;

	private const string LUCKY_DRAW_NEW_HAMMER_FX = "NewHammerFX";

	private const string LUCKY_DRAW_NEW_HAMMER_ANIM = "LuckyDrawNewHammer_Anim";

	private Notification m_luckyDrawFTUENotification;

	private const float LUCKY_DRAW_FTUE_POPUP_DELAY_SEC = 4f;

	private const string FTUE_TOOLTIP_BONE = "FTUETooltip";

	private readonly PlatformDependentValue<string> PLATFORM_DEPENDENT_BONE_SUFFIX = new PlatformDependentValue<string>(PlatformCategory.Screen)
	{
		PC = "PC",
		Tablet = "PC",
		Phone = "Mobile"
	};

	private readonly PlatformDependentValue<bool> ShowLowMemoryWarning = new PlatformDependentValue<bool>(PlatformCategory.Memory)
	{
		LowMemory = true,
		MediumMemory = true,
		HighMemory = false
	};

	private const int PAST_GAMES_TO_SHOW = 5;

	private const int MINIONS_PER_BOARD = 7;

	private const string OPEN_SHOP_EVENT = "OpenShop";

	private const string OPEN_COLLECTION_EVENT = "OpenCollection";

	private const string STATS_PANEL_SLIDE_COMPLETE = "CODE_STATS_SLIDE_FINISHED";

	private const string STATS_PANEL_PHONE_SLIDE_COMPLETE = "CODE_STATS_PHONE_SLIDE_FINISHED";

	private static bool m_hasSeenLowMemoryWarningThisSession;

	private void Awake()
	{
		InitSlidingTray();
		RegisterListeners();
		m_OwningWidget = GetComponent<WidgetTemplate>();
	}

	public override void Start()
	{
		base.Start();
		LuckyDrawManager.Get().InitializeOrUpdateData();
		m_PlayButtonReference.RegisterReadyListener<VisualController>(OnPlayButtonReady);
		m_BackButtonReference.RegisterReadyListener<VisualController>(OnBackButtonReady);
		m_PlayButtonPhoneReference.RegisterReadyListener<VisualController>(OnPlayButtonReady);
		m_BackButtonPhoneReference.RegisterReadyListener<VisualController>(OnBackButtonReady);
		m_StatsButtonReference.RegisterReadyListener<VisualController>(OnStatsButtonReady);
		m_StatsButtonPhoneReference.RegisterReadyListener<VisualController>(OnStatsButtonReady);
		m_StatsPageReference.RegisterReadyListener<VisualController>(OnStatsPagePCReady);
		m_StatsPagePhoneReference.RegisterReadyListener<VisualController>(OnStatsPagePhoneReady);
		m_LobbyReference.RegisterReadyListener<Widget>(OnLobbyPCReady);
		m_LobbyPhoneReference.RegisterReadyListener<Widget>(OnLobbyPhoneReady);
		m_LobbyReference.RegisterReadyListener<Widget>(OnPartyPCReady);
		m_LobbyPhoneReference.RegisterReadyListener<Widget>(OnPartyPhoneReady);
		m_luckyDrawButtonReference.RegisterReadyListener<WidgetTemplate>(OnLuckyDrawButtonReady);
		NetCache.Get().RegisterScreenBattlegrounds(OnNetCacheReady);
		PartyManager.Get().AddChangedListener(OnPartyChanged);
		InitializeBaconLobbyData();
		NarrativeManager.Get().OnBattlegroundsEntered();
		MusicManager.Get().StartPlaylist(MusicPlaylistType.UI_Battlegrounds);
		PresenceMgr.Get().SetStatus(Global.PresenceStatus.BATTLEGROUNDS_SCREEN);
		StoreManager.Get().RegisterStatusChangedListener(OnStoreStatusChanged);
	}

	private void OnDestroy()
	{
		HideLuckyDrawFTUENotification();
		UnregisterListeners();
	}

	private void BaconDisplayEventListener(string eventName)
	{
		switch (eventName)
		{
		case "OpenShop":
			HideLuckyDrawFTUENotification();
			OpenBattlegroundsShop();
			break;
		case "OpenCollection":
			HideLuckyDrawFTUENotification();
			OpenBattlegroundsCollection();
			break;
		case "CODE_STATS_SLIDE_FINISHED":
			StatsPanelFinishedLoading();
			break;
		case "CODE_STATS_PHONE_SLIDE_FINISHED":
			StatsPanelPhoneFinishedLoading();
			break;
		}
	}

	private void OnPartyPCReady(Widget widget)
	{
		if (SceneMgr.Get().GetPrevMode() == SceneMgr.Mode.HUB || (bool)UniversalInputManager.UsePhoneUI)
		{
			m_partyFinishedLoading = true;
		}
		else
		{
			m_partyFinishedLoading = false;
		}
	}

	private void OnPartyPhoneReady(Widget widget)
	{
		if (SceneMgr.Get().GetPrevMode() == SceneMgr.Mode.HUB || !UniversalInputManager.UsePhoneUI)
		{
			m_partyPhoneFinishedLoading = true;
		}
		else
		{
			m_partyPhoneFinishedLoading = false;
		}
	}

	private void StatsPanelFinishedLoading()
	{
		m_partyFinishedLoading = true;
	}

	private void OnLuckyDrawExpired()
	{
		if (SceneMgr.Get().GetMode() == SceneMgr.Mode.BACON && m_luckyDrawButton != null)
		{
			m_luckyDrawButton.gameObject.SetActive(value: false);
			StartCoroutine(WaitThenShowLuckDrawEndPopupIfExistsUnusedHammers());
		}
	}

	private IEnumerator WaitThenShowLuckDrawEndPopupIfExistsUnusedHammers()
	{
		LuckyDrawManager luckyDrawManager = LuckyDrawManager.Get();
		while (luckyDrawManager.IsDataDirty())
		{
			yield return new WaitForSeconds(0.1f);
		}
		if (luckyDrawManager.GetBattlegroundsLuckyDrawDataModel().Hammers > 0)
		{
			AlertPopup.PopupInfo popupInfo = new AlertPopup.PopupInfo();
			popupInfo.m_headerText = GameStrings.Get("GLUE_BATTLEBASH_ALERT_EVENT_END_TITLE");
			popupInfo.m_text = GameStrings.Get("GLUE_BATTLEBASH_ALERT_EVENT_END_DESCRIPTION");
			popupInfo.m_iconSet = AlertPopup.PopupInfo.IconSet.Default;
			popupInfo.m_showAlertIcon = true;
			popupInfo.m_alertTextAlignment = UberText.AlignmentOptions.Center;
			popupInfo.m_responseDisplay = AlertPopup.ResponseDisplay.OK;
			popupInfo.m_responseCallback = delegate
			{
				SetNextModeAndHandleTransition(SceneMgr.Mode.HUB, SceneMgr.TransitionHandlerType.NEXT_SCENE);
			};
			DialogManager.Get().ShowPopup(popupInfo);
		}
	}

	private void StatsPanelPhoneFinishedLoading()
	{
		m_partyPhoneFinishedLoading = true;
	}

	public void OnPlayButtonReady(VisualController buttonVisualController)
	{
		if (buttonVisualController == null)
		{
			Error.AddDevWarning("UI Error!", "PlayButton could not be found! You will not be able to click 'Play'!");
			return;
		}
		m_playButton = buttonVisualController.gameObject.GetComponent<PlayButton>();
		m_playButton.AddEventListener(UIEventType.RELEASE, PlayButtonRelease);
		UpdatePlayButtonBasedOnPartyInfo();
		m_playButtonFinishedLoading = true;
	}

	public void OnBackButtonReady(VisualController buttonVisualController)
	{
		if (buttonVisualController == null)
		{
			Error.AddDevWarning("UI Error!", "BackButton could not be found! You will not be able to click 'Back'!");
			return;
		}
		buttonVisualController.gameObject.GetComponent<UIBButton>().AddEventListener(UIEventType.RELEASE, BackButtonRelease);
		m_backButtonFinishedLoading = true;
	}

	public void OnStatsButtonReady(VisualController buttonVisualController)
	{
		if (buttonVisualController == null)
		{
			Error.AddDevWarning("UI Error!", "StatsButton could not be found! You will not be able to show 'Stats'!");
			return;
		}
		m_statsButton = buttonVisualController.gameObject.GetComponent<UIBButton>();
		m_statsButtonClickable = buttonVisualController.gameObject.GetComponent<Clickable>();
		UpdateStatsButtonState();
		m_statsButtonFinishedLoading = true;
	}

	public void OnLuckyDrawButtonReady(WidgetTemplate button)
	{
		if (button == null)
		{
			Error.AddDevWarning("UI Error!", "Lucky Draw Button could not be found! Cant show Lucky Draw button!");
			return;
		}
		m_luckyDrawButton = button.GetComponentInChildren<LuckyDrawButton>();
		WidgetTemplate component = m_luckyDrawButton.GetComponent<WidgetTemplate>();
		if (component == null)
		{
			Error.AddDevWarning("UI Error!", "Could not find widget component of Lucky Draw button! Cant show lucky Draw button!");
			return;
		}
		component.RegisterEventListener(delegate(string eventName)
		{
			if (eventName == "BUTTON_CLICKED")
			{
				LuckyDrawButtonClicked();
			}
		});
		m_luckyDrawButtonFinishedLoading = true;
		StartCoroutine("WaitThenShowLuckyDrawFTUEIfNeeded");
	}

	private IEnumerator WaitThenShowLuckyDrawFTUEIfNeeded()
	{
		yield return new WaitForSeconds(4f);
		LuckyDrawManager luckyDrawManager = LuckyDrawManager.Get();
		while (luckyDrawManager.IsDataDirty())
		{
			yield return new WaitForSeconds(0.1f);
		}
		GameSaveDataManager.Get().GetSubkeyValue(GameSaveKeyId.FTUE, GameSaveKeySubkeyId.FTUE_HAS_SEEN_BATTLE_BASH_BUTTON_TOOLTIP, out long value);
		if (!luckyDrawManager.GetLuckyDrawButtonDataModel().IsEventExpired && value <= 0)
		{
			ShowLuckyDrawFTUENotification();
		}
	}

	private void ShowLuckyDrawFTUENotification()
	{
		string key = GameStrings.Get("GLUE_BATTLEBASH_FTUE_HINT");
		GameObject gameObject = GameObjectUtils.FindChildBySubstring(m_luckyDrawButton.gameObject, "FTUETooltip" + PLATFORM_DEPENDENT_BONE_SUFFIX);
		if (gameObject == null)
		{
			Log.All.PrintWarning("[BaconDisplay.ShowLuckyDrawFTUENotifiation] - Popup bone is missing");
			return;
		}
		NotificationManager notificationManager = NotificationManager.Get();
		if ((bool)UniversalInputManager.UsePhoneUI)
		{
			m_luckyDrawFTUENotification = notificationManager.CreatePopupText(UserAttentionBlocker.NONE, gameObject.transform.position, gameObject.transform.localScale, GameStrings.Get(key));
		}
		else
		{
			m_luckyDrawFTUENotification = notificationManager.CreatePopupText(UserAttentionBlocker.NONE, gameObject.transform.position, gameObject.transform.localScale, GameStrings.Get(key));
		}
		m_luckyDrawFTUENotification.ShowPopUpArrow(Notification.PopUpArrowDirection.Up);
	}

	private void HideLuckyDrawFTUENotification(bool animate = false)
	{
		StopCoroutine("WaitThenShowLuckyDrawFTUEIfNeeded");
		if (!(m_luckyDrawFTUENotification == null))
		{
			if (animate)
			{
				NotificationManager.Get()?.DestroyNotification(m_luckyDrawFTUENotification, 0f);
			}
			else
			{
				NotificationManager.Get()?.DestroyNotificationNowWithNoAnim(m_luckyDrawFTUENotification);
			}
		}
	}

	private void LuckyDrawButtonClicked()
	{
		SetNextModeAndHandleTransition(SceneMgr.Mode.LUCKY_DRAW, SceneMgr.TransitionHandlerType.CURRENT_SCENE);
		HideLuckyDrawFTUENotification();
		m_luckyDrawButton.SetUserInteractionEnabled(enabled: false);
	}

	private void UpdateStatsButtonState()
	{
		if (!(m_statsButton == null) && !(m_statsButtonClickable == null))
		{
			bool flag = HasAccessToStatsPage();
			m_statsButton.Flip(flag, forceImmediate: true);
			m_statsButton.SetEnabled(flag);
			m_statsButton.AddEventListener(UIEventType.RELEASE, OnStatsButtonReleased);
			m_statsButtonClickable.Active = flag;
		}
	}

	private void OnStatsButtonReleased(UIEvent e)
	{
		HideLuckyDrawFTUENotification();
	}

	public void PlayButtonRelease(UIEvent e)
	{
		HideLuckyDrawFTUENotification();
		if (BattleNet.IsConnected() && !GameMgr.Get().IsFindingGame())
		{
			PresenceMgr.Get().SetStatus(Global.PresenceStatus.BATTLEGROUNDS_QUEUE);
			bool flag = !NetCache.Get().GetNetObject<NetCache.NetCacheFeatures>().Games.BattlegroundsTutorial;
			GameSaveDataManager.Get().GetSubkeyValue(GameSaveKeyId.BACON, GameSaveKeySubkeyId.BACON_HAS_SEEN_TUTORIAL, out long value);
			PartyManager partyManager = PartyManager.Get();
			if (partyManager.IsInParty() && partyManager.IsInBattlegroundsParty() && partyManager.IsPartyLeader())
			{
				partyManager.FindGame();
			}
			else if (value == 0L && !flag)
			{
				PlayBaconTutorial();
			}
			else
			{
				GameMgr.Get().FindGame(GameType.GT_BATTLEGROUNDS, FormatType.FT_WILD, 3459, 0, 0L, null, null, restoreSavedGameState: false, null, null, 0L);
			}
		}
	}

	public void PlayBaconTutorial()
	{
		GameMgr.Get().FindGame(GameType.GT_VS_AI, FormatType.FT_WILD, 3539, 0, 0L, null, null, restoreSavedGameState: false, null, null, 0L);
	}

	public void BackButtonRelease(UIEvent e)
	{
		HideLuckyDrawFTUENotification();
		if (PartyManager.Get().IsInBattlegroundsParty())
		{
			ShowLeavePartyDialog();
		}
		else
		{
			SceneMgr.Get().SetNextMode(SceneMgr.Mode.HUB);
		}
	}

	private void ShowLeavePartyDialog()
	{
		AlertPopup.PopupInfo popupInfo = new AlertPopup.PopupInfo();
		popupInfo.m_headerText = GameStrings.Get("GLUE_BACON_LEAVE_PARTY_CONFIRMATION_HEADER");
		popupInfo.m_text = (PartyManager.Get().IsPartyLeader() ? GameStrings.Get("GLUE_BACON_DISBAND_PARTY_CONFIRMATION_BODY") : GameStrings.Get("GLUE_BACON_LEAVE_PARTY_CONFIRMATION_BODY"));
		popupInfo.m_iconSet = AlertPopup.PopupInfo.IconSet.Default;
		popupInfo.m_showAlertIcon = false;
		popupInfo.m_alertTextAlignment = UberText.AlignmentOptions.Center;
		popupInfo.m_responseDisplay = AlertPopup.ResponseDisplay.CONFIRM_CANCEL;
		popupInfo.m_confirmText = GameStrings.Get("GLUE_BACON_LEAVE_PARTY_CONFIRMATION_CONFIRM");
		popupInfo.m_cancelText = GameStrings.Get("GLUE_BACON_LEAVE_PARTY_CONFIRMATION_CANCEL");
		popupInfo.m_responseCallback = delegate(AlertPopup.Response response, object userData)
		{
			if (response == AlertPopup.Response.CONFIRM)
			{
				BaconParty.Get().LeaveParty();
				SceneMgr.Get().SetNextMode(SceneMgr.Mode.HUB);
			}
		};
		DialogManager.Get().ShowPopup(popupInfo);
	}

	private void OnNetCacheReady()
	{
		NetCache.Get().UnregisterNetCacheHandler(OnNetCacheReady);
		if (!NetCache.Get().GetNetObject<NetCache.NetCacheFeatures>().Games.Battlegrounds && !SceneMgr.Get().IsModeRequested(SceneMgr.Mode.HUB))
		{
			SceneMgr.Get().SetNextMode(SceneMgr.Mode.HUB);
			Error.AddWarningLoc("GLOBAL_FEATURE_DISABLED_TITLE", "GLOBAL_FEATURE_DISABLED_MESSAGE_BATTLEGROUNDS");
		}
	}

	private void OnStatsPagePCReady(VisualController visualController)
	{
		if (!UniversalInputManager.UsePhoneUI)
		{
			if (visualController == null)
			{
				Error.AddDevWarning("UI Error!", "StatsPage could not be found! You will not be able to view stats!");
			}
			else
			{
				InitializeBaconStatsPageData(visualController);
			}
		}
	}

	private void OnStatsPagePhoneReady(VisualController visualController)
	{
		if ((bool)UniversalInputManager.UsePhoneUI)
		{
			if (visualController == null)
			{
				Error.AddDevWarning("UI Error!", "StatsPage could not be found! You will not be able to view stats!");
			}
			else
			{
				InitializeBaconStatsPageData(visualController);
			}
		}
	}

	private void OnLobbyPCReady(Widget widget)
	{
		if (!UniversalInputManager.UsePhoneUI)
		{
			if (widget == null)
			{
				Error.AddDevWarning("UI Error!", "LobbyReference could not be found!");
				return;
			}
			widget.RegisterEventListener(BaconDisplayEventListener);
			StartCoroutine(ShowBattlegroundsUnacknowledgedHammersPopUp());
		}
	}

	private void OnLobbyPhoneReady(Widget widget)
	{
		if ((bool)UniversalInputManager.UsePhoneUI)
		{
			if (widget == null)
			{
				Error.AddDevWarning("UI Error!", "LobbyReference could not be found!");
				return;
			}
			widget.RegisterEventListener(BaconDisplayEventListener);
			StartCoroutine(ShowBattlegroundsUnacknowledgedHammersPopUp());
		}
	}

	public BaconLobbyDataModel GetBaconLobbyDataModel()
	{
		VisualController component = GetComponent<VisualController>();
		if (component == null)
		{
			return null;
		}
		Widget owner = component.Owner;
		if (!owner.GetDataModel(43, out var model))
		{
			model = new BaconLobbyDataModel();
			owner.BindDataModel(model);
		}
		return model as BaconLobbyDataModel;
	}

	private void InitializeBaconLobbyData()
	{
		BaconLobbyDataModel baconLobbyDataModel = GetBaconLobbyDataModel();
		if (baconLobbyDataModel != null)
		{
			NetCache.NetCacheBaconRatingInfo netObject = NetCache.Get().GetNetObject<NetCache.NetCacheBaconRatingInfo>();
			if (netObject != null)
			{
				baconLobbyDataModel.Rating = netObject.Rating;
			}
			else
			{
				Log.Net.PrintError("No bacon rating info in NetCache.");
			}
			baconLobbyDataModel.Top4Finishes = (int)GetBaconGameSaveValue(GameSaveKeySubkeyId.BACON_TOP_4_FINISHES);
			baconLobbyDataModel.FirstPlaceFinishes = (int)GetBaconGameSaveValue(GameSaveKeySubkeyId.BACON_FIRST_PLACE_FINISHES);
			baconLobbyDataModel.ShopOpen = StoreManager.Get().IsOpen();
			NetCache.NetCacheFeatures netObject2 = NetCache.Get().GetNetObject<NetCache.NetCacheFeatures>();
			baconLobbyDataModel.BattlegroundsSkinsEnabled = netObject2.BattlegroundsSkinsEnabled;
			baconLobbyDataModel.BattlegroundsRewardTrackEnabled = netObject2.BattlegroundsRewardTrackEnabled;
			baconLobbyDataModel.HasNewProducts = HasNewBattlegroundsProducts();
			baconLobbyDataModel.HasNewSkins = CollectionManager.Get().HasAnyNewBattlegroundsSkins();
		}
	}

	private void RegisterListeners()
	{
		GameMgr.Get().RegisterFindGameEvent(OnFindGameEvent);
		NetCache.Get().OwnedBattlegroundsSkinsChanged += RefreshHasAnyNewSkins;
		GameMgr.Get().OnTransitionPopupShown += OnTransitionPopupShown;
		BnetPresenceMgr.Get().AddPlayersChangedListener(OnPresenceUpdated);
		BnetNearbyPlayerMgr.Get().AddChangeListener(OnNearbyPlayersUpdated);
		LuckyDrawManager.Get().RegisterOnEventEndsListeners(OnLuckyDrawExpired);
	}

	private void UnregisterListeners()
	{
		if (GameMgr.Get() != null)
		{
			GameMgr.Get().UnregisterFindGameEvent(OnFindGameEvent);
			GameMgr.Get().OnTransitionPopupShown -= OnTransitionPopupShown;
		}
		if (NetCache.Get() != null)
		{
			NetCache.Get().OwnedBattlegroundsSkinsChanged -= RefreshHasAnyNewSkins;
		}
		if (PartyManager.Get() != null)
		{
			PartyManager.Get().RemoveChangedListener(OnPartyChanged);
		}
		if (BnetPresenceMgr.Get() != null)
		{
			BnetPresenceMgr.Get().RemovePlayersChangedListener(OnPresenceUpdated);
		}
		if (BnetNearbyPlayerMgr.Get() != null)
		{
			BnetNearbyPlayerMgr.Get().RemoveChangeListener(OnNearbyPlayersUpdated);
		}
		if (StoreManager.Get() != null)
		{
			StoreManager.Get().RemoveStatusChangedListener(OnStoreStatusChanged);
		}
		if (LuckyDrawManager.Get() != null)
		{
			LuckyDrawManager.Get().RemoveOnEventEndsListenders(OnLuckyDrawExpired);
		}
	}

	private bool OnFindGameEvent(FindGameEventData eventData, object userData)
	{
		FindGameState state = eventData.m_state;
		if ((uint)(state - 2) <= 1u || (uint)(state - 7) <= 1u || state == FindGameState.SERVER_GAME_CANCELED)
		{
			PresenceMgr.Get().SetStatus(Global.PresenceStatus.BATTLEGROUNDS_SCREEN);
			UpdatePlayButtonBasedOnPartyInfo();
		}
		return false;
	}

	private void OnTransitionPopupShown()
	{
		Shop.Get().Close();
		DialogManager.Get().ClearAllImmediately();
	}

	private void ShowLowMemoryAlertMessage()
	{
		if ((bool)ShowLowMemoryWarning && !m_hasSeenLowMemoryWarningThisSession)
		{
			m_hasSeenLowMemoryWarningThisSession = true;
			AlertPopup.PopupInfo info = new AlertPopup.PopupInfo
			{
				m_headerText = GameStrings.Get("GLUE_BACON_LOW_MEMORY_HEADER"),
				m_text = GameStrings.Get("GLUE_BACON_LOW_MEMORY_BODY"),
				m_showAlertIcon = true,
				m_responseDisplay = AlertPopup.ResponseDisplay.OK
			};
			DialogManager.Get().ShowPopup(info);
		}
	}

	public BaconStatsPageDataModel GetBaconStatsPageDataModel(VisualController visualController)
	{
		if (visualController == null)
		{
			return null;
		}
		Widget owner = visualController.Owner;
		if (!owner.GetDataModel(122, out var model))
		{
			model = new BaconStatsPageDataModel();
			owner.BindDataModel(model);
		}
		return model as BaconStatsPageDataModel;
	}

	private void InitializeBaconStatsPageData(VisualController visualController)
	{
		BaconStatsPageDataModel dataModel = GetBaconStatsPageDataModel(visualController);
		if (dataModel == null)
		{
			return;
		}
		dataModel.Top4Finishes = (int)GetBaconGameSaveValue(GameSaveKeySubkeyId.BACON_TOP_4_FINISHES);
		dataModel.FirstPlaceFinishes = (int)GetBaconGameSaveValue(GameSaveKeySubkeyId.BACON_FIRST_PLACE_FINISHES);
		dataModel.TriplesCreated = (int)GetBaconGameSaveValue(GameSaveKeySubkeyId.BACON_TRIPLES_CREATED);
		dataModel.TavernUpgrades = (int)GetBaconGameSaveValue(GameSaveKeySubkeyId.BACON_TAVERN_UPGRADES);
		dataModel.DamageInOneTurn = (int)GetBaconGameSaveValue(GameSaveKeySubkeyId.BACON_MOST_DAMAGE_ONE_TURN);
		dataModel.LongestWinStreak = (int)GetBaconGameSaveValue(GameSaveKeySubkeyId.BACON_LONGEST_COMBAT_WIN_STREAK);
		dataModel.SecondsPlayed = (int)GetBaconGameSaveValue(GameSaveKeySubkeyId.BACON_TIME_PLAYED);
		List<long> baconGameSaveValueList = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_MINIONS_KILLED_COUNT);
		dataModel.MinionsDestroyed = (int)((baconGameSaveValueList != null) ? baconGameSaveValueList.Sum() : 0);
		List<long> baconGameSaveValueList2 = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_HEROES_KILLED_COUNT);
		dataModel.PlayersEliminated = (int)((baconGameSaveValueList2 != null) ? baconGameSaveValueList2.Sum() : 0);
		List<long> baconGameSaveValueList3 = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_LARGEST_MINION_ATTACK_HEALTH);
		dataModel.BiggestMinionId = ((baconGameSaveValueList3 == null || baconGameSaveValueList3.Count() < 3) ? null : new CardDataModel
		{
			CardId = GameUtils.TranslateDbIdToCardId((int)baconGameSaveValueList3[0]),
			Premium = TAG_PREMIUM.NORMAL
		});
		dataModel.BiggestMinionAttack = (int)((baconGameSaveValueList3 != null && baconGameSaveValueList3.Count() >= 3) ? baconGameSaveValueList3[1] : 0);
		dataModel.BiggestMinionHealth = (int)((baconGameSaveValueList3 != null && baconGameSaveValueList3.Count() >= 3) ? baconGameSaveValueList3[2] : 0);
		dataModel.BiggestMinionString = GameStrings.Format("GLUE_BACON_STATS_VALUE_BIGGEST_MINION", dataModel.BiggestMinionAttack, dataModel.BiggestMinionHealth);
		if (dataModel.SecondsPlayed > 3600)
		{
			dataModel.TimePlayedString = GameStrings.Format("GLUE_BACON_STATS_VALUE_HOURS_PLAYED", Mathf.FloorToInt(dataModel.SecondsPlayed / 3600));
		}
		else
		{
			dataModel.TimePlayedString = GameStrings.Format("GLUE_BACON_STATS_VALUE_MINUTES_PLAYED", Mathf.FloorToInt(dataModel.SecondsPlayed / 60));
		}
		List<KeyValuePair<long, long>> sortedListFromGameSaveDataLists = GetSortedListFromGameSaveDataLists(GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_BOUGHT_MINIONS), GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_BOUGHT_MINIONS_COUNT));
		dataModel.MostBoughtMinionsCardIds = new DataModelList<CardDataModel>();
		dataModel.MostBoughtMinionsCardIds.AddRange(sortedListFromGameSaveDataLists.Select((KeyValuePair<long, long> kvp) => new CardDataModel
		{
			CardId = GameUtils.TranslateDbIdToCardId((int)kvp.Key),
			Premium = TAG_PREMIUM.NORMAL
		}));
		dataModel.MostBoughtMinionsCount = new DataModelList<int>();
		dataModel.MostBoughtMinionsCount.AddRange(sortedListFromGameSaveDataLists.Select((KeyValuePair<long, long> kvp) => (int)kvp.Value));
		List<KeyValuePair<long, long>> sortedListFromGameSaveDataLists2 = GetSortedListFromGameSaveDataLists(GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_HEROES_WON_WITH), GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_HEROES_WON_WITH_COUNT));
		dataModel.TopHeroesByWinCardIds = new DataModelList<CardDataModel>();
		dataModel.TopHeroesByWinCardIds.AddRange(sortedListFromGameSaveDataLists2.Select((KeyValuePair<long, long> kvp) => new CardDataModel
		{
			CardId = CollectionManager.Get().GetFavoriteBattleGroundsHeroSkinCardId((int)kvp.Key),
			Premium = TAG_PREMIUM.NORMAL
		}));
		dataModel.TopHeroesByWinCount = new DataModelList<int>();
		dataModel.TopHeroesByWinCount.AddRange(sortedListFromGameSaveDataLists2.Select((KeyValuePair<long, long> kvp) => (int)kvp.Value));
		List<KeyValuePair<long, long>> sortedListFromGameSaveDataLists3 = GetSortedListFromGameSaveDataLists(GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_HEROES_PICKED), GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_HEROES_PICKED_COUNT));
		dataModel.TopHeroesByGamesPlayedCardIds = new DataModelList<CardDataModel>();
		dataModel.TopHeroesByGamesPlayedCardIds.AddRange(sortedListFromGameSaveDataLists3.Select((KeyValuePair<long, long> kvp) => new CardDataModel
		{
			CardId = CollectionManager.Get().GetFavoriteBattleGroundsHeroSkinCardId((int)kvp.Key),
			Premium = TAG_PREMIUM.NORMAL
		}));
		dataModel.TopHeroesByGamesPlayedCount = new DataModelList<int>();
		dataModel.TopHeroesByGamesPlayedCount.AddRange(sortedListFromGameSaveDataLists3.Select((KeyValuePair<long, long> kvp) => (int)kvp.Value));
		dataModel.PastGames = new DataModelList<BaconPastGameStatsDataModel>();
		List<long> baconGameSaveValueList4 = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_HEROES);
		List<long> baconGameSaveValueList5 = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_PLACES);
		List<long> baconGameSaveValueList6 = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_MINIONS_ID);
		List<long> baconGameSaveValueList7 = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_MINIONS_ATTACK);
		List<long> baconGameSaveValueList8 = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_MINIONS_HEALTH);
		List<long> baconGameSaveValueList9 = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_MINIONS_GOLDEN);
		List<long> tauntList = new List<long>();
		List<long> divineShieldList = new List<long>();
		List<long> poisonousList = new List<long>();
		List<long> windfuryList = new List<long>();
		List<long> rebornList = new List<long>();
		List<long> questIDList = new List<long>();
		List<long> rewardIDList = new List<long>();
		List<long> rewardIsCompletedList = new List<long>();
		List<long> rewardCardDatabaseIDList = new List<long>();
		List<long> rewardMinionTypeList = new List<long>();
		List<long> questProgressTotalList = new List<long>();
		List<long> questRace1List = new List<long>();
		List<long> questRace2List = new List<long>();
		PopulateAdditionalInfoLists(baconGameSaveValueList4?.Count ?? 0, ref tauntList, ref divineShieldList, ref poisonousList, ref windfuryList, ref rebornList, ref questIDList, ref rewardIDList, ref rewardIsCompletedList, ref rewardCardDatabaseIDList, ref rewardMinionTypeList, ref questProgressTotalList, ref questRace1List, ref questRace2List);
		List<BaconPastGameStatsDataModel> list = new List<BaconPastGameStatsDataModel>();
		for (int i = 0; i < 5; i++)
		{
			if (baconGameSaveValueList4 == null)
			{
				break;
			}
			if (i >= baconGameSaveValueList4.Count)
			{
				break;
			}
			if (i >= baconGameSaveValueList5.Count)
			{
				break;
			}
			string cardId = GameUtils.TranslateDbIdToCardId((int)baconGameSaveValueList4[i]);
			CardDataModel hero = new CardDataModel
			{
				CardId = CollectionManager.Get().GetFavoriteBattleGroundsHeroSkinCardId((int)baconGameSaveValueList4[i]),
				Premium = TAG_PREMIUM.NORMAL
			};
			CardDbfRecord cardRecord = GameUtils.GetCardRecord(cardId);
			string heroName = ((cardRecord == null) ? "" : ((string)cardRecord.Name));
			CardDataModel heroPower = new CardDataModel
			{
				CardId = GameUtils.GetHeroPowerCardIdFromHero((int)baconGameSaveValueList4[i]),
				Premium = TAG_PREMIUM.NORMAL,
				SpellTypes = new DataModelList<SpellType> { SpellType.COIN_MANA_GEM }
			};
			string cardId2 = GameUtils.TranslateDbIdToCardId((int)questIDList[i]);
			string cardId3 = GameUtils.TranslateDbIdToCardId((int)rewardIDList[i]);
			CardDataModel quest = new CardDataModel
			{
				CardId = cardId2,
				Premium = TAG_PREMIUM.NORMAL
			};
			CardDataModel reward = new CardDataModel
			{
				CardId = cardId3,
				Premium = TAG_PREMIUM.NORMAL
			};
			DataModelList<CardDataModel> dataModelList = new DataModelList<CardDataModel>();
			for (int j = 0; j < 7; j++)
			{
				int num = i * 7 + j;
				if (baconGameSaveValueList6.Count <= num || baconGameSaveValueList7.Count <= num || baconGameSaveValueList8.Count <= num || baconGameSaveValueList9.Count <= num || tauntList.Count <= num || divineShieldList.Count <= num || poisonousList.Count <= num || windfuryList.Count <= num || rebornList.Count <= num)
				{
					Debug.LogErrorFormat("Missing Minion Data for GameIndex={0}, MinionIndex={1}", i, num);
					break;
				}
				if (baconGameSaveValueList6[num] == 0L)
				{
					break;
				}
				DataModelList<SpellType> dataModelList2 = new DataModelList<SpellType>();
				bool flag = baconGameSaveValueList9[num] > 0;
				if (tauntList[num] > 0)
				{
					dataModelList2.Add(flag ? SpellType.TAUNT_INSTANT_PREMIUM : SpellType.TAUNT_INSTANT);
				}
				if (divineShieldList[num] > 0)
				{
					dataModelList2.Add(SpellType.DIVINE_SHIELD);
				}
				if (poisonousList[num] > 0)
				{
					dataModelList2.Add(SpellType.POISONOUS);
				}
				if (windfuryList[num] > 0)
				{
					dataModelList2.Add(SpellType.WINDFURY_IDLE);
				}
				if (rebornList[num] > 0)
				{
					dataModelList2.Add(SpellType.REBORN);
				}
				dataModelList.Add(new CardDataModel
				{
					CardId = GameUtils.TranslateDbIdToCardId((int)baconGameSaveValueList6[num]),
					Premium = (flag ? TAG_PREMIUM.GOLDEN : TAG_PREMIUM.NORMAL),
					Attack = (int)baconGameSaveValueList7[num],
					Health = (int)baconGameSaveValueList8[num],
					SpellTypes = dataModelList2
				});
			}
			list.Add(new BaconPastGameStatsDataModel
			{
				Hero = hero,
				HeroPower = heroPower,
				HeroName = heroName,
				Place = (int)baconGameSaveValueList5[i],
				Minions = dataModelList,
				Reward = reward,
				Quest = quest,
				RewardCompleted = (rewardIsCompletedList[i] != 0),
				RewardCardDatabaseID = (int)rewardCardDatabaseIDList[i],
				RewardMinionType = (int)rewardMinionTypeList[i],
				QuestProgressTotal = (int)questProgressTotalList[i],
				QuestRace1 = (int)questRace1List[i],
				QuestRace2 = (int)questRace2List[i]
			});
		}
		list.Reverse();
		list.ForEach(delegate(BaconPastGameStatsDataModel g)
		{
			dataModel.PastGames.Add(g);
		});
	}

	private void PopulateAdditionalInfoLists(int pastGames, ref List<long> tauntList, ref List<long> divineShieldList, ref List<long> poisonousList, ref List<long> windfuryList, ref List<long> rebornList, ref List<long> questIDList, ref List<long> rewardIDList, ref List<long> rewardIsCompletedList, ref List<long> rewardCardDatabaseIDList, ref List<long> rewardMinionTypeList, ref List<long> questProgressTotalList, ref List<long> questRace1List, ref List<long> questRace2List)
	{
		tauntList = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_MINIONS_TAUNT);
		divineShieldList = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_MINIONS_DIVINE_SHIELD);
		poisonousList = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_MINIONS_POISONOUS);
		windfuryList = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_MINIONS_WINDFURY);
		rebornList = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_MINIONS_REBORN);
		questIDList = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_QUEST_IDS);
		rewardIDList = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_REWARD_IDS);
		rewardIsCompletedList = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_REWARD_IS_COMPLETED);
		rewardCardDatabaseIDList = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_REWARD_CARD_DATABASE_ID);
		rewardMinionTypeList = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_REWARD_MINION_TYPE);
		questProgressTotalList = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_QUEST_PROGRESS_TOTAL);
		questRace1List = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_QUEST_RACE_1);
		questRace2List = GetBaconGameSaveValueList(GameSaveKeySubkeyId.BACON_PAST_GAME_QUEST_RACE_2);
		if (tauntList == null)
		{
			tauntList = new List<long>();
		}
		if (divineShieldList == null)
		{
			divineShieldList = new List<long>();
		}
		if (poisonousList == null)
		{
			poisonousList = new List<long>();
		}
		if (windfuryList == null)
		{
			windfuryList = new List<long>();
		}
		if (rebornList == null)
		{
			rebornList = new List<long>();
		}
		if (questIDList == null)
		{
			questIDList = new List<long>();
		}
		if (rewardIDList == null)
		{
			rewardIDList = new List<long>();
		}
		if (rewardIsCompletedList == null)
		{
			rewardIsCompletedList = new List<long>();
		}
		if (rewardCardDatabaseIDList == null)
		{
			rewardCardDatabaseIDList = new List<long>();
		}
		if (rewardMinionTypeList == null)
		{
			rewardMinionTypeList = new List<long>();
		}
		if (questProgressTotalList == null)
		{
			questProgressTotalList = new List<long>();
		}
		if (questRace1List == null)
		{
			questRace1List = new List<long>();
		}
		if (questRace2List == null)
		{
			questRace2List = new List<long>();
		}
		while (tauntList.Count < pastGames * 7)
		{
			tauntList.Insert(0, 0L);
		}
		while (divineShieldList.Count < pastGames * 7)
		{
			divineShieldList.Insert(0, 0L);
		}
		while (poisonousList.Count < pastGames * 7)
		{
			poisonousList.Insert(0, 0L);
		}
		while (windfuryList.Count < pastGames * 7)
		{
			windfuryList.Insert(0, 0L);
		}
		while (rebornList.Count < pastGames * 7)
		{
			rebornList.Insert(0, 0L);
		}
		while (questIDList.Count < pastGames)
		{
			questIDList.Insert(0, 0L);
		}
		while (rewardIDList.Count < pastGames)
		{
			rewardIDList.Insert(0, 0L);
		}
		while (rewardIsCompletedList.Count < pastGames)
		{
			rewardIsCompletedList.Insert(0, 0L);
		}
		while (rewardCardDatabaseIDList.Count < pastGames)
		{
			rewardCardDatabaseIDList.Insert(0, 0L);
		}
		while (rewardMinionTypeList.Count < pastGames)
		{
			rewardMinionTypeList.Insert(0, 0L);
		}
		while (questProgressTotalList.Count < pastGames)
		{
			questProgressTotalList.Insert(0, 0L);
		}
		while (questRace1List.Count < pastGames)
		{
			questRace1List.Insert(0, 0L);
		}
		while (questRace2List.Count < pastGames)
		{
			questRace2List.Insert(0, 0L);
		}
	}

	private long GetBaconGameSaveValue(GameSaveKeySubkeyId subkey)
	{
		GameSaveDataManager.Get().GetSubkeyValue(GameSaveKeyId.BACON, subkey, out long value);
		return value;
	}

	private List<long> GetBaconGameSaveValueList(GameSaveKeySubkeyId subkey)
	{
		GameSaveDataManager.Get().GetSubkeyValue(GameSaveKeyId.BACON, subkey, out List<long> values);
		return values;
	}

	private List<KeyValuePair<long, long>> GetSortedListFromGameSaveDataLists(List<long> keys, List<long> values)
	{
		List<KeyValuePair<long, long>> list = new List<KeyValuePair<long, long>>();
		if (keys == null || values == null)
		{
			return list;
		}
		if (keys.Count != values.Count)
		{
			Debug.LogError("GetSortedListFromGameSaveDataLists: Stats Page Game Save Data Lists Length Not Equal!");
			return list;
		}
		for (int i = 0; i < keys.Count; i++)
		{
			list.Add(new KeyValuePair<long, long>(keys[i], values[i]));
		}
		return list.OrderByDescending((KeyValuePair<long, long> kvp) => kvp.Value).ToList();
	}

	private bool HasAccessToStatsPage()
	{
		return true;
	}

	private void OpenBattlegroundsShop()
	{
		if (GetBaconLobbyDataModel().ShopOpen)
		{
			if (!HasBattlegroundsProductsAvailable())
			{
				ShowBattlegroundsStoreEmptyPopup();
			}
			else
			{
				StoreManager.Get().StartBattlegroundsTransaction(OnStoreBackButtonPressed, isTotallyFake: false);
			}
		}
	}

	private void OnStoreBackButtonPressed(bool authorizationBackButtonPressed, object userData)
	{
		GetBaconLobbyDataModel().HasNewProducts = HasNewBattlegroundsProducts();
	}

	private void OpenBattlegroundsCollection()
	{
		CollectionManager.Get().NotifyOfBoxTransitionStart();
		SceneMgr.Get().SetNextMode(SceneMgr.Mode.BACON_COLLECTION);
	}

	private void RefreshHasAnyNewSkins()
	{
		GetBaconLobbyDataModel().HasNewSkins = CollectionManager.Get().HasAnyNewBattlegroundsSkins();
	}

	private void ShowBattlegroundsBonusErrorPopup()
	{
		AlertPopup.PopupInfo info = new AlertPopup.PopupInfo
		{
			m_headerText = GameStrings.Get("GLUE_BACON_PERKS_ERROR_HEADER"),
			m_text = GameStrings.Get("GLUE_BACON_PERKS_ERROR_BODY"),
			m_showAlertIcon = false,
			m_responseDisplay = AlertPopup.ResponseDisplay.OK
		};
		DialogManager.Get().ShowPopup(info);
	}

	private bool ShouldShowBattlegroundsUnacknowledgedEarnedHammersPopUp()
	{
		return LuckyDrawManager.Get().NumUnacknowledgedEarnedHammers() > 0;
	}

	private IEnumerator ShowBattlegroundsUnacknowledgedHammersPopUp()
	{
		LuckyDrawManager luckyDrawManager = LuckyDrawManager.Get();
		while (luckyDrawManager.IsDataDirty())
		{
			yield return new WaitForSeconds(0.1f);
		}
		if (ShouldShowBattlegroundsUnacknowledgedEarnedHammersPopUp() && m_rewardPresenter != null)
		{
			while (m_rewardPresenter.IsShowingReward())
			{
				yield return new WaitForSeconds(0.1f);
			}
			RewardScrollDataModel dataModel = new RewardScrollDataModel
			{
				DisplayName = GameStrings.Get("GLUE_BACON_REWARD_BATTLE_BASH_HAMMER"),
				Description = GameStrings.Get("GLUE_BACON_TOP_4_REWARD_DESC"),
				RewardList = new RewardListDataModel
				{
					Items = new DataModelList<RewardItemDataModel>
					{
						new RewardItemDataModel
						{
							Quantity = LuckyDrawManager.Get().NumUnacknowledgedEarnedHammers(),
							ItemType = RewardItemType.BATTLEGROUNDS_BATTLE_BASH_HAMMER
						}
					}
				}
			};
			m_rewardPresenter.EnqueueReward(dataModel, delegate
			{
			});
			m_rewardPresenter.ShowNextReward(OnLuckyDrawPopupDismissed);
		}
	}

	private IEnumerator PlayLuckyDrawButtonFanfareFX()
	{
		yield return new WaitForSeconds(0.5f);
		GameObject gameObject = GameObjectUtils.FindChild(m_luckyDrawButton.gameObject, "NewHammerFX");
		if (gameObject == null)
		{
			Log.All.PrintError("BaconDisplay.PlayLuckyDrawButtonFanfareFX - New Hammer FX object is null");
			yield break;
		}
		Animator component = gameObject.GetComponent<Animator>();
		if (component == null)
		{
			Log.All.PrintError("BaconDisplay.PlayLuckyDrawButtonFanfareFX - New Hammer FX object does not have animator component");
		}
		else
		{
			component.Play("LuckyDrawNewHammer_Anim");
		}
	}

	private void OnLuckyDrawPopupDismissed()
	{
		LuckyDrawManager.Get().AcknowledgeAllHammers();
		StartCoroutine(PlayLuckyDrawButtonFanfareFX());
	}

	private void OnPartyChanged(PartyManager.PartyInviteEvent inviteEvent, BnetGameAccountId playerGameAccountId, PartyManager.PartyData data, object userData)
	{
		if (inviteEvent == PartyManager.PartyInviteEvent.I_CREATED_PARTY || inviteEvent == PartyManager.PartyInviteEvent.FRIEND_RECEIVED_INVITE)
		{
			PartyManager.Get().SetReadyStatus(ready: true);
		}
		UpdatePlayButtonBasedOnPartyInfo();
	}

	private void OnPresenceUpdated(BnetPlayerChangelist changelist, object userData)
	{
		UpdatePlayButtonBasedOnPartyInfo();
	}

	private void OnNearbyPlayersUpdated(BnetRecentOrNearbyPlayerChangelist changelist, object userData)
	{
		UpdatePlayButtonBasedOnPartyInfo();
	}

	private void UpdatePlayButtonBasedOnPartyInfo()
	{
		if (!(m_playButton == null))
		{
			string text = ((!PartyManager.Get().IsInBattlegroundsParty() || PartyManager.Get().IsPartyLeader()) ? GameStrings.Get("GLOBAL_PLAY") : GameStrings.Get("GLOBAL_PLAY_WAITING"));
			m_playButton.SetText(text);
			int readyPartyMemberCount = PartyManager.Get().GetReadyPartyMemberCount();
			int currentPartySize = PartyManager.Get().GetCurrentPartySize();
			string secondaryText = "";
			if (PartyManager.Get().IsInBattlegroundsParty() && PartyManager.Get().IsPartyLeader() && !GameMgr.Get().IsFindingGame() && readyPartyMemberCount < currentPartySize)
			{
				secondaryText = $"{readyPartyMemberCount}/{currentPartySize}";
			}
			m_playButton.SetSecondaryText(secondaryText);
			if (PartyManager.Get().IsInBattlegroundsParty() && (!PartyManager.Get().IsPartyLeader() || readyPartyMemberCount < currentPartySize))
			{
				m_playButton.Disable(keepLabelTextVisible: true);
			}
			else
			{
				m_playButton.Enable();
			}
		}
	}

	private void OnStoreStatusChanged(bool isOpen)
	{
		GetBaconLobbyDataModel().ShopOpen = isOpen;
	}

	private void ShowBattlegroundsStoreEmptyPopup()
	{
		AlertPopup.PopupInfo info = new AlertPopup.PopupInfo
		{
			m_headerText = GameStrings.Get("GLUE_BACON_SHOP_EMPTY_HEADER"),
			m_text = GameStrings.Get("GLUE_BACON_SHOP_EMPTY_BODY"),
			m_showAlertIcon = false,
			m_responseDisplay = AlertPopup.ResponseDisplay.OK
		};
		DialogManager.Get().ShowPopup(info);
	}

	private bool HasBattlegroundsProductsAvailable()
	{
		if (StoreManager.Get().Catalog.CurrentTestDataMode == ProductCatalog.TestDataMode.TIER_TEST_DATA)
		{
			return true;
		}
		List<ShopType> shopTypes = new List<ShopType> { ShopType.BATTLEGROUNDS_STORE };
		if (!StoreManager.Get().CatalogNetworkPages.Contains(shopTypes))
		{
			return false;
		}
		foreach (Network.ShopSection section in StoreManager.Get().CatalogNetworkPages.Pages[ShopType.BATTLEGROUNDS_STORE].Sections)
		{
			foreach (Network.ShopSection.ProductRef product in section.Products)
			{
				Network.Bundle bundleFromPmtProductId = StoreManager.Get().GetBundleFromPmtProductId(ProductId.CreateFrom(product.PmtId));
				if (bundleFromPmtProductId != null && !StoreManager.Get().IsProductAlreadyOwned(bundleFromPmtProductId))
				{
					return true;
				}
				ProductDataModel productByPmtId = StoreManager.Get().Catalog.GetProductByPmtId(ProductId.CreateFrom(product.PmtId));
				if (productByPmtId != null && productByPmtId.Availability == ProductAvailability.CAN_PURCHASE)
				{
					return true;
				}
			}
		}
		return false;
	}

	private bool HasNewBattlegroundsProducts()
	{
		List<ShopType> shopTypes = new List<ShopType> { ShopType.BATTLEGROUNDS_STORE };
		if (!StoreManager.Get().CatalogNetworkPages.Contains(shopTypes))
		{
			return false;
		}
		foreach (Network.ShopSection section in StoreManager.Get().CatalogNetworkPages.Pages[ShopType.BATTLEGROUNDS_STORE].Sections)
		{
			foreach (Network.ShopSection.ProductRef product in section.Products)
			{
				ProductDataModel productByPmtId = StoreManager.Get().Catalog.GetProductByPmtId(ProductId.CreateFrom(product.PmtId));
				if (productByPmtId != null && productByPmtId.Availability == ProductAvailability.CAN_PURCHASE && productByPmtId.Tags.Contains("new"))
				{
					return true;
				}
			}
		}
		return false;
	}

	protected override bool ShouldStartShown()
	{
		if (SceneMgr.Get().GetMode() != SceneMgr.Mode.LUCKY_DRAW)
		{
			return SceneMgr.Get().GetPrevMode() != SceneMgr.Mode.LUCKY_DRAW;
		}
		return false;
	}

	public override bool IsFinishedLoading(out string failureMessage)
	{
		if (!m_playButtonFinishedLoading)
		{
			failureMessage = "BaconDisplay - Play button never finished loading";
			return false;
		}
		if (!m_backButtonFinishedLoading)
		{
			failureMessage = "BaconDisplay - Back button never finished loading";
			return false;
		}
		if (!m_statsButtonFinishedLoading)
		{
			failureMessage = "BaconDisplay - Stats button never finished loading";
			return false;
		}
		if (!m_luckyDrawButtonFinishedLoading)
		{
			failureMessage = "BaconDisplay - Lucky draw button never finished loading";
			return false;
		}
		if ((bool)UniversalInputManager.UsePhoneUI)
		{
			if (!m_partyPhoneFinishedLoading)
			{
				failureMessage = "BaconDisplay - Lobby Phone not finished loading";
				return false;
			}
		}
		else if (!m_partyFinishedLoading)
		{
			failureMessage = "BaconDisplay - Lobby PC not finished loading";
			return false;
		}
		if (m_OwningWidget.IsChangingStates)
		{
			failureMessage = "BaconDisplay - owning widget is still transitioning";
			return false;
		}
		failureMessage = string.Empty;
		return true;
	}

	private void InitSlidingTray()
	{
		if (m_slidingTray == null)
		{
			Error.AddDevWarning("UI Error", "Warning [BaconDisplay] InitSlidingTray() reference to the sliding tray is missing! This may lead to an improper layout.");
		}
		else if ((bool)UniversalInputManager.UsePhoneUI)
		{
			m_slidingTray.m_trayHiddenBone = m_OffScreenBoneMobile;
			m_slidingTray.m_trayShownBone = m_OnScreenBoneMobile;
		}
		else
		{
			m_slidingTray.m_trayHiddenBone = m_OffScreenBonePC;
			m_slidingTray.m_trayShownBone = m_OnScreenBonePC;
		}
	}
}
