using Hearthstone.UI;
using UnityEngine;

public class AdventureBookDeckTray : MonoBehaviour
{
	public AsyncReference m_PlayButtonReference;

	public AsyncReference m_AnomalyModeButtonReference;

	public UIBButton m_BackButton;

	public Transform m_anomalyModeCardBone;

	public Transform m_anomalyModeCardSourceBone;
}
