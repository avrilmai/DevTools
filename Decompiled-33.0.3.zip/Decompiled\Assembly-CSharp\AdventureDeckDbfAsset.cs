using System.Collections.Generic;
using UnityEngine;

public class AdventureDeckDbfAsset : ScriptableObject
{
	public List<AdventureDeckDbfRecord> Records = new List<AdventureDeckDbfRecord>();
}
