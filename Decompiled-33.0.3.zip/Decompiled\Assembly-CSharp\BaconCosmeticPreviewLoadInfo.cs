public static class BaconCosmeticPreviewLoadInfo
{
	public static BaconCosmeticPreviewRunnerConfig s_runnerConfig;
}
