using System.Collections.Generic;
using Blizzard.GameService.SDK.Client.Integration;
using UnityEngine;

public class BnetRecentPlayerMgr
{
	public delegate void ChangeCallback(BnetRecentOrNearbyPlayerChangelist changelist, object userData);

	private class ChangeListener : EventListener<ChangeCallback>
	{
		public void Fire(BnetRecentOrNearbyPlayerChangelist changelist)
		{
			m_callback(changelist, m_userData);
		}
	}

	public enum RecentReason
	{
		INVALID,
		RECENT_OPPONENT,
		FORMER_FRIEND,
		NEW_FRIEND,
		RECENT_CHALLENGED,
		RECENT_CHATTED,
		LAST_OPPONENT,
		CURRENT_OPPONENT,
		RECENT_SPECTATED,
		CHEAT
	}

	private static readonly int MAX_NUMBER_ENTRIES_PC_TABLET = 5;

	private static readonly int MAX_NUMBER_ENTRIES_PHONE = 2;

	private static BnetRecentPlayerMgr s_instance;

	private int m_maxNumberOfEntries;

	private List<BnetPlayer> m_recentPlayers = new List<BnetPlayer>();

	private Dictionary<BnetPlayer, RecentReason> m_recentPlayerData = new Dictionary<BnetPlayer, RecentReason>();

	private List<BnetPlayer> m_recentFriends = new List<BnetPlayer>();

	private List<BnetPlayer> m_recentStrangers = new List<BnetPlayer>();

	private List<ChangeListener> m_changeListeners = new List<ChangeListener>();

	private BnetRecentOrNearbyPlayerChangelist m_changelist = new BnetRecentOrNearbyPlayerChangelist();

	private HashSet<BnetEntityId> m_pendingFriendsById = new HashSet<BnetEntityId>();

	private HashSet<string> m_pendingFriendsByBattleTag = new HashSet<string>();

	private BnetPlayer m_lastOpponent;

	private BnetRecentPlayerMgr()
	{
		m_maxNumberOfEntries = (UniversalInputManager.UsePhoneUI ? MAX_NUMBER_ENTRIES_PHONE : MAX_NUMBER_ENTRIES_PC_TABLET);
	}

	public static BnetRecentPlayerMgr Get()
	{
		if (s_instance == null)
		{
			s_instance = new BnetRecentPlayerMgr();
		}
		return s_instance;
	}

	public void Initialize()
	{
		BnetFriendMgr.Get().AddChangeListener(OnFriendsChanged);
		FriendChallengeMgr.Get().AddChangedListener(OnChallengeChanged);
	}

	public void Shutdown()
	{
		BnetFriendMgr.Get().RemoveChangeListener(OnFriendsChanged);
		FriendChallengeMgr.Get().RemoveChangedListener(OnChallengeChanged);
	}

	public List<BnetPlayer> GetRecentPlayers()
	{
		return m_recentPlayers;
	}

	public string GetRecentReason(BnetPlayer player)
	{
		if (!m_recentPlayerData.ContainsKey(player))
		{
			return null;
		}
		switch (m_recentPlayerData[player])
		{
		case RecentReason.RECENT_OPPONENT:
			return GameStrings.Get("GLOBAL_FRIENDLIST_RECENT_OPPONENT_STATUS");
		case RecentReason.FORMER_FRIEND:
			return GameStrings.Get("GLOBAL_FRIENDLIST_FORMER_FRIEND_STATUS");
		case RecentReason.NEW_FRIEND:
			return GameStrings.Get("GLOBAL_FRIENDLIST_NEW_FRIEND_STATUS");
		case RecentReason.RECENT_CHALLENGED:
			return GameStrings.Get("GLOBAL_FRIENDLIST_RECENT_CHALLENGED_STATUS");
		case RecentReason.RECENT_CHATTED:
			return GameStrings.Get("GLOBAL_FRIENDLIST_RECENT_CHATTED_STATUS");
		case RecentReason.LAST_OPPONENT:
			return GameStrings.Get("GLOBAL_FRIENDLIST_LAST_OPPONENT_STATUS");
		case RecentReason.CURRENT_OPPONENT:
			return GameStrings.Get("GLOBAL_FRIENDLIST_CURRENT_OPPONENT_STATUS");
		default:
			return null;
		}
	}

	public bool IsCurrentOpponent(BnetPlayer player)
	{
		if (!m_recentPlayerData.ContainsKey(player))
		{
			return false;
		}
		return m_recentPlayerData[player] == RecentReason.CURRENT_OPPONENT;
	}

	public bool IsRecentStranger(BnetPlayer player)
	{
		return IsRecentInList(player, m_recentStrangers);
	}

	public bool IsRecentPlayer(BnetPlayer player)
	{
		return IsRecentInList(player, m_recentPlayers);
	}

	private static bool IsRecentInList(BnetPlayer player, List<BnetPlayer> bnetPlayers)
	{
		if (player == null)
		{
			return false;
		}
		BnetAccountId accountId = player.GetAccountId();
		if (accountId != null)
		{
			for (int i = 0; i < bnetPlayers.Count; i++)
			{
				if (accountId == bnetPlayers[i].GetAccountId())
				{
					return true;
				}
			}
			return false;
		}
		BnetGameAccountId hearthstoneGameAccountId = player.GetHearthstoneGameAccountId();
		if (hearthstoneGameAccountId != null)
		{
			for (int j = 0; j < bnetPlayers.Count; j++)
			{
				if (hearthstoneGameAccountId == bnetPlayers[j].GetHearthstoneGameAccountId())
				{
					return true;
				}
			}
			return false;
		}
		return false;
	}

	public bool AddChangeListener(ChangeCallback callback)
	{
		ChangeListener changeListener = new ChangeListener();
		changeListener.SetCallback(callback);
		if (m_changeListeners.Contains(changeListener))
		{
			return false;
		}
		m_changeListeners.Add(changeListener);
		return true;
	}

	public bool RemoveChangeListenerFromInstance(ChangeCallback callback)
	{
		ChangeListener changeListener = new ChangeListener();
		changeListener.SetCallback(callback);
		return m_changeListeners.Remove(changeListener);
	}

	public void AddRecentPlayer(BnetPlayer player, RecentReason recentReason)
	{
		if (player == null || !NetCache.Get().GetNetObject<NetCache.NetCacheFeatures>().RecentFriendListDisplayEnabled)
		{
			return;
		}
		if (recentReason == RecentReason.LAST_OPPONENT)
		{
			if (m_lastOpponent != null)
			{
				m_recentPlayerData[m_lastOpponent] = RecentReason.RECENT_OPPONENT;
			}
			m_lastOpponent = player;
		}
		player.TimeLastAddedToRecentPlayers = Time.time;
		if (m_recentPlayers.Contains(player))
		{
			m_recentPlayerData[player] = recentReason;
			return;
		}
		BnetRecentOrNearbyPlayerChangelist bnetRecentOrNearbyPlayerChangelist = new BnetRecentOrNearbyPlayerChangelist();
		m_recentPlayers.Add(player);
		bnetRecentOrNearbyPlayerChangelist.AddAddedPlayer(player);
		m_recentPlayerData[player] = recentReason;
		if (BnetFriendMgr.Get().IsFriend(player))
		{
			m_recentFriends.Add(player);
			bnetRecentOrNearbyPlayerChangelist.AddAddedFriend(player);
		}
		else
		{
			m_recentStrangers.Add(player);
			bnetRecentOrNearbyPlayerChangelist.AddAddedStranger(player);
		}
		RemoveNoLongerRecentPlayers(bnetRecentOrNearbyPlayerChangelist);
		FireChangeEvent(bnetRecentOrNearbyPlayerChangelist);
	}

	public void AddPendingFriend(BnetEntityId playerId)
	{
		if (!m_pendingFriendsById.Contains(playerId))
		{
			m_pendingFriendsById.Add(playerId);
		}
	}

	public void AddPendingFriend(string playerBattleTag)
	{
		if (!m_pendingFriendsByBattleTag.Contains(playerBattleTag))
		{
			m_pendingFriendsByBattleTag.Add(playerBattleTag);
		}
	}

	public BnetPlayer GetCurrentOpponent()
	{
		foreach (KeyValuePair<BnetPlayer, RecentReason> recentPlayerDatum in m_recentPlayerData)
		{
			if (recentPlayerDatum.Value == RecentReason.CURRENT_OPPONENT)
			{
				return recentPlayerDatum.Key;
			}
		}
		return null;
	}

	public void Update()
	{
		m_changelist.Clear();
		RemoveNoLongerRecentPlayers(m_changelist);
		FireChangeEvent(m_changelist);
	}

	private void RemoveNoLongerRecentPlayers(BnetRecentOrNearbyPlayerChangelist changelist)
	{
		List<BnetPlayer> list = null;
		for (int num = m_recentPlayers.Count - 1; num >= 0; num--)
		{
			bool flag = false;
			BnetPlayer item = m_recentPlayers[num];
			if (m_recentPlayers.Count - num > m_maxNumberOfEntries)
			{
				flag = true;
			}
			if (flag)
			{
				if (list == null)
				{
					list = new List<BnetPlayer>();
				}
				list.Add(item);
			}
		}
		if (list == null)
		{
			return;
		}
		foreach (BnetPlayer item2 in list)
		{
			RemoveRecentPlayer(item2, changelist);
		}
	}

	private void RemoveRecentPlayer(BnetPlayer recentPlayer, BnetRecentOrNearbyPlayerChangelist changelist)
	{
		m_recentPlayers.Remove(recentPlayer);
		changelist.AddRemovedPlayer(recentPlayer);
		if (m_recentFriends.Remove(recentPlayer))
		{
			changelist.AddRemovedFriend(recentPlayer);
		}
		else if (m_recentStrangers.Remove(recentPlayer))
		{
			changelist.AddRemovedStranger(recentPlayer);
		}
	}

	private void FireChangeEvent(BnetRecentOrNearbyPlayerChangelist changelist)
	{
		if (!changelist.IsEmpty())
		{
			ChangeListener[] array = m_changeListeners.ToArray();
			for (int i = 0; i < array.Length; i++)
			{
				array[i].Fire(changelist);
			}
		}
	}

	private void OnFriendsChanged(BnetFriendChangelist changelist, object userData)
	{
		List<BnetPlayer> addedFriends = changelist.GetAddedFriends();
		if (addedFriends != null && (m_pendingFriendsById.Count > 0 || m_pendingFriendsByBattleTag.Count > 0))
		{
			foreach (BnetPlayer item2 in addedFriends)
			{
				BnetEntityId accountId = item2.GetAccountId();
				string item = item2.GetBattleTag().ToString();
				if (m_pendingFriendsById.Contains(accountId))
				{
					m_pendingFriendsById.Remove(accountId);
					AddRecentPlayer(item2, RecentReason.NEW_FRIEND);
				}
				else if (m_pendingFriendsByBattleTag.Contains(item))
				{
					m_pendingFriendsByBattleTag.Remove(item);
					AddRecentPlayer(item2, RecentReason.NEW_FRIEND);
				}
			}
		}
		List<BnetPlayer> removedFriends = changelist.GetRemovedFriends();
		if (removedFriends == null)
		{
			return;
		}
		foreach (BnetPlayer item3 in removedFriends)
		{
			AddRecentPlayer(item3, RecentReason.FORMER_FRIEND);
		}
	}

	private void OnChallengeChanged(FriendChallengeEvent challengeEvent, BnetPlayer player, FriendlyChallengeData challengeData, object userData)
	{
		if (challengeEvent == FriendChallengeEvent.I_SENT_CHALLENGE || challengeEvent == FriendChallengeEvent.I_RECEIVED_CHALLENGE)
		{
			AddRecentPlayer(player, RecentReason.RECENT_CHALLENGED);
		}
	}

	public BnetPlayer Cheat_CreateRecentPlayer(string fullName, int leagueId, int starLevel, BnetProgramId programId, bool isFriend, bool isOnline)
	{
		BnetPlayer bnetPlayer = BnetFriendMgr.Get().Cheat_CreatePlayer(fullName, leagueId, starLevel, programId, isFriend, isOnline);
		AddRecentPlayer(bnetPlayer, RecentReason.CHEAT);
		return bnetPlayer;
	}

	public int Cheat_RemoveCheatFriends()
	{
		int num = 0;
		BnetRecentOrNearbyPlayerChangelist changelist = new BnetRecentOrNearbyPlayerChangelist();
		for (int num2 = m_recentPlayers.Count - 1; num2 >= 0; num2--)
		{
			BnetPlayer bnetPlayer = m_recentPlayers[num2];
			if (bnetPlayer.IsCheatPlayer)
			{
				RemoveRecentPlayer(bnetPlayer, changelist);
				num++;
			}
		}
		FireChangeEvent(changelist);
		return num;
	}
}
