using System.Text;
using Blizzard.T5.AssetManager;
using Hearthstone.UI;
using UnityEngine;

[CustomEditClass]
public class BaconGuideSkinInfoManager : BaconBaseSkinInfoManager
{
	private static BaconGuideSkinInfoManager s_instance;

	private static bool s_isReadyingInstance;

	public static BaconGuideSkinInfoManager Get()
	{
		return s_instance;
	}

	public static void EnterPreviewWhenReady(CollectionCardVisual cardVisual)
	{
		BaconGuideSkinInfoManager baconGuideSkinInfoManager = Get();
		if (baconGuideSkinInfoManager != null)
		{
			baconGuideSkinInfoManager.EnterPreview(cardVisual);
			return;
		}
		if (s_isReadyingInstance)
		{
			Debug.LogWarning("BaconGuideSkinInfoManager:EnterPreviewWhenReady called while the info manager instance was being readied");
			return;
		}
		string assetString = "BaconGuideSkinInfoManager.prefab:2201365483a4bd748ab41038e3b56d91";
		Widget widget = WidgetInstance.Create(assetString);
		if (widget == null)
		{
			Debug.LogError("BaconGuideSkinInfoManager:EnterPreviewWhenReady failed to create widget instance");
			return;
		}
		s_isReadyingInstance = true;
		widget.RegisterReadyListener(delegate
		{
			s_instance = widget.GetComponentInChildren<BaconGuideSkinInfoManager>();
			s_isReadyingInstance = false;
			if (s_instance == null)
			{
				Debug.LogError("BaconGuideSkinInfoManager:EnterPreviewWhenReady created widget instance but failed to get BaconGuideSkinInfoManager component");
			}
			else
			{
				s_instance.EnterPreview(cardVisual);
			}
		});
	}

	public static bool IsLoadedAndShowingPreview()
	{
		if (!s_instance)
		{
			return false;
		}
		return s_instance.IsShowingPreview;
	}

	private void OnDestroy()
	{
		m_currentHeroCardDef?.Dispose();
		m_currentHeroCardDef = null;
		AssetHandle.SafeDispose(ref m_currentHeroGoldenAnimation);
		CancelPreview();
		s_instance = null;
	}

	protected override void PushNavigateBack()
	{
		Navigation.PushUnique(OnNavigateBack);
	}

	protected override void RemoveNavigateBack()
	{
		Navigation.RemoveHandler(OnNavigateBack);
	}

	private static bool OnNavigateBack()
	{
		BaconGuideSkinInfoManager baconGuideSkinInfoManager = Get();
		if (baconGuideSkinInfoManager != null)
		{
			baconGuideSkinInfoManager.CancelPreview();
		}
		return true;
	}

	protected override void SetFavoriteHero()
	{
		if (!CollectionManager.Get().IsBattlegroundsGuideCardId(m_currentEntityDef.GetCardId()))
		{
			return;
		}
		int skinCardId = GameUtils.TranslateCardIdToDbId(m_currentEntityDef.GetCardId());
		if (CollectionManager.Get().GetBattlegroundsGuideSkinIdForCardId(skinCardId, out var skinId))
		{
			if (CollectionManager.Get().OwnsBattlegroundsGuideSkin(skinCardId))
			{
				Network.Get().SetBattlegroundsFavoriteGuideSkin(skinId);
			}
		}
		else
		{
			Network.Get().ClearBattlegroundsFavoriteGuideSkin();
		}
	}

	protected override bool CanToggleFavorite()
	{
		return BaconHeroSkinUtils.CanFavoriteBattlegroundsGuideSkin(m_currentEntityDef);
	}

	protected override void AppendDebugTextForCurrentCard(StringBuilder builder)
	{
		base.AppendDebugTextForCurrentCard(builder);
		int skinCardId = GameUtils.TranslateCardIdToDbId(m_currentEntityDef.GetCardId());
		if (CollectionManager.Get().GetBattlegroundsGuideSkinIdForCardId(skinCardId, out var skinId))
		{
			builder.Append("Guide Skin Id: ");
			builder.Append(skinId.ToValue());
			builder.AppendLine();
		}
		else
		{
			builder.AppendLine("No Guide Skin Id");
		}
	}
}
