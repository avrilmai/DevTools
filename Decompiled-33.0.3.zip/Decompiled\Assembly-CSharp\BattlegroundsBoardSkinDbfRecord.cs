using System;
using System.Collections.Generic;
using Assets;
using Blizzard.T5.Jobs;
using UnityEngine;

[Serializable]
public class BattlegroundsBoardSkinDbfRecord : DbfRecord
{
	[SerializeField]
	private bool m_enabled = true;

	[SerializeField]
	private int m_rarityId = 2;

	[SerializeField]
	private string m_fullBoardPrefab;

	[SerializeField]
	private string m_fullBoardPrefabPhone;

	[SerializeField]
	private string m_fullTavernBoardPrefab;

	[SerializeField]
	private string m_fullTavernBoardPrefabPhone;

	[SerializeField]
	private DbfLocValue m_collectionName;

	[SerializeField]
	private DbfLocValue m_collectionShortName;

	[SerializeField]
	private DbfLocValue m_description;

	[SerializeField]
	private string m_detailsTexture;

	[SerializeField]
	private string m_detailsTexturePhone;

	[SerializeField]
	private string m_detailsMovie;

	[SerializeField]
	private string m_detailsMoviePhone;

	[SerializeField]
	private string m_detailsRenderConfig;

	[SerializeField]
	private BattlegroundsBoardSkin.Bordertype m_borderType;

	[DbfField("RARITY")]
	public int Rarity => m_rarityId;

	[DbfField("FULL_BOARD_PREFAB")]
	public string FullBoardPrefab => m_fullBoardPrefab;

	[DbfField("FULL_BOARD_PREFAB_PHONE")]
	public string FullBoardPrefabPhone => m_fullBoardPrefabPhone;

	[DbfField("FULL_TAVERN_BOARD_PREFAB")]
	public string FullTavernBoardPrefab => m_fullTavernBoardPrefab;

	[DbfField("FULL_TAVERN_BOARD_PREFAB_PHONE")]
	public string FullTavernBoardPrefabPhone => m_fullTavernBoardPrefabPhone;

	[DbfField("COLLECTION_NAME")]
	public DbfLocValue CollectionName => m_collectionName;

	[DbfField("COLLECTION_SHORT_NAME")]
	public DbfLocValue CollectionShortName => m_collectionShortName;

	[DbfField("DESCRIPTION")]
	public DbfLocValue Description => m_description;

	[DbfField("DETAILS_TEXTURE")]
	public string DetailsTexture => m_detailsTexture;

	[DbfField("DETAILS_TEXTURE_PHONE")]
	public string DetailsTexturePhone => m_detailsTexturePhone;

	[DbfField("DETAILS_MOVIE")]
	public string DetailsMovie => m_detailsMovie;

	[DbfField("DETAILS_MOVIE_PHONE")]
	public string DetailsMoviePhone => m_detailsMoviePhone;

	[DbfField("BORDER_TYPE")]
	public BattlegroundsBoardSkin.Bordertype BorderType => m_borderType;

	public override object GetVar(string name)
	{
		switch (name)
		{
		case "ID":
			return base.ID;
		case "ENABLED":
			return m_enabled;
		case "RARITY":
			return m_rarityId;
		case "FULL_BOARD_PREFAB":
			return m_fullBoardPrefab;
		case "FULL_BOARD_PREFAB_PHONE":
			return m_fullBoardPrefabPhone;
		case "FULL_TAVERN_BOARD_PREFAB":
			return m_fullTavernBoardPrefab;
		case "FULL_TAVERN_BOARD_PREFAB_PHONE":
			return m_fullTavernBoardPrefabPhone;
		case "COLLECTION_NAME":
			return m_collectionName;
		case "COLLECTION_SHORT_NAME":
			return m_collectionShortName;
		case "DESCRIPTION":
			return m_description;
		case "DETAILS_TEXTURE":
			return m_detailsTexture;
		case "DETAILS_TEXTURE_PHONE":
			return m_detailsTexturePhone;
		case "DETAILS_MOVIE":
			return m_detailsMovie;
		case "DETAILS_MOVIE_PHONE":
			return m_detailsMoviePhone;
		case "DETAILS_RENDER_CONFIG":
			return m_detailsRenderConfig;
		case "BORDER_TYPE":
			return m_borderType;
		default:
			return null;
		}
	}

	public override void SetVar(string name, object val)
	{
		switch (name)
		{
		case "ID":
			SetID((int)val);
			break;
		case "ENABLED":
			m_enabled = (bool)val;
			break;
		case "RARITY":
			m_rarityId = (int)val;
			break;
		case "FULL_BOARD_PREFAB":
			m_fullBoardPrefab = (string)val;
			break;
		case "FULL_BOARD_PREFAB_PHONE":
			m_fullBoardPrefabPhone = (string)val;
			break;
		case "FULL_TAVERN_BOARD_PREFAB":
			m_fullTavernBoardPrefab = (string)val;
			break;
		case "FULL_TAVERN_BOARD_PREFAB_PHONE":
			m_fullTavernBoardPrefabPhone = (string)val;
			break;
		case "COLLECTION_NAME":
			m_collectionName = (DbfLocValue)val;
			break;
		case "COLLECTION_SHORT_NAME":
			m_collectionShortName = (DbfLocValue)val;
			break;
		case "DESCRIPTION":
			m_description = (DbfLocValue)val;
			break;
		case "DETAILS_TEXTURE":
			m_detailsTexture = (string)val;
			break;
		case "DETAILS_TEXTURE_PHONE":
			m_detailsTexturePhone = (string)val;
			break;
		case "DETAILS_MOVIE":
			m_detailsMovie = (string)val;
			break;
		case "DETAILS_MOVIE_PHONE":
			m_detailsMoviePhone = (string)val;
			break;
		case "DETAILS_RENDER_CONFIG":
			m_detailsRenderConfig = (string)val;
			break;
		case "BORDER_TYPE":
			if (val == null)
			{
				m_borderType = BattlegroundsBoardSkin.Bordertype.DEFAULT;
			}
			else if (val is BattlegroundsBoardSkin.Bordertype || val is int)
			{
				m_borderType = (BattlegroundsBoardSkin.Bordertype)val;
			}
			else if (val is string)
			{
				m_borderType = BattlegroundsBoardSkin.ParseBordertypeValue((string)val);
			}
			break;
		}
	}

	public override Type GetVarType(string name)
	{
		switch (name)
		{
		case "ID":
			return typeof(int);
		case "ENABLED":
			return typeof(bool);
		case "RARITY":
			return typeof(int);
		case "FULL_BOARD_PREFAB":
			return typeof(string);
		case "FULL_BOARD_PREFAB_PHONE":
			return typeof(string);
		case "FULL_TAVERN_BOARD_PREFAB":
			return typeof(string);
		case "FULL_TAVERN_BOARD_PREFAB_PHONE":
			return typeof(string);
		case "COLLECTION_NAME":
			return typeof(DbfLocValue);
		case "COLLECTION_SHORT_NAME":
			return typeof(DbfLocValue);
		case "DESCRIPTION":
			return typeof(DbfLocValue);
		case "DETAILS_TEXTURE":
			return typeof(string);
		case "DETAILS_TEXTURE_PHONE":
			return typeof(string);
		case "DETAILS_MOVIE":
			return typeof(string);
		case "DETAILS_MOVIE_PHONE":
			return typeof(string);
		case "DETAILS_RENDER_CONFIG":
			return typeof(string);
		case "BORDER_TYPE":
			return typeof(BattlegroundsBoardSkin.Bordertype);
		default:
			return null;
		}
	}

	public override IEnumerator<IAsyncJobResult> Job_LoadRecordsFromAssetAsync<T>(string resourcePath, Action<List<T>> resultHandler)
	{
		LoadBattlegroundsBoardSkinDbfRecords loadRecords = new LoadBattlegroundsBoardSkinDbfRecords(resourcePath);
		yield return loadRecords;
		resultHandler?.Invoke(loadRecords.GetRecords() as List<T>);
	}

	public override bool LoadRecordsFromAsset<T>(string resourcePath, out List<T> records)
	{
		BattlegroundsBoardSkinDbfAsset battlegroundsBoardSkinDbfAsset = DbfShared.GetAssetBundle().LoadAsset(resourcePath, typeof(BattlegroundsBoardSkinDbfAsset)) as BattlegroundsBoardSkinDbfAsset;
		if (battlegroundsBoardSkinDbfAsset == null)
		{
			records = new List<T>();
			Debug.LogError($"BattlegroundsBoardSkinDbfAsset.LoadRecordsFromAsset() - failed to load records from assetbundle: {resourcePath}");
			return false;
		}
		for (int i = 0; i < battlegroundsBoardSkinDbfAsset.Records.Count; i++)
		{
			battlegroundsBoardSkinDbfAsset.Records[i].StripUnusedLocales();
		}
		records = battlegroundsBoardSkinDbfAsset.Records as List<T>;
		return true;
	}

	public override bool SaveRecordsToAsset<T>(string assetPath, List<T> records, Locale locale)
	{
		return false;
	}

	public override void StripUnusedLocales()
	{
		m_collectionName.StripUnusedLocales();
		m_collectionShortName.StripUnusedLocales();
		m_description.StripUnusedLocales();
	}
}
