using Hearthstone.DataModels;
using Hearthstone.UI;
using UnityEngine;

public class BaconRewardsVideoDetailView : MonoBehaviour
{
	private BaconBoardCollectionDetails m_boardDetailsDisplay;

	private BaconFinisherCollectionDetails m_finisherDetailsDisplay;

	public VisualController MainVisualController;

	public Widget m_BoardSkinsWidget;

	public AsyncReference m_boardDisplayReference;

	private Widget m_BoardSkinsWidgetInstance;

	public Widget m_FinishersWidget;

	public AsyncReference m_finisherDisplayReference;

	private Widget m_FinisherWidgetInstance;

	private RewardItemDataModel m_CurrentRewardItem;

	private WidgetTemplate m_widget;

	private void Start()
	{
		m_widget = GetComponent<WidgetTemplate>();
		if (m_widget == null)
		{
			Log.Gameplay.PrintError("Video Details View isn't a widget");
			return;
		}
		if (MainVisualController == null)
		{
			Log.Gameplay.PrintError("Main visual controller is null.");
			return;
		}
		if (m_boardDisplayReference == null)
		{
			Log.Gameplay.PrintError("Board display reference is null.");
			return;
		}
		if (m_finisherDisplayReference == null)
		{
			Log.Gameplay.PrintError("Finisher display reference is null.");
			return;
		}
		m_boardDisplayReference.RegisterReadyListener<Widget>(OnBoardDisplayReady);
		m_finisherDisplayReference.RegisterReadyListener<Widget>(OnFinisherDisplayReady);
		MainVisualController.RegisterDoneChangingStatesListener(ShowReward);
	}

	private void OnBoardDisplayReady(Widget widget)
	{
		m_BoardSkinsWidgetInstance = widget;
		m_boardDetailsDisplay = m_BoardSkinsWidgetInstance.GetComponentInChildren<BaconBoardCollectionDetails>();
	}

	private void OnFinisherDisplayReady(Widget widget)
	{
		m_FinisherWidgetInstance = widget;
		m_finisherDetailsDisplay = m_FinisherWidgetInstance.GetComponentInChildren<BaconFinisherCollectionDetails>();
	}

	private void ShowReward(object o = null)
	{
		m_CurrentRewardItem = m_widget.GetDataModel<RewardItemDataModel>();
		if (m_CurrentRewardItem != null)
		{
			switch (m_CurrentRewardItem.ItemType)
			{
			case RewardItemType.BATTLEGROUNDS_BOARD_SKIN:
				ShowBoardSkinReward();
				break;
			case RewardItemType.BATTLEGROUNDS_FINISHER:
				ShowFinisherReward();
				break;
			}
		}
	}

	private void ShowBoardSkinReward()
	{
		if (m_CurrentRewardItem.BGBoardSkin != null && m_boardDetailsDisplay != null)
		{
			m_boardDetailsDisplay.ClearVideo();
			m_boardDetailsDisplay.gameObject.SetActive(value: true);
			m_boardDetailsDisplay.AssignDataModels(m_CurrentRewardItem.BGBoardSkin, null);
			m_boardDetailsDisplay.Show();
		}
	}

	private void ShowFinisherReward()
	{
		if (m_CurrentRewardItem.BGFinisher != null && m_finisherDetailsDisplay != null)
		{
			m_finisherDetailsDisplay.ClearVideo();
			m_finisherDetailsDisplay.gameObject.SetActive(value: true);
			m_finisherDetailsDisplay.AssignDataModels(m_CurrentRewardItem.BGFinisher, null);
			m_finisherDetailsDisplay.Show();
		}
	}
}
