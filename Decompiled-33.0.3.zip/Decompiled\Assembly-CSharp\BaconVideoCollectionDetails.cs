using Hearthstone.UI;
using UnityEngine;

public abstract class BaconVideoCollectionDetails : BaconCollectionDetails
{
	[SerializeField]
	private VisualController m_videoPreviewController;

	[SerializeField]
	private DynamicVideoLoader m_videoPreview;

	public override void Show()
	{
		base.Show();
		EventFunctions.TriggerEvent(m_videoPreviewController.transform, "LOAD_VIDEO", new Widget.TriggerEventParameters
		{
			IgnorePlaymaker = true,
			NoDownwardPropagation = true
		});
	}

	public void ClearVideo()
	{
		EventFunctions.TriggerEvent(m_videoPreviewController.transform, "CLEAR_VIDEO", new Widget.TriggerEventParameters
		{
			IgnorePlaymaker = true,
			NoDownwardPropagation = true
		});
		if (m_videoPreview != null)
		{
			m_videoPreview.OnClosed();
		}
	}

	public override void Hide()
	{
		base.Hide();
		ClearVideo();
	}
}
