using Blizzard.GameService.SDK.Client.Integration;
using PegasusShared;
using UnityEngine;

public static class BnetUtils
{
	public static BnetPlayer GetPlayer(BnetAccountId id)
	{
		if (id == null)
		{
			return null;
		}
		BnetPlayer bnetPlayer = BnetNearbyPlayerMgr.Get().FindNearbyStranger(id);
		if (bnetPlayer == null)
		{
			bnetPlayer = BnetPresenceMgr.Get().GetPlayer(id);
		}
		return bnetPlayer;
	}

	public static BnetPlayer GetPlayer(BnetGameAccountId id)
	{
		if (id == null)
		{
			return null;
		}
		BnetPlayer bnetPlayer = BnetNearbyPlayerMgr.Get().FindNearbyStranger(id);
		if (bnetPlayer == null)
		{
			bnetPlayer = BnetPresenceMgr.Get().GetPlayer(id);
		}
		return bnetPlayer;
	}

	public static string GetPlayerBestName(BnetGameAccountId id)
	{
		string text = GetPlayer(id)?.GetBestName();
		if (string.IsNullOrEmpty(text))
		{
			text = GameStrings.Get("GLOBAL_PLAYER_PLAYER");
		}
		return text;
	}

	public static bool HasPlayerBestNamePresence(BnetGameAccountId id)
	{
		return !string.IsNullOrEmpty(GetPlayer(id)?.GetBestName());
	}

	public static string GetInviterBestName(PartyInvite invite)
	{
		if (invite != null && !string.IsNullOrEmpty(invite.InviterName))
		{
			return invite.InviterName;
		}
		string text = ((invite == null) ? null : GetPlayer(invite.InviterId))?.GetBestName();
		if (string.IsNullOrEmpty(text))
		{
			text = GameStrings.Get("GLOBAL_PLAYER_PLAYER");
		}
		return text;
	}

	public static bool CanReceiveWhisperFrom(BnetAccountId id)
	{
		if (BnetPresenceMgr.Get().GetMyPlayer().IsBusy())
		{
			return false;
		}
		if (BnetFriendMgr.Get().IsFriend(id))
		{
			return true;
		}
		return false;
	}

	public static BnetPartyId CreatePartyId(BnetId protoEntityId)
	{
		return new BnetPartyId(protoEntityId.Hi, protoEntityId.Lo);
	}

	public static BnetId CreatePegasusBnetId(BnetPartyId partyId)
	{
		BnetId bnetId = new BnetId();
		BnetEntityId bnetEntityId = partyId.ToBnetEntityId();
		bnetId.Hi = bnetEntityId.High;
		bnetId.Lo = bnetEntityId.Low;
		return bnetId;
	}

	public static BnetId CreatePegasusBnetId(BnetEntityId src)
	{
		return new BnetId
		{
			Hi = src.High,
			Lo = src.Low
		};
	}

	public static string GetNameForProgramId(BnetProgramId programId)
	{
		string nameTag = BnetProgramId.GetNameTag(programId);
		if (nameTag != null)
		{
			return GameStrings.Get(nameTag);
		}
		return null;
	}

	public static ulong? TryGetGameAccountId()
	{
		if (!BattleNet.IsInitialized())
		{
			return null;
		}
		return BattleNet.GetMyGameAccountId().Low;
	}

	public static ulong? TryGetBnetAccountId()
	{
		if (!BattleNet.IsInitialized())
		{
			return null;
		}
		return BattleNet.GetMyAccoundId().Low;
	}

	public static BnetRegion? TryGetBnetRegion()
	{
		if (!BattleNet.IsInitialized())
		{
			return null;
		}
		return BattleNet.GetAccountRegion();
	}

	public static BnetRegion? TryGetGameRegion()
	{
		if (!BattleNet.IsInitialized())
		{
			return null;
		}
		return BattleNet.GetCurrentRegion();
	}

	public static bool IsPlayerPartOfSamplingPercentage(float samplingPercentage)
	{
		float? num = TryGetGameAccountId();
		if (num.HasValue)
		{
			if (num.Value % 100f / 100f >= samplingPercentage)
			{
				return false;
			}
			return true;
		}
		Debug.LogError("Could Not Retrieve Game Account Id");
		return false;
	}
}
