using System.Collections.Generic;
using UnityEngine;

public class BattlegroundsHeroSkinDbfAsset : ScriptableObject
{
	public List<BattlegroundsHeroSkinDbfRecord> Records = new List<BattlegroundsHeroSkinDbfRecord>();
}
