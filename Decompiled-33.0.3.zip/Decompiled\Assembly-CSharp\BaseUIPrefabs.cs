using System;

[Serializable]
public class BaseUIPrefabs
{
	public ChatMgr m_ChatMgrPrefab;
}
