using Hearthstone;
using Hearthstone.DataModels;
using Hearthstone.UI;
using UnityEngine;

public class BaconBoardCollectionDetails : BaconVideoCollectionDetails
{
	[SerializeField]
	private VisualController m_favoriteButtonController;

	private BattlegroundsBoardSkinDataModel m_dataModel;

	private BattlegroundsBoardSkinCollectionPageDataModel m_pageDataModel;

	protected override string DebugTextValue => $"Board ID: {m_dataModel?.BoardDbiId}";

	public override void AssignDataModels(IDataModel dataModel, IDataModel pageDataModel)
	{
		m_dataModel = dataModel as BattlegroundsBoardSkinDataModel;
		m_pageDataModel = pageDataModel as BattlegroundsBoardSkinCollectionPageDataModel;
		m_widget.BindDataModel(dataModel);
	}

	public override void Show()
	{
		base.Show();
		ToggleFavoriteButton();
	}

	public override void Hide()
	{
		base.Hide();
		UIContext.GetRoot().DismissPopup(base.transform.parent.gameObject);
	}

	private void ToggleFavoriteButton()
	{
		if (m_dataModel != null)
		{
			Widget.TriggerEventParameters parameters;
			if (!m_dataModel.IsFavorite && m_dataModel.IsOwned)
			{
				Transform target = m_favoriteButtonController.transform;
				parameters = new Widget.TriggerEventParameters
				{
					IgnorePlaymaker = true,
					NoDownwardPropagation = true
				};
				EventFunctions.TriggerEvent(target, "ENABLE_FAVORITE_BUTTON", parameters);
			}
			else
			{
				Transform target2 = m_favoriteButtonController.transform;
				parameters = new Widget.TriggerEventParameters
				{
					IgnorePlaymaker = true,
					NoDownwardPropagation = true
				};
				EventFunctions.TriggerEvent(target2, "DISABLE_FAVORITE_BUTTON", parameters);
			}
		}
	}

	protected void MakeFavorite()
	{
		if (m_dataModel == null)
		{
			return;
		}
		if (m_dataModel.IsFavorite || !m_dataModel.IsOwned)
		{
			Error.AddDevFatal("BaconBoardCollectionDetails.MakeFavorite: Should not have been called for already-favorite or un-owned board");
			return;
		}
		if (BattlegroundsBoardSkinId.IsDefaultBoardId(m_dataModel.BoardDbiId))
		{
			Network.Get().ClearBattlegroundsFavoriteBoardSkin();
		}
		else
		{
			Network.Get().SetBattlegroundsFavoriteBoardSkin(BattlegroundsBoardSkinId.FromTrustedValue(m_dataModel.BoardDbiId));
		}
		foreach (BattlegroundsBoardSkinDataModel boardSkin in m_pageDataModel.BoardSkinList)
		{
			boardSkin.IsFavorite = boardSkin == m_dataModel;
		}
	}

	protected override bool ValidateDataModels(IDataModel dataModel, IDataModel pageDataModel)
	{
		if (dataModel is BattlegroundsBoardSkinDataModel)
		{
			return pageDataModel is BattlegroundsBoardSkinCollectionPageDataModel;
		}
		return false;
	}

	protected override void ClearDataModels()
	{
		m_dataModel = null;
		m_pageDataModel = null;
	}

	protected override void DetailsEventListener(string eventName)
	{
		if (!(eventName == "OffDialogClick_code"))
		{
			if (eventName == "MakeFavorite_code")
			{
				MakeFavorite();
			}
			else
			{
				Debug.LogWarning("Unrecognized event handled in " + GetType().Name + ": " + eventName);
			}
		}
		else if (CanHide())
		{
			Hide();
		}
	}
}
