using System;
using System.Collections;
using System.Collections.Generic;
using Blizzard.T5.Core;
using Blizzard.T5.Core.Utils;
using UnityEngine;

[CustomEditClass]
public class BigCard : MonoBehaviour
{
	[Serializable]
	public class LayoutData
	{
		public float m_ScaleSec = 0.15f;

		public float m_DriftSec = 10f;
	}

	[Serializable]
	public class SecretLayoutOffsets
	{
		public Vector3 m_InitialOffset = new Vector3(0.1f, 5f, 3.3f);

		public Vector3 m_OpponentInitialOffset = new Vector3(0.1f, 5f, -3.3f);

		public Vector3 m_HiddenInitialOffset = new Vector3(0f, 4f, 4f);

		public Vector3 m_HiddenOpponentInitialOffset = new Vector3(0f, 4f, -4f);
	}

	[Serializable]
	public class SecretLayoutData
	{
		public float m_ShowAnimTime = 0.15f;

		public float m_HideAnimTime = 0.15f;

		public float m_DeathShowAnimTime = 1f;

		public float m_TimeUntilDeathSpell = 1.5f;

		public float m_DriftSec = 5f;

		public Vector3 m_DriftOffset = new Vector3(0f, 0f, 0.05f);

		public Vector3 m_Spacing = new Vector3(2.1f, 0f, 0.7f);

		public Vector3 m_HiddenSpacing = new Vector3(2.4f, 0f, 0.7f);

		public int m_MinCardThreshold = 1;

		public int m_MaxCardThreshold = 5;

		public SecretLayoutOffsets m_MinCardOffsets = new SecretLayoutOffsets();

		public SecretLayoutOffsets m_MaxCardOffsets = new SecretLayoutOffsets();
	}

	private struct KeywordArgs
	{
		public Card card;

		public Actor actor;

		public bool showOnRight;
	}

	private enum BigCardDisplay_RelativeBoardPosition
	{
		INVALID,
		LEFT,
		RIGHT,
		MIDDLE
	}

	public LayoutData m_LayoutData;

	public SecretLayoutData m_SecretLayoutData;

	private static readonly Vector3 INVISIBLE_SCALE = new Vector3(0.0001f, 0.0001f, 0.0001f);

	private const string GHOST_CARD_BOTTOM = "GhostedCard_Bottom";

	private static BigCard s_instance;

	private Card m_card;

	private Actor m_bigCardActor;

	private TooltipPanel m_bigCardAsTooltip;

	private Actor m_twinCardActor;

	private Actor m_evolvingCardActor;

	private List<Actor> m_phoneSecretActors;

	private List<Actor> m_phoneSideQuestActors;

	private List<Actor> m_phoneSigilActors;

	private List<Actor> m_phoneObjectivesActors;

	private readonly PlatformDependentValue<float> PLATFORM_SCALING_FACTOR;

	private EnchantmentBanner m_enchantmentBanner;

	private Actor m_extraBigCardActor;

	public BigCard()
	{
		PLATFORM_SCALING_FACTOR = new PlatformDependentValue<float>(PlatformCategory.Screen)
		{
			PC = 1f,
			Tablet = 1f,
			Phone = 1.3f,
			MiniTablet = 1f
		};
	}

	public PlatformDependentValue<float> GetPlatformScalingFactor()
	{
		return PLATFORM_SCALING_FACTOR;
	}

	private void Awake()
	{
		s_instance = this;
		GameObject gameObject = AssetLoader.Get().InstantiatePrefab("EnchantmentBanner.prefab:e7058664cd0b13f4bb45e5b5f0385f34", AssetLoadingOptions.IgnorePrefabPosition);
		m_enchantmentBanner = gameObject.GetComponent<EnchantmentBanner>();
	}

	private void OnDestroy()
	{
		s_instance = null;
	}

	public static BigCard Get()
	{
		return s_instance;
	}

	public Card GetCard()
	{
		return m_card;
	}

	public Actor GetExtraBigCardActor()
	{
		return m_extraBigCardActor;
	}

	public Actor GetBigCardActor()
	{
		return m_bigCardActor;
	}

	public void Show(Card card)
	{
		m_card = card;
		if (GameState.Get() != null && !GameState.Get().GetGameEntity().NotifyOfCardTooltipDisplayShow(card))
		{
			return;
		}
		Zone zone = card.GetZone();
		if ((bool)UniversalInputManager.UsePhoneUI && zone is ZoneSecret)
		{
			if (card.GetEntity().IsBobQuest())
			{
				DisplayBigCardAsTooltip();
			}
			else if (card.GetEntity().IsSideQuest())
			{
				LoadAndDisplayTooltipPhoneSideQuests();
			}
			else if (card.GetEntity().IsSigil())
			{
				LoadAndDisplayTooltipPhoneSigils();
			}
			else if (card.GetEntity().IsObjective())
			{
				LoadAndDisplayTooltipPhoneObjectives();
			}
			else
			{
				LoadAndDisplayTooltipPhoneSecrets();
			}
		}
		else
		{
			LoadAndDisplayBigCard();
		}
	}

	public void Hide()
	{
		if (GameState.Get() != null)
		{
			GameState.Get().GetGameEntity().NotifyOfCardTooltipDisplayHide(m_card);
		}
		HideBigCard();
		HideTooltipPhoneSecrets();
		HideTooltipPhoneSideQuests();
		HideTooltipPhoneSigils();
		HideTooltipPhoneObjectives();
		m_card = null;
	}

	public bool Hide(Card card)
	{
		if (m_card != card)
		{
			return false;
		}
		Hide();
		return true;
	}

	public void ShowSecretDeaths(Map<Player, DeadSecretGroup> deadSecretMap)
	{
		if (deadSecretMap == null || deadSecretMap.Count == 0)
		{
			return;
		}
		int num = 0;
		foreach (DeadSecretGroup value in deadSecretMap.Values)
		{
			Card mainCard = value.GetMainCard();
			List<Card> cards = value.GetCards();
			List<Actor> list = new List<Actor>();
			for (int i = 0; i < cards.Count; i++)
			{
				Card card = cards[i];
				Actor item = LoadPhoneSecret(card);
				list.Add(item);
			}
			DisplayPhoneSecrets(mainCard, list, showDeath: true);
			num++;
		}
	}

	private void LoadAndDisplayBigCard()
	{
		if ((bool)m_extraBigCardActor)
		{
			m_extraBigCardActor.Destroy();
		}
		if ((bool)m_bigCardActor)
		{
			m_bigCardActor.Destroy();
		}
		if (ActorNames.ShouldDisplayTooltipInsteadOfBigCard(m_card.GetEntity()))
		{
			DisplayBigCardAsTooltip();
			return;
		}
		string bigCardActor = ActorNames.GetBigCardActor(m_card.GetEntity());
		if (bigCardActor == "Card_Hidden.prefab:1a94649d257bc284ca6e2962f634a8b9")
		{
			return;
		}
		GameObject gameObject = AssetLoader.Get().InstantiatePrefab(bigCardActor, AssetLoadingOptions.IgnorePrefabPosition);
		m_bigCardActor = gameObject.GetComponent<Actor>();
		SetupActor(m_card, m_bigCardActor);
		int num = m_card.GetEntity().GetTag(GAME_TAG.DISGUISED_TWIN);
		if (num > 0)
		{
			using (DefLoader.DisposableFullDef disposableFullDef = DefLoader.Get().GetFullDef(num))
			{
				bigCardActor = ActorNames.GetHandActor(disposableFullDef?.EntityDef, m_card.GetEntity().GetPremiumType());
				GameObject gameObject2 = AssetLoader.Get().InstantiatePrefab(bigCardActor, AssetLoadingOptions.IgnorePrefabPosition);
				m_twinCardActor = gameObject2.GetComponent<Actor>();
				LayerUtils.SetLayer(m_twinCardActor, GameLayer.Tooltip);
				m_twinCardActor.SetFullDef(disposableFullDef);
				m_twinCardActor.SetPremium(m_card.GetEntity().GetPremiumType());
				m_twinCardActor.SetCardBackSideOverride(m_card.GetEntity().GetControllerSide());
				m_twinCardActor.SetWatermarkCardSetOverride(m_card.GetEntity().GetWatermarkCardSetOverride());
				m_twinCardActor.UpdateAllComponents();
			}
		}
		Entity extraMouseOverBigCardEntity = GameState.Get().GetGameEntity().GetExtraMouseOverBigCardEntity(m_card.GetEntity());
		if (extraMouseOverBigCardEntity != null)
		{
			string bigCardActor2 = ActorNames.GetBigCardActor(extraMouseOverBigCardEntity);
			if (bigCardActor2 != "Card_Hidden.prefab:1a94649d257bc284ca6e2962f634a8b9")
			{
				GameObject gameObject3 = AssetLoader.Get().InstantiatePrefab(bigCardActor2, AssetLoadingOptions.IgnorePrefabPosition);
				m_extraBigCardActor = gameObject3.GetComponent<Actor>();
				SetupActor(extraMouseOverBigCardEntity.GetCard(), m_extraBigCardActor);
				m_extraBigCardActor.transform.parent = m_bigCardActor.transform;
				Vector3 localScale = new Vector3(0.75f, 1f, 0.75f);
				if (UniversalInputManager.Get().IsTouchMode() && GameState.Get() != null && GameState.Get().GetGameEntity() != null && GameState.Get().GetGameEntity().GetGameOptions()
					.GetBooleanOption(GameEntityOption.CAN_ADJUST_BIG_CARD_HORIZONTALLY))
				{
					localScale.x *= 0.92f;
					localScale.z *= 0.92f;
				}
				m_extraBigCardActor.transform.localScale = localScale;
			}
		}
		int num2 = m_card.GetEntity().GetTag(GAME_TAG.BACON_EVOLUTION_CARD_ID);
		if (num2 > 0)
		{
			using (DefLoader.DisposableFullDef disposableFullDef2 = DefLoader.Get().GetFullDef(num2))
			{
				string handActor = ActorNames.GetHandActor(disposableFullDef2?.EntityDef, m_card.GetEntity().GetPremiumType());
				GameObject gameObject4 = AssetLoader.Get().InstantiatePrefab(handActor, AssetLoadingOptions.IgnorePrefabPosition);
				m_evolvingCardActor = gameObject4.GetComponent<Actor>();
				SetupActor(m_card, m_evolvingCardActor);
				m_evolvingCardActor.SetEntity(null);
				m_evolvingCardActor.transform.parent = m_bigCardActor.transform;
				m_evolvingCardActor.transform.localScale = Vector3.one;
				GameObject gameObject5 = GameObjectUtils.FindChildBySubstring(gameObject4, "EvolutionVFX");
				if (gameObject5 != null)
				{
					gameObject5.SetActive(value: true);
				}
				m_evolvingCardActor.SetFullDef(disposableFullDef2);
				m_evolvingCardActor.SetPremium(m_card.GetEntity().GetPremiumType());
				m_evolvingCardActor.SetCardBackSideOverride(m_card.GetEntity().GetControllerSide());
				m_evolvingCardActor.SetWatermarkCardSetOverride(m_card.GetEntity().GetWatermarkCardSetOverride());
				m_evolvingCardActor.UpdateAllComponents();
			}
		}
		if (ShouldUseBonesForBigCardPlacement())
		{
			DisplayBigCardWithBones();
		}
		else
		{
			DisplayBigCard();
		}
	}

	private bool ShouldUseBonesForBigCardPlacement()
	{
		if (m_card == null)
		{
			return false;
		}
		if (m_bigCardActor == null)
		{
			return false;
		}
		if (GameState.Get() == null)
		{
			return false;
		}
		GameEntity gameEntity = GameState.Get().GetGameEntity();
		if (gameEntity == null)
		{
			return false;
		}
		if (!gameEntity.GetGameOptions().GetBooleanOption(GameEntityOption.USE_BONES_FOR_BIG_CARD_PLACEMENT))
		{
			return false;
		}
		if (m_card == null)
		{
			return false;
		}
		Zone zone = m_card.GetZone();
		if (!(zone is ZonePlay) && !(zone is ZoneLettuceAbility))
		{
			return false;
		}
		Actor actor = m_card.GetActor();
		if (actor == null)
		{
			return false;
		}
		if (m_card.GetEntity().IsMinion())
		{
			BigCardDisplayBones componentInChildren = actor.GetComponentInChildren<BigCardDisplayBones>();
			if (componentInChildren == null)
			{
				return false;
			}
			if (!componentInChildren.HasBonesForCurrentPlatform())
			{
				return false;
			}
		}
		else
		{
			if (!m_card.GetEntity().IsLettuceAbility())
			{
				return false;
			}
			MercenariesAbilityTray abilityTray = ZoneMgr.Get().GetLettuceZoneController().GetAbilityTray();
			if (abilityTray == null)
			{
				return false;
			}
			abilityTray.GetBigCardBones(out var left, out var right);
			if (left == null || right == null)
			{
				return false;
			}
		}
		if (!GameState.Get().MercenariesAllowBigCardBones())
		{
			return false;
		}
		return true;
	}

	private void HideBigCard()
	{
		if ((bool)m_extraBigCardActor)
		{
			m_extraBigCardActor.Destroy();
			m_extraBigCardActor = null;
		}
		if ((bool)m_bigCardActor)
		{
			Card card = m_bigCardActor.GetCard();
			if (card != null)
			{
				Actor actor = card.GetActor();
				if (actor != null && actor.gameObject != null)
				{
					HeroBuddyWidget component = actor.GetComponent<HeroBuddyWidget>();
					if (component != null)
					{
						component.ShowProgressText(value: false);
					}
				}
			}
			m_enchantmentBanner.ResetEnchantments();
			iTween.Stop(m_bigCardActor.gameObject);
			m_bigCardActor.Destroy();
			m_bigCardActor = null;
			TooltipPanelManager.Get().HideKeywordHelp();
		}
		if ((bool)m_bigCardAsTooltip)
		{
			UnityEngine.Object.Destroy(m_bigCardAsTooltip);
		}
		if ((bool)m_twinCardActor)
		{
			iTween.Stop(m_twinCardActor.gameObject);
			m_twinCardActor.Destroy();
			m_twinCardActor = null;
		}
		if ((bool)m_evolvingCardActor)
		{
			iTween.Stop(m_evolvingCardActor.gameObject);
			m_evolvingCardActor.Destroy();
			m_evolvingCardActor = null;
		}
	}

	private void DisplayBigCardAsTooltip()
	{
		if (m_bigCardAsTooltip != null)
		{
			UnityEngine.Object.Destroy(m_bigCardAsTooltip.gameObject);
		}
		Vector3 vector;
		if (!m_card.GetEntity().IsBobQuest())
		{
			vector = ((!ShowBigCardOnRight()) ? new Vector3(-2f, 0f, 0f) : new Vector3(2f, 0f, 0f));
		}
		else
		{
			vector = ((!UniversalInputManager.UsePhoneUI) ? new Vector3(0f, 0f, 1.33f) : new Vector3(0f, 0f, 2.478f));
			if (m_card.GetControllerSide() == Player.Side.OPPOSING)
			{
				vector.z *= -1f;
			}
		}
		Vector3 position = m_card.transform.position + vector;
		m_bigCardAsTooltip = TooltipPanelManager.Get().CreateKeywordPanel(0);
		m_bigCardAsTooltip.Reset();
		m_bigCardAsTooltip.Initialize(m_card.GetEntity().GetName(), m_card.GetEntity().GetCardTextInHand());
		m_bigCardAsTooltip.SetScale(TooltipPanel.GAMEPLAY_SCALE);
		m_bigCardAsTooltip.transform.position = position;
		RenderUtils.SetAlpha(m_bigCardAsTooltip.gameObject, 0f);
		iTween.FadeTo(m_bigCardAsTooltip.gameObject, iTween.Hash("alpha", 1, "time", 0.1f));
	}

	private BigCardDisplay_RelativeBoardPosition GetBoardPositionOfSourceCard()
	{
		if (m_card == null)
		{
			return BigCardDisplay_RelativeBoardPosition.INVALID;
		}
		int zonePosition = m_card.GetZonePosition();
		float num = (float)(m_card.GetZone().GetCardCount() + 1) / 2f;
		float num2 = (float)zonePosition - num;
		if (Mathf.Abs(num2) <= 0.5f)
		{
			return BigCardDisplay_RelativeBoardPosition.MIDDLE;
		}
		if (num2 < 0f)
		{
			return BigCardDisplay_RelativeBoardPosition.LEFT;
		}
		return BigCardDisplay_RelativeBoardPosition.RIGHT;
	}

	private Vector3 GetScaleForCard(BigCardBoneLayout.ScaleSettings platformScale, Card card)
	{
		if (platformScale == null || card == null)
		{
			return Vector3.one;
		}
		if (card.GetEntity().IsMinion())
		{
			return Vector3.one * platformScale.m_BigCardScale_Minion;
		}
		if (card.GetEntity().IsLettuceAbility())
		{
			return Vector3.one * platformScale.m_BigCardScale_LettuceAbility;
		}
		return Vector3.one;
	}

	private Vector3 AdjustYValueToBeLevelOnBoard(Vector3 bonePosition, Zone ownerZone)
	{
		ZonePlay zonePlay = ownerZone as ZonePlay;
		if (zonePlay == null)
		{
			return bonePosition;
		}
		float y = zonePlay.GetComponent<Collider>().bounds.center.y;
		float num = ((!UniversalInputManager.UsePhoneUI) ? 0.33f : 0.3f);
		float num2 = (bonePosition.y = y + num);
		return bonePosition;
	}

	private void BigCardBones_UpdateEnchantmentBanner()
	{
		if (m_bigCardActor.GetCard().GetZone() is ZoneHand)
		{
			m_bigCardActor.SetEntity(m_bigCardActor.GetEntity());
			m_bigCardActor.UpdateTextComponents(m_bigCardActor.GetEntity());
		}
		else if (m_twinCardActor == null)
		{
			m_enchantmentBanner.UpdateEnchantments(m_card, m_bigCardActor);
		}
		else
		{
			m_enchantmentBanner.ResetEnchantments();
		}
	}

	private void BigCardBones_ShowTooltips(bool showOnRight)
	{
		if (GameState.Get() != null)
		{
			GameState.Get().GetGameEntity().NotifyOfCardTooltipBigCardActorShow();
		}
		KeywordArgs keywordArgs = default(KeywordArgs);
		keywordArgs.card = m_card;
		keywordArgs.actor = m_bigCardActor;
		keywordArgs.showOnRight = showOnRight;
		KeywordArgs keywordArgs2 = keywordArgs;
		float? overrideScale = null;
		if (m_card.GetEntity().IsHeroPower())
		{
			overrideScale = 0.6f;
		}
		TooltipPanelManager.Get().UpdateKeywordHelp(keywordArgs2.card, keywordArgs2.actor, keywordArgs2.showOnRight, overrideScale);
	}

	private void BigCardBones_ShowStateSpells()
	{
		if (m_card.GetEntity().IsSilenced())
		{
			m_bigCardActor.ActivateSpellBirthState(SpellType.SILENCE);
			if (m_twinCardActor != null)
			{
				m_twinCardActor.ActivateSpellBirthState(SpellType.SILENCE);
			}
		}
	}

	private void BigCardBones_ScaleAndPlaceBigCard(Actor bigCardActor, Zone actorZone, Vector3 scale, GameObject bone)
	{
		if (!(bigCardActor == null) && !(actorZone == null) && !(bone == null))
		{
			bigCardActor.transform.position = AdjustYValueToBeLevelOnBoard(bone.transform.position, actorZone);
			bigCardActor.transform.localScale = scale;
		}
	}

	private void BigCardBones_ActivateAndScaleIn(bool showTooltipsOnRight)
	{
		if (m_bigCardActor != null)
		{
			Vector3 localScale = m_bigCardActor.transform.localScale;
			m_bigCardActor.transform.localScale = Vector3.one;
			bool? flag = showTooltipsOnRight;
			Hashtable args = iTween.Hash("scale", localScale, "time", m_LayoutData.m_ScaleSec, "oncompleteparams", flag, "oncomplete", (Action<object>)delegate(object tooltipsOnRight)
			{
				if (tooltipsOnRight is bool?)
				{
					bool? flag2 = tooltipsOnRight as bool?;
					bool showOnRight = flag2.HasValue && flag2.Value;
					BigCardBones_ShowTooltips(showOnRight);
				}
			});
			iTween.ScaleTo(m_bigCardActor.gameObject, args);
		}
		if (m_extraBigCardActor != null)
		{
			Vector3 localScale2 = m_bigCardActor.transform.localScale;
			m_extraBigCardActor.transform.localScale = Vector3.one;
			iTween.ScaleTo(m_extraBigCardActor.gameObject, localScale2, m_LayoutData.m_ScaleSec);
		}
		if (m_bigCardActor != null)
		{
			m_bigCardActor.Show();
		}
	}

	private void DisplayCardInPlayWithBones(out bool showTooltipsOnRight)
	{
		Actor actor = m_card.GetActor();
		showTooltipsOnRight = false;
		if (actor == null)
		{
			return;
		}
		BigCardDisplayBones componentInChildren = actor.GetComponentInChildren<BigCardDisplayBones>();
		if (componentInChildren == null)
		{
			return;
		}
		componentInChildren.GetRigForCurrentPlatform(out var rig, out var scale);
		if (rig == null)
		{
			return;
		}
		BigCardBoneLayout component = rig.GetComponent<BigCardBoneLayout>();
		if (!(component == null))
		{
			GameObject bone;
			GameObject bone2;
			switch (GetBoardPositionOfSourceCard())
			{
			case BigCardDisplay_RelativeBoardPosition.LEFT:
				bone = component.m_InnerRightBone;
				bone2 = component.m_OuterRightBone;
				showTooltipsOnRight = false;
				break;
			case BigCardDisplay_RelativeBoardPosition.RIGHT:
				bone = component.m_InnerLeftBone;
				bone2 = component.m_OuterLeftBone;
				showTooltipsOnRight = true;
				break;
			case BigCardDisplay_RelativeBoardPosition.MIDDLE:
				bone = component.m_InnerLeftBone;
				bone2 = component.m_InnerRightBone;
				showTooltipsOnRight = false;
				break;
			default:
				Log.Gameplay.PrintError("Unknown value for BigCardDisplay_RelativeBoardPosition.");
				return;
			}
			Transform parent = rig.transform.parent;
			Vector3 localScale = rig.transform.localScale;
			rig.transform.parent = null;
			rig.transform.localScale = Vector3.one;
			Zone zone = m_bigCardActor.GetCard().GetZone();
			if (m_bigCardActor != null)
			{
				Vector3 scaleForCard = GetScaleForCard(scale, m_bigCardActor.GetCard());
				BigCardBones_ScaleAndPlaceBigCard(m_bigCardActor, zone, scaleForCard, bone);
				BigCardBones_UpdateEnchantmentBanner();
			}
			if (m_extraBigCardActor != null)
			{
				Vector3 scaleForCard2 = GetScaleForCard(scale, m_extraBigCardActor.GetCard());
				BigCardBones_ScaleAndPlaceBigCard(m_extraBigCardActor, zone, scaleForCard2, bone2);
			}
			rig.transform.localScale = localScale;
			rig.transform.parent = parent;
		}
	}

	private void DisplayLettuceAbilitiesWithBones(out bool showTooltipsOnRight)
	{
		MercenariesAbilityTray abilityTray = ZoneMgr.Get().GetLettuceZoneController().GetAbilityTray();
		abilityTray.GetBigCardBones(out var left, out var right);
		GameObject gameObject;
		if (abilityTray.GetTrayPositionOfAbility(m_card) < 2)
		{
			gameObject = left;
			showTooltipsOnRight = true;
		}
		else
		{
			gameObject = right;
			showTooltipsOnRight = false;
		}
		if (!(gameObject == null))
		{
			float num = abilityTray.GetAbilityPreviewScaleForCurrentPlatform();
			if (num <= 0f)
			{
				Debug.LogError($"Getting the ability card scale from the ability tray's scale settings returned an invalid scale value of {num} when it should be a positive value. Changing value to 1.0.");
				num = 1f;
			}
			Vector3 scale = Vector3.one * num;
			BigCardBones_ScaleAndPlaceBigCard(m_bigCardActor, m_bigCardActor.GetCard().GetZone(), scale, gameObject);
		}
	}

	private void DisplayBigCardWithBones()
	{
		bool showTooltipsOnRight = false;
		Entity entity = m_card.GetEntity();
		if (entity != null)
		{
			if (entity.IsLettuceAbility())
			{
				DisplayLettuceAbilitiesWithBones(out showTooltipsOnRight);
			}
			else if (entity.IsMinion())
			{
				DisplayCardInPlayWithBones(out showTooltipsOnRight);
			}
			FitInsideScreenVerticalAxis();
			BigCardBones_ShowStateSpells();
			BigCardBones_ActivateAndScaleIn(showTooltipsOnRight);
		}
	}

	private void DisplayBigCard()
	{
		Entity entity = m_card.GetEntity();
		bool flag = entity.GetController().IsFriendlySide();
		Zone zone = m_card.GetZone();
		Bounds bounds = m_bigCardActor.GetMeshRenderer().bounds;
		Vector3 position = m_card.GetActor().transform.position;
		Vector3 vector = new Vector3(0f, 0f, 0f);
		Vector3 vector2 = new Vector3(0f, 0f, 0f);
		Vector3 vector3 = new Vector3(1.1f, 1.1f, 1.1f);
		float? overrideScale = null;
		if (zone is ZoneHero)
		{
			vector = ((!flag) ? new Vector3(0f, 4f, (0f - bounds.size.z) * 0.7f) : new Vector3(0f, 4f, 0f));
		}
		else if (zone is ZoneWeapon)
		{
			if ((bool)UniversalInputManager.UsePhoneUI)
			{
				if (flag)
				{
					vector3 = new Vector3(1.98f, 1.27f, 1.98f);
					vector = new Vector3(5.45f, 0f, bounds.size.z * 0.9f);
				}
				else
				{
					vector3 = new Vector3(1.65f, 1.65f, 1.65f);
					vector = new Vector3(-1.57f, 0f, -1f);
				}
			}
			else
			{
				vector3 = new Vector3(1.65f, 1.65f, 1.65f);
				vector = ((!flag) ? new Vector3(-1.57f, 0f, -1f) : new Vector3(0f, 0f, bounds.size.z * 0.9f));
			}
			vector3 *= (float)PLATFORM_SCALING_FACTOR;
		}
		else if (zone is ZoneHeroPower)
		{
			if (!UniversalInputManager.UsePhoneUI)
			{
				vector = ((!flag) ? new Vector3(0f, 4f, -2.6f) : new Vector3(0f, 4f, 2.69f));
			}
			else
			{
				vector3 = new Vector3(1.3f, 1f, 1.3f);
				vector = ((!flag) ? new Vector3(-3.5f, 8f, -3.35f) : new Vector3(-3.5f, 8f, 3.5f));
			}
			overrideScale = 0.6f;
			if ((bool)m_evolvingCardActor)
			{
				bool flag2 = ShowBigCardOnRight();
				if ((bool)UniversalInputManager.UsePhoneUI)
				{
					vector3 = new Vector3(1.1f, 1f, 1.1f);
					Vector3 vector4 = new Vector3(1.5f, 0f, 0f);
					if (flag2)
					{
						vector -= vector4;
					}
					else
					{
						vector += vector4;
					}
				}
				if (flag2)
				{
					m_evolvingCardActor.transform.localPosition = new Vector3(2.2f, 0f, 0f);
				}
				else
				{
					m_evolvingCardActor.transform.localPosition = new Vector3(-2.2f, 0f, 0f);
				}
			}
		}
		else if (zone is ZoneBattlegroundHeroBuddy)
		{
			if (!UniversalInputManager.UsePhoneUI)
			{
				vector = ((!flag) ? new Vector3(0.33f, 4f, -3.7f) : new Vector3(0.4f, 4f, 3.17f));
			}
			else
			{
				vector3 = new Vector3(1f, 1f, 1f);
				vector = ((!flag) ? new Vector3(-0.38f, 8f, -4.15f) : new Vector3(-0.38f, 8f, 4.1f));
			}
		}
		else if (zone is ZoneBattlegroundQuestReward)
		{
			PlatformDependentVector3 platformDependentVector = new PlatformDependentVector3(PlatformCategory.Screen)
			{
				PC = new Vector3(-3.11f, 0f, 0f),
				Phone = new Vector3(-6.71f, 0f, 0f)
			};
			PlatformDependentVector3 platformDependentVector2 = new PlatformDependentVector3(PlatformCategory.Screen)
			{
				PC = new Vector3(1.5f, 4f, 3.17f),
				Phone = new Vector3(4.33f, 4.1f, 3.1f)
			};
			PlatformDependentVector3 platformDependentVector3 = new PlatformDependentVector3(PlatformCategory.Screen)
			{
				PC = new Vector3(1.54f, 4f, -2.8f),
				Phone = new Vector3(4.17f, 4.1f, -2.45f)
			};
			vector = ((!flag) ? ((zone as ZoneBattlegroundQuestReward).m_isHeroPower ? (platformDependentVector3.Value + platformDependentVector.Value) : ((Vector3)platformDependentVector3)) : ((zone as ZoneBattlegroundQuestReward).m_isHeroPower ? (platformDependentVector2.Value + platformDependentVector.Value) : ((Vector3)platformDependentVector2)));
			vector3 = ((!UniversalInputManager.UsePhoneUI) ? new Vector3(1.3f, 1f, 1.3f) : new Vector3(1.85f, 1f, 1.85f));
		}
		else if (zone is ZoneSecret)
		{
			vector3 = new Vector3(1.65f, 1.65f, 1.65f);
			vector = new Vector3(bounds.size.x + 0.3f, 0f, 0f);
		}
		else if (zone is ZoneHand)
		{
			vector = new Vector3(bounds.size.x * 0.7f, 4f, (0f - bounds.size.z) * 0.8f);
			vector3 = new Vector3(1.65f, 1.65f, 1.65f);
		}
		else if (zone is ZoneLettuceAbility)
		{
			MercenariesAbilityTray abilityTray = ZoneMgr.Get().GetLettuceZoneController().GetAbilityTray();
			abilityTray.GetBigCardBones(out var left, out var right);
			GameObject gameObject = ((abilityTray.GetTrayPositionOfAbility(m_card) < 2) ? left : right);
			if (gameObject != null)
			{
				position = gameObject.gameObject.transform.position;
				vector = Vector3.zero;
			}
			vector3 = new Vector3(1.65f, 1.65f, 1.65f) * PLATFORM_SCALING_FACTOR;
		}
		else
		{
			if ((bool)UniversalInputManager.UsePhoneUI)
			{
				vector3 = new Vector3(2f, 2f, 2f);
				vector = ((!ShowBigCardOnRight()) ? new Vector3(0f - bounds.size.x - 2.2f, 0f, 0f) : new Vector3(bounds.size.x + 2.2f, 0f, 0f));
			}
			else
			{
				vector3 = new Vector3(1.65f, 1.65f, 1.65f);
				if (!m_twinCardActor)
				{
					vector = ((!ShowBigCardOnRight()) ? new Vector3(0f - bounds.size.x - 0.7f, 0f, 0f) : new Vector3(bounds.size.x + 0.7f, 0f, 0f));
				}
				else if (UnityEngine.Random.Range(0, 2) == 0)
				{
					vector = new Vector3(bounds.size.x + 0.7f, 0f, 0f);
					vector2 = new Vector3(0f - bounds.size.x - 0.7f, 0f, 0f);
				}
				else
				{
					vector = new Vector3(0f - bounds.size.x - 0.7f, 0f, 0f);
					vector2 = new Vector3(bounds.size.x + 0.7f, 0f, 0f);
				}
			}
			if (zone is ZonePlay)
			{
				if ((bool)m_extraBigCardActor)
				{
					bool flag3 = ShowBigCardOnRight();
					if (flag3)
					{
						m_extraBigCardActor.transform.localPosition = new Vector3(1.9f, 0.1f, 0.07f);
					}
					else
					{
						m_extraBigCardActor.transform.localPosition = new Vector3(-1.9f, 0.1f, 0.07f);
					}
					if (UniversalInputManager.Get().IsTouchMode() && GameState.Get() != null && GameState.Get().GetGameEntity() != null && GameState.Get().GetGameEntity().GetGameOptions()
						.GetBooleanOption(GameEntityOption.CAN_ADJUST_BIG_CARD_HORIZONTALLY))
					{
						vector3 *= 0.8f;
						if (flag3)
						{
							vector += new Vector3(-2f, 0f, 0f);
						}
						else
						{
							vector += new Vector3(2f, 0f, 0f);
						}
					}
				}
				vector += new Vector3(0f, 0.1f, 0f);
				vector2 += new Vector3(0f, 0.1f, 0f);
				vector3 *= (float)PLATFORM_SCALING_FACTOR;
			}
		}
		Vector3 vector5 = new Vector3(0.02f, 0.02f, 0.02f);
		Vector3 position2 = position + vector + vector5;
		if (zone is ZonePlay && entity.IsMinion() && entity.HasTag(GAME_TAG.LETTUCE_CONTROLLER))
		{
			float y = (zone as ZonePlay).GetComponent<Collider>().bounds.center.y;
			float num = ((!UniversalInputManager.UsePhoneUI) ? 0.2f : 0.3f);
			float num2 = (position2.y = y + num);
		}
		Vector3 localScale = new Vector3(1f, 1f, 1f);
		Transform parent = m_bigCardActor.transform.parent;
		m_bigCardActor.transform.localScale = vector3;
		m_bigCardActor.transform.position = position2;
		m_bigCardActor.transform.parent = null;
		Transform parent2 = null;
		if ((bool)m_twinCardActor)
		{
			parent2 = m_twinCardActor.transform.parent;
		}
		Vector3 position3 = position + vector2 + vector5;
		if (m_card.GetEntity().GetTag(GAME_TAG.DISGUISED_TWIN) > 0 && m_twinCardActor != null)
		{
			m_twinCardActor.transform.localScale = vector3;
			m_twinCardActor.transform.position = position3;
			m_twinCardActor.transform.parent = null;
		}
		if (zone is ZoneHand)
		{
			m_bigCardActor.SetEntity(entity);
			m_bigCardActor.UpdateTextComponents(entity);
		}
		else
		{
			if (m_twinCardActor == null)
			{
				m_enchantmentBanner.UpdateEnchantments(m_card, m_bigCardActor);
			}
			else
			{
				m_enchantmentBanner.ResetEnchantments();
			}
			if ((bool)UniversalInputManager.UsePhoneUI && m_enchantmentBanner.IsBannerVisible())
			{
				float num3 = ((m_enchantmentBanner.GetEnchantmentCount() > 1) ? 0.75f : 0.85f);
				vector3 *= num3;
				m_bigCardActor.transform.localScale = vector3;
			}
		}
		FitInsideScreenVerticalAxis();
		m_bigCardActor.transform.parent = parent;
		m_bigCardActor.transform.localScale = localScale;
		if ((bool)m_twinCardActor)
		{
			m_twinCardActor.transform.parent = parent2;
			m_twinCardActor.transform.localScale = localScale;
		}
		Vector3 position4 = m_bigCardActor.transform.position;
		m_bigCardActor.transform.position -= vector5;
		Vector3 position5 = new Vector3(0f, 0f, 0f);
		if ((bool)m_twinCardActor)
		{
			position5 = m_twinCardActor.transform.position;
			m_twinCardActor.transform.position -= vector5;
		}
		KeywordArgs keywordArgs = default(KeywordArgs);
		keywordArgs.card = m_card;
		keywordArgs.actor = m_bigCardActor;
		keywordArgs.showOnRight = ShowBigCardOnRight();
		if (zone is ZoneHand)
		{
			Hashtable args = iTween.Hash("scale", vector3, "time", m_LayoutData.m_ScaleSec, "oncompleteparams", keywordArgs, "oncomplete", (Action<object>)delegate(object obj)
			{
				if (!UniversalInputManager.UsePhoneUI)
				{
					KeywordArgs keywordArgs3 = (KeywordArgs)obj;
					TooltipPanelManager.Get().UpdateKeywordHelp(keywordArgs3.card, keywordArgs3.actor, keywordArgs3.showOnRight);
				}
			});
			iTween.ScaleTo(m_bigCardActor.gameObject, args);
		}
		else
		{
			iTween.ScaleTo(m_bigCardActor.gameObject, vector3, m_LayoutData.m_ScaleSec);
			if (m_twinCardActor != null)
			{
				KeywordArgs keywordArgs2 = default(KeywordArgs);
				keywordArgs2.card = m_card;
				keywordArgs2.actor = m_twinCardActor;
				keywordArgs2.showOnRight = ShowBigCardOnRight();
				iTween.ScaleTo(m_twinCardActor.gameObject, vector3, m_LayoutData.m_ScaleSec);
				iTween.MoveTo(m_twinCardActor.gameObject, position5, m_LayoutData.m_DriftSec);
				m_twinCardActor.transform.rotation = Quaternion.identity;
				m_twinCardActor.Show();
			}
			else if (!UniversalInputManager.UsePhoneUI)
			{
				if (m_extraBigCardActor != null || m_evolvingCardActor != null)
				{
					keywordArgs.showOnRight = !keywordArgs.showOnRight;
				}
				TooltipPanelManager.Get().UpdateKeywordHelp(keywordArgs.card, keywordArgs.actor, keywordArgs.showOnRight, overrideScale);
			}
		}
		iTween.MoveTo(m_bigCardActor.gameObject, position4, m_LayoutData.m_DriftSec);
		m_bigCardActor.transform.rotation = Quaternion.identity;
		if (GameState.Get() != null)
		{
			GameState.Get().GetGameEntity().NotifyOfCardTooltipBigCardActorShow();
		}
		m_bigCardActor.Show();
		if ((bool)UniversalInputManager.UsePhoneUI)
		{
			TooltipPanelManager.Get().UpdateKeywordHelp(m_card, m_bigCardActor, ShowKeywordOnRight(), overrideScale);
		}
		if (entity.IsSilenced())
		{
			m_bigCardActor.ActivateSpellBirthState(SpellType.SILENCE);
			if (m_twinCardActor != null)
			{
				m_twinCardActor.ActivateSpellBirthState(SpellType.SILENCE);
			}
		}
	}

	private bool ShowBigCardOnRight()
	{
		if (UniversalInputManager.Get().IsTouchMode())
		{
			return ShowBigCardOnRightTouch();
		}
		return ShowBigCardOnRightMouse();
	}

	private bool ShowBigCardOnRightMouse()
	{
		if (m_card.GetEntity().IsHero() || m_card.GetEntity().IsHeroPower() || m_card.GetEntity().IsSecret())
		{
			return true;
		}
		if (m_card.GetEntity().GetCardId() == "TU4c_007")
		{
			return false;
		}
		ZonePlay zonePlay = m_card.GetZone() as ZonePlay;
		if (zonePlay != null)
		{
			Actor actor = m_card.GetActor();
			if (actor != null)
			{
				MeshRenderer meshRenderer = actor.GetMeshRenderer();
				if (meshRenderer != null)
				{
					float x = meshRenderer.bounds.center.x;
					float num = zonePlay.GetComponent<BoxCollider>().bounds.center.x + zonePlay.m_BigCardCenterOffset;
					return x < num;
				}
			}
		}
		return true;
	}

	private bool ShowBigCardOnRightTouch()
	{
		if (m_card.GetEntity().IsHero() || m_card.GetEntity().IsHeroPower() || m_card.GetEntity().IsSecret())
		{
			return false;
		}
		if (m_card.GetEntity().GetCardId() == "TU4c_007")
		{
			return false;
		}
		ZonePlay zonePlay = m_card.GetZone() as ZonePlay;
		if (zonePlay != null)
		{
			float num = (GameState.Get().GetGameEntity().GetGameOptions()
				.GetBooleanOption(GameEntityOption.CAN_ADJUST_BIG_CARD_HORIZONTALLY) ? ((!UniversalInputManager.UsePhoneUI) ? 1f : 0.5f) : ((!UniversalInputManager.UsePhoneUI) ? (-2.5f) : 0f));
			Actor actor = m_card.GetActor();
			if (actor != null)
			{
				MeshRenderer meshRenderer = actor.GetMeshRenderer();
				if (meshRenderer != null)
				{
					float x = meshRenderer.bounds.center.x;
					float num2 = zonePlay.GetComponent<BoxCollider>().bounds.center.x + num;
					return x < num2;
				}
			}
		}
		return false;
	}

	private bool ShowKeywordOnRight()
	{
		if (m_card.GetEntity().IsHeroPower())
		{
			return true;
		}
		if (m_card.GetEntity().IsWeapon())
		{
			return false;
		}
		if (m_card.GetEntity().IsHero() || m_card.GetEntity().IsSecretLike())
		{
			return false;
		}
		if (m_card.GetEntity().GetCardId() == "TU4c_007")
		{
			return false;
		}
		ZonePlay zonePlay = m_card.GetZone() as ZonePlay;
		if (zonePlay != null)
		{
			Actor actor = m_card.GetActor();
			MeshRenderer meshRenderer = null;
			if (actor != null)
			{
				meshRenderer = actor.GetMeshRenderer();
				if (meshRenderer == null)
				{
					return false;
				}
			}
			if ((bool)UniversalInputManager.UsePhoneUI)
			{
				GameEntity gameEntity = GameState.Get().GetGameEntity();
				if (gameEntity != null && gameEntity.GetGameOptions().GetBooleanOption(GameEntityOption.CAN_ADJUST_BIG_CARD_HORIZONTALLY))
				{
					return meshRenderer.bounds.center.x > zonePlay.GetComponent<BoxCollider>().bounds.center.x + 0.5f;
				}
				return meshRenderer.bounds.center.x > zonePlay.GetComponent<BoxCollider>().bounds.center.x;
			}
			return meshRenderer.bounds.center.x < zonePlay.GetComponent<BoxCollider>().bounds.center.x + 0.03f;
		}
		return false;
	}

	private void FitInsideScreenVerticalAxis()
	{
		FitInsideScreenBottom();
		FitInsideScreenTop();
	}

	private Bounds CalculateBoundsOfSeveralMeshes(Actor actor)
	{
		if (actor == null)
		{
			return new Bounds(Vector3.zero, Vector3.zero);
		}
		Bounds bounds = actor.GetMeshRenderer().bounds;
		if (actor.m_meshesThatAffectBoundsCalculations != null)
		{
			foreach (MeshRenderer meshesThatAffectBoundsCalculation in actor.m_meshesThatAffectBoundsCalculations)
			{
				if (meshesThatAffectBoundsCalculation == null)
				{
					Debug.LogWarning("Actor \"" + actor.gameObject.name + "\" has a null entry in the m_meshesThatAffectBoundsCalculations array.");
				}
				else
				{
					bounds.Encapsulate(meshesThatAffectBoundsCalculation.bounds);
				}
			}
			return bounds;
		}
		return bounds;
	}

	private Bounds CalculateLowerMeshBounds(Actor actor = null)
	{
		if (actor == null)
		{
			actor = m_bigCardActor;
		}
		if (m_enchantmentBanner.IsBannerVisible())
		{
			return m_enchantmentBanner.GetLowerMeshBounds();
		}
		if (actor.m_meshesThatAffectBoundsCalculations != null && actor.m_meshesThatAffectBoundsCalculations.Count > 0)
		{
			return CalculateBoundsOfSeveralMeshes(actor);
		}
		return actor.GetMeshRenderer().bounds;
	}

	private bool FitInsideScreenBottom()
	{
		Bounds bounds = CalculateLowerMeshBounds();
		Vector3 center = bounds.center;
		if ((bool)UniversalInputManager.UsePhoneUI)
		{
			center.z -= 0.4f;
		}
		Vector3 vector = new Vector3(center.x, center.y, center.z - bounds.extents.z);
		Ray ray = new Ray(vector, vector - center);
		Plane plane = CameraUtils.CreateBottomPlane(CameraUtils.FindFirstByLayer(GameLayer.Tooltip));
		float enter = 0f;
		if (plane.Raycast(ray, out enter))
		{
			return false;
		}
		if (Mathf.Approximately(enter, 0f))
		{
			return false;
		}
		TransformUtil.SetPosZ(m_bigCardActor.gameObject, m_bigCardActor.transform.position.z - enter);
		return true;
	}

	private Bounds CalculateMeshBoundsIncludingGem(Actor actor = null)
	{
		if (actor == null)
		{
			actor = m_bigCardActor;
		}
		if (actor.m_meshesThatAffectBoundsCalculations != null && actor.m_meshesThatAffectBoundsCalculations.Count > 0)
		{
			return CalculateBoundsOfSeveralMeshes(actor);
		}
		Bounds bounds = actor.GetMeshRenderer().bounds;
		if (actor != null && actor.GetEntity() != null && (actor.GetEntity().IsSideQuest() || actor.GetEntity().IsSigil() || actor.GetEntity().IsObjective()))
		{
			MeshRenderer[] componentsInChildren = actor.GetRootObject().GetComponentsInChildren<MeshRenderer>();
			foreach (MeshRenderer meshRenderer in componentsInChildren)
			{
				if (meshRenderer.gameObject.name.Equals("gem_mana", StringComparison.InvariantCultureIgnoreCase))
				{
					Bounds bounds2 = meshRenderer.bounds;
					bounds.Encapsulate(bounds2);
					break;
				}
			}
		}
		return bounds;
	}

	private bool FitInsideScreenTop()
	{
		Bounds bounds = CalculateMeshBoundsIncludingGem();
		Vector3 center = bounds.center;
		if ((bool)UniversalInputManager.UsePhoneUI && !(m_card.GetZone() is ZoneHeroPower))
		{
			center.z += 1f;
		}
		Vector3 vector = new Vector3(center.x, center.y, center.z + bounds.extents.z);
		Ray ray = new Ray(vector, vector - center);
		Plane plane = CameraUtils.CreateTopPlane(CameraUtils.FindFirstByLayer(GameLayer.Tooltip));
		float enter = 0f;
		if (plane.Raycast(ray, out enter))
		{
			return false;
		}
		if (Mathf.Approximately(enter, 0f))
		{
			return false;
		}
		TransformUtil.SetPosZ(m_bigCardActor.gameObject, m_bigCardActor.transform.position.z + enter);
		return true;
	}

	private void FitInsideScreenHorizontalAxis()
	{
		FitInsideScreenLeft();
		FitInsideScreenRight();
	}

	private bool FitInsideScreenLeft()
	{
		Bounds bounds = ComputeBoundsOfBigCardExtraCardAndTooltips();
		Vector3 center = bounds.center;
		Vector3 vector = new Vector3(center.x - bounds.extents.x, center.y, center.z);
		Ray ray = new Ray(vector, vector - center);
		if (CameraUtils.CreateLeftPlane(CameraUtils.FindFirstByLayer(GameLayer.Tooltip)).Raycast(ray, out var enter))
		{
			return false;
		}
		if (Mathf.Approximately(enter, 0f))
		{
			return false;
		}
		TransformUtil.SetPosX(m_bigCardActor.gameObject, m_bigCardActor.transform.position.x + enter);
		return true;
	}

	private bool FitInsideScreenRight()
	{
		Bounds bounds = ComputeBoundsOfBigCardExtraCardAndTooltips();
		Vector3 center = bounds.center;
		Vector3 vector = new Vector3(center.x + bounds.extents.x, center.y, center.z);
		Ray ray = new Ray(vector, vector - center);
		if (CameraUtils.CreateRightPlane(CameraUtils.FindFirstByLayer(GameLayer.Tooltip)).Raycast(ray, out var enter))
		{
			return false;
		}
		if (Mathf.Approximately(enter, 0f))
		{
			return false;
		}
		TransformUtil.SetPosX(m_bigCardActor.gameObject, m_bigCardActor.transform.position.x + enter);
		return true;
	}

	private Bounds ComputeBoundsOfBigCardExtraCardAndTooltips()
	{
		Bounds bounds = m_bigCardActor.GetMeshRenderer().bounds;
		List<TooltipPanel> currentTooltipPanels = TooltipPanelManager.Get().GetCurrentTooltipPanels();
		if (currentTooltipPanels != null)
		{
			foreach (TooltipPanel item in currentTooltipPanels)
			{
				MeshRenderer[] componentsInChildren = item.gameObject.GetComponentsInChildren<MeshRenderer>();
				if (componentsInChildren != null)
				{
					MeshRenderer[] array = componentsInChildren;
					foreach (MeshRenderer meshRenderer in array)
					{
						bounds.Encapsulate(meshRenderer.bounds);
					}
				}
			}
		}
		if (m_extraBigCardActor != null)
		{
			MeshRenderer[] componentsInChildren2 = m_extraBigCardActor.GetComponentsInChildren<MeshRenderer>();
			if (componentsInChildren2 != null)
			{
				MeshRenderer[] array = componentsInChildren2;
				foreach (MeshRenderer meshRenderer2 in array)
				{
					bounds.Encapsulate(meshRenderer2.bounds);
				}
			}
		}
		return bounds;
	}

	public void ActivateBigCardStateSpells(Entity entity, Actor cardActor, Actor bigCardActor, EntityDef bigCardEntityDef = null)
	{
		if (cardActor == null)
		{
			return;
		}
		int num = 0;
		if (bigCardEntityDef != null)
		{
			if (bigCardEntityDef.UseTechLevelManaGem())
			{
				num = bigCardEntityDef.GetTechLevel();
			}
		}
		else if (cardActor.UseTechLevelManaGem())
		{
			num = entity.GetTechLevel();
		}
		if (num != 0)
		{
			bigCardActor.m_manaObject.SetActive(value: false);
			Spell spell = bigCardActor.GetSpell(SpellType.TECH_LEVEL_MANA_GEM);
			if (spell != null)
			{
				spell.GetComponent<PlayMakerFSM>().FsmVariables.GetFsmInt("TechLevel").Value = num;
				spell.ActivateState(SpellStateType.BIRTH);
			}
		}
		if (cardActor.UseCoinManaGem())
		{
			bigCardActor.ActivateSpellBirthState(SpellType.COIN_MANA_GEM);
		}
	}

	private void LoadAndDisplayTooltipPhoneSigils()
	{
		if (m_phoneSigilActors == null)
		{
			m_phoneSigilActors = new List<Actor>();
		}
		else
		{
			foreach (Actor phoneSigilActor in m_phoneSigilActors)
			{
				phoneSigilActor.Destroy();
			}
			m_phoneSigilActors.Clear();
		}
		ZoneSecret zoneSecret = m_card.GetZone() as ZoneSecret;
		if (zoneSecret == null)
		{
			Log.Gameplay.PrintError("BigCard.LoadAndDisplayTooltipPhoneSigils() called for a card that is not in a Secret Zone.");
			return;
		}
		List<Card> sigilCards = zoneSecret.GetSigilCards();
		for (int i = 0; i < sigilCards.Count; i++)
		{
			Actor item = LoadPhoneSecret(sigilCards[i]);
			m_phoneSigilActors.Add(item);
		}
		DisplayPhoneSecrets(m_card, m_phoneSigilActors, showDeath: false);
	}

	private void HideTooltipPhoneSigils()
	{
		if (m_phoneSigilActors == null)
		{
			return;
		}
		foreach (Actor phoneSigilActor in m_phoneSigilActors)
		{
			HidePhoneSecret(phoneSigilActor);
		}
		m_phoneSigilActors.Clear();
	}

	private void LoadAndDisplayTooltipPhoneObjectives()
	{
		if (m_phoneObjectivesActors == null)
		{
			m_phoneObjectivesActors = new List<Actor>();
		}
		else
		{
			foreach (Actor phoneObjectivesActor in m_phoneObjectivesActors)
			{
				phoneObjectivesActor.Destroy();
			}
			m_phoneObjectivesActors.Clear();
		}
		ZoneSecret zoneSecret = m_card.GetZone() as ZoneSecret;
		if (zoneSecret == null)
		{
			Log.Gameplay.PrintError("BigCard.LoadAndDisplayTooltipPhoneObjectives() called for a card that is not in a Secret Zone.");
			return;
		}
		List<Card> objectiveCards = zoneSecret.GetObjectiveCards();
		for (int i = 0; i < objectiveCards.Count; i++)
		{
			Actor item = LoadPhoneSecret(objectiveCards[i]);
			m_phoneObjectivesActors.Add(item);
		}
		DisplayPhoneSecrets(m_card, m_phoneObjectivesActors, showDeath: false);
	}

	private void HideTooltipPhoneObjectives()
	{
		if (m_phoneObjectivesActors == null)
		{
			return;
		}
		foreach (Actor phoneObjectivesActor in m_phoneObjectivesActors)
		{
			HidePhoneSecret(phoneObjectivesActor);
		}
		m_phoneObjectivesActors.Clear();
	}

	private void LoadAndDisplayTooltipPhoneSecrets()
	{
		if (m_phoneSecretActors == null)
		{
			m_phoneSecretActors = new List<Actor>();
		}
		else
		{
			foreach (Actor phoneSecretActor in m_phoneSecretActors)
			{
				phoneSecretActor.Destroy();
			}
			m_phoneSecretActors.Clear();
		}
		ZoneSecret zoneSecret = m_card.GetZone() as ZoneSecret;
		if (zoneSecret == null)
		{
			Log.Gameplay.PrintError("BigCard.LoadAndDisplayTooltipPhoneSecrets() called for a card that is not in a Secret Zone.");
			return;
		}
		List<Card> secretCards = zoneSecret.GetSecretCards();
		for (int i = 0; i < secretCards.Count; i++)
		{
			Actor item = LoadPhoneSecret(secretCards[i]);
			m_phoneSecretActors.Add(item);
		}
		DisplayPhoneSecrets(m_card, m_phoneSecretActors, showDeath: false);
	}

	private void HideTooltipPhoneSecrets()
	{
		if (m_phoneSecretActors == null)
		{
			return;
		}
		foreach (Actor phoneSecretActor in m_phoneSecretActors)
		{
			HidePhoneSecret(phoneSecretActor);
		}
		m_phoneSecretActors.Clear();
	}

	private void LoadAndDisplayTooltipPhoneSideQuests()
	{
		if (m_phoneSideQuestActors == null)
		{
			m_phoneSideQuestActors = new List<Actor>();
		}
		else
		{
			foreach (Actor phoneSideQuestActor in m_phoneSideQuestActors)
			{
				phoneSideQuestActor.Destroy();
			}
			m_phoneSideQuestActors.Clear();
		}
		ZoneSecret zoneSecret = m_card.GetZone() as ZoneSecret;
		if (zoneSecret == null)
		{
			Log.Gameplay.PrintError("BigCard.LoadAndDisplayTooltipPhoneSideQuests() called for a card that is not in a Secret Zone.");
			return;
		}
		List<Card> sideQuestCards = zoneSecret.GetSideQuestCards();
		for (int i = 0; i < sideQuestCards.Count; i++)
		{
			Actor item = LoadPhoneSecret(sideQuestCards[i]);
			m_phoneSideQuestActors.Add(item);
		}
		DisplayPhoneSecrets(m_card, m_phoneSideQuestActors, showDeath: false);
	}

	private void HideTooltipPhoneSideQuests()
	{
		if (m_phoneSideQuestActors == null)
		{
			return;
		}
		foreach (Actor phoneSideQuestActor in m_phoneSideQuestActors)
		{
			HidePhoneSecret(phoneSideQuestActor);
		}
		m_phoneSideQuestActors.Clear();
	}

	private Actor LoadPhoneSecret(Card card)
	{
		string bigCardActor = ActorNames.GetBigCardActor(card.GetEntity());
		Actor component = AssetLoader.Get().InstantiatePrefab(bigCardActor, AssetLoadingOptions.IgnorePrefabPosition).GetComponent<Actor>();
		SetupActor(card, component);
		return component;
	}

	private Vector3 PhoneMoveSideQuestBigCardToTopOfScreen(Actor actor, Vector3 initialPosition)
	{
		if (actor == null || !UniversalInputManager.UsePhoneUI)
		{
			return initialPosition;
		}
		Vector3 position = actor.transform.position;
		try
		{
			actor.transform.position = initialPosition;
			Bounds bounds = CalculateMeshBoundsIncludingGem(actor);
			Vector3 center = bounds.center;
			Vector3 vector = new Vector3(center.x, center.y, center.z + bounds.extents.z);
			Ray ray = new Ray(vector, vector - center);
			Plane plane = CameraUtils.CreateTopPlane(CameraUtils.FindFirstByLayer(GameLayer.Tooltip));
			float enter = 0f;
			plane.Raycast(ray, out enter);
			return initialPosition + new Vector3(0f, 0f, enter);
		}
		finally
		{
			actor.transform.position = position;
		}
	}

	private void DisplayPhoneSecrets(Card mainCard, List<Actor> actors, bool showDeath)
	{
		DetermineSecretLayoutOffsets(mainCard, actors, out var initialOffset, out var spacing, out var drift);
		bool flag = GeneralUtils.IsOdd(actors.Count);
		Player controller = mainCard.GetController();
		ZoneSecret secretZone = controller.GetSecretZone();
		Actor actor = mainCard.GetActor();
		Vector3 vector = secretZone.transform.position + initialOffset;
		for (int i = 0; i < actors.Count; i++)
		{
			Actor actor2 = actors[i];
			Vector3 vector2;
			if (i == 0 && flag)
			{
				vector2 = ((actors.Count != 1 || !actor2.GetCard().GetEntity().IsSideQuest() || !controller.IsFriendlySide()) ? vector : PhoneMoveSideQuestBigCardToTopOfScreen(actor2, vector));
			}
			else
			{
				bool flag2 = GeneralUtils.IsOdd(i);
				bool flag3 = flag == flag2;
				float num = (flag ? Mathf.Ceil(0.5f * (float)i) : Mathf.Floor(0.5f * (float)i));
				float num2 = num * spacing.x;
				if (!flag)
				{
					num2 += 0.5f * spacing.x;
				}
				if (flag3)
				{
					num2 = 0f - num2;
				}
				float num3 = num * spacing.z;
				vector2 = new Vector3(vector.x + num2, vector.y, vector.z + num3);
			}
			actor2.transform.position = actor.transform.position;
			actor2.transform.rotation = actor.transform.rotation;
			actor2.transform.localScale = INVISIBLE_SCALE;
			float num4 = (showDeath ? m_SecretLayoutData.m_DeathShowAnimTime : m_SecretLayoutData.m_ShowAnimTime);
			Hashtable args = iTween.Hash("position", vector2 - drift, "time", num4, "easeType", iTween.EaseType.easeOutExpo);
			iTween.MoveTo(actor2.gameObject, args);
			Hashtable args2 = iTween.Hash("position", vector2, "delay", num4, "time", m_SecretLayoutData.m_DriftSec, "easeType", iTween.EaseType.easeOutExpo);
			iTween.MoveTo(actor2.gameObject, args2);
			iTween.ScaleTo(actor2.gameObject, base.transform.localScale, num4);
			if (mainCard.GetEntity().IsSideQuest())
			{
				actor2.ShowSideQuestProgressBanner();
			}
			else if (mainCard.GetEntity().IsObjective())
			{
				actor2.ShowObjectiveProgressBanner();
			}
			else
			{
				actor2.HideSideQuestProgressBanner();
			}
			if (showDeath)
			{
				ShowPhoneSecretDeath(actor2);
			}
		}
	}

	private void DetermineSecretLayoutOffsets(Card mainCard, List<Actor> actors, out Vector3 initialOffset, out Vector3 spacing, out Vector3 drift)
	{
		Player controller = mainCard.GetController();
		bool flag = controller.IsFriendlySide();
		bool num = controller.IsRevealed();
		int minCardThreshold = m_SecretLayoutData.m_MinCardThreshold;
		int maxCardThreshold = m_SecretLayoutData.m_MaxCardThreshold;
		SecretLayoutOffsets minCardOffsets = m_SecretLayoutData.m_MinCardOffsets;
		SecretLayoutOffsets maxCardOffsets = m_SecretLayoutData.m_MaxCardOffsets;
		float t = Mathf.InverseLerp(minCardThreshold, maxCardThreshold, actors.Count);
		if (num)
		{
			if (flag)
			{
				initialOffset = Vector3.Lerp(minCardOffsets.m_InitialOffset, maxCardOffsets.m_InitialOffset, t);
			}
			else
			{
				initialOffset = Vector3.Lerp(minCardOffsets.m_OpponentInitialOffset, maxCardOffsets.m_OpponentInitialOffset, t);
			}
			spacing = m_SecretLayoutData.m_Spacing;
		}
		else
		{
			if (flag)
			{
				initialOffset = Vector3.Lerp(minCardOffsets.m_HiddenInitialOffset, maxCardOffsets.m_HiddenInitialOffset, t);
			}
			else
			{
				initialOffset = Vector3.Lerp(minCardOffsets.m_HiddenOpponentInitialOffset, maxCardOffsets.m_HiddenOpponentInitialOffset, t);
			}
			spacing = m_SecretLayoutData.m_HiddenSpacing;
		}
		if (flag)
		{
			spacing.z = 0f - spacing.z;
			drift = m_SecretLayoutData.m_DriftOffset;
		}
		else
		{
			drift = -m_SecretLayoutData.m_DriftOffset;
		}
	}

	private void ShowPhoneSecretDeath(Actor actor)
	{
		Spell.StateFinishedCallback deathSpellStateFinished = delegate(Spell spell, SpellStateType prevStateType, object userData)
		{
			if (spell.GetActiveState() != 0)
			{
				actor.Destroy();
			}
		};
		Action<object> action = delegate
		{
			Spell spell2 = actor.GetSpell(SpellType.DEATH);
			spell2.AddStateFinishedCallback(deathSpellStateFinished);
			spell2.Activate();
		};
		Hashtable args = iTween.Hash("time", m_SecretLayoutData.m_TimeUntilDeathSpell, "oncomplete", action);
		iTween.Timer(actor.gameObject, args);
	}

	private void HidePhoneSecret(Actor actor)
	{
		if (!(actor == null) && !(m_card == null))
		{
			Actor actor2 = m_card.GetActor();
			if (actor2 != null)
			{
				iTween.MoveTo(actor.gameObject, actor2.transform.position, m_SecretLayoutData.m_HideAnimTime);
			}
			iTween.ScaleTo(actor.gameObject, INVISIBLE_SCALE, m_SecretLayoutData.m_HideAnimTime);
			Action<object> action = delegate
			{
				actor.Destroy();
			};
			Hashtable args = iTween.Hash("time", m_SecretLayoutData.m_HideAnimTime, "oncomplete", action);
			iTween.Timer(actor.gameObject, args);
		}
	}

	private void SetupActor(Card card, Actor actor)
	{
		bool ignoreHideStats = false;
		Entity entity = card.GetEntity();
		if (ShouldActorUseEntity(entity))
		{
			actor.SetEntity(entity);
			ignoreHideStats = entity.HasTag(GAME_TAG.IGNORE_HIDE_STATS_FOR_BIG_CARD) || (entity.IsDormant() && !entity.HasTag(GAME_TAG.HIDE_STATS));
		}
		GhostCard.Type ghostType = (GhostCard.Type)entity.GetTag(GAME_TAG.MOUSE_OVER_CARD_APPEARANCE);
		if (card.GetEntity().IsDormant())
		{
			ghostType = GhostCard.Type.DORMANT;
		}
		actor.GhostCardEffect(ghostType, entity.GetPremiumType(), update: false);
		EntityDef entityDef = entity.GetEntityDef();
		DefLoader.DisposableCardDef disposableCardDef = card.ShareDisposableCardDef();
		int heroBuddyCardId = entity.GetTag(GAME_TAG.ALTERNATE_MOUSE_OVER_CARD);
		bool flag = entity.GetCardType() == TAG_CARDTYPE.BATTLEGROUND_HERO_BUDDY;
		if (flag)
		{
			Entity entity2 = entity?.GetController()?.GetHero();
			if (entity2 != null)
			{
				heroBuddyCardId = entity2.GetHeroBuddyCardId();
				actor.SetEntity(null);
			}
		}
		EntityDef entityDef2 = null;
		if (heroBuddyCardId != 0)
		{
			entityDef2 = DefLoader.Get().GetEntityDef(heroBuddyCardId);
			if (entityDef2 == null)
			{
				Log.Gameplay.PrintError("BigCard.SetupActor(): Unable to load EntityDef for card ID {0}.", heroBuddyCardId);
			}
			else
			{
				entityDef = entityDef2;
			}
			DefLoader.DisposableCardDef cardDef = DefLoader.Get().GetCardDef(heroBuddyCardId);
			if (cardDef == null)
			{
				Log.Spells.PrintError("BigCard.SetupActor(): Unable to load CardDef for card ID {0}.", heroBuddyCardId);
			}
			else
			{
				disposableCardDef?.Dispose();
				disposableCardDef = cardDef;
			}
		}
		using (disposableCardDef)
		{
			if (ShouldActorUseEntityDef(entity))
			{
				actor.SetEntityDef(entityDef);
				ignoreHideStats = entityDef.HasTag(GAME_TAG.IGNORE_HIDE_STATS_FOR_BIG_CARD) || entityDef.IsDormant();
			}
			actor.SetPremium(entity.GetPremiumType());
			actor.SetCard(card);
			actor.SetCardDef(disposableCardDef);
			actor.SetIgnoreHideStats(ignoreHideStats);
			actor.SetWatermarkCardSetOverride(entity.GetWatermarkCardSetOverride());
			actor.UpdateAllComponents();
			ActivateBigCardStateSpells(entity, card.GetActor(), actor, flag ? entityDef2 : null);
			if (flag)
			{
				GameObject gameObject = GameObjectUtils.FindChildBySubstring(m_bigCardActor.gameObject, "GhostCard");
				GameObject gameObject2 = GameObjectUtils.FindChildBySubstring(m_bigCardActor.gameObject, "RootObject");
				if (gameObject != null && gameObject2 != null)
				{
					GhostCard component = gameObject.GetComponent<GhostCard>();
					component.enabled = true;
					component.SetGhostType(GhostCard.Type.DORMANT);
					component.RenderGhostCard(forceRender: true);
					actor.GhostCardEffect(GhostCard.Type.DORMANT);
				}
				GameObject gameObject3 = GameObjectUtils.FindChildBySubstring(actor.gameObject, "GhostedCard_Bottom");
				if (gameObject3 != null)
				{
					bool active = entity.GetTag(GAME_TAG.TAG_SCRIPT_DATA_ENT_2) != 0;
					gameObject3.SetActive(active);
				}
				else
				{
					Debug.LogWarning("BigCard.SetupActor - Bottom ghost card is missing");
				}
				HeroBuddyWidget heroBuddyWidget = card.GetActor()?.GetComponent<HeroBuddyWidget>();
				if (heroBuddyWidget != null)
				{
					heroBuddyWidget.ShowProgressText(value: true);
				}
			}
			BoxCollider componentInChildren = actor.GetComponentInChildren<BoxCollider>();
			if (componentInChildren != null)
			{
				componentInChildren.enabled = false;
			}
			actor.name = "BigCard_" + actor.name;
			LayerUtils.SetLayer(actor, GameLayer.Tooltip);
		}
	}

	private bool ShouldActorUseEntity(Entity entity)
	{
		if (entity.IsHidden())
		{
			return true;
		}
		if ((entity.GetZone() == TAG_ZONE.PLAY || entity.GetZone() == TAG_ZONE.SECRET) && entity.GetCardTextBuilder().ShouldUseEntityForTextInPlay())
		{
			return true;
		}
		if (entity.GetZone() == TAG_ZONE.HAND && entity.GetCardTextBuilder().ShouldUseEntityForTextInHand())
		{
			return true;
		}
		if (entity.IsDormant())
		{
			return true;
		}
		if (entity.IsSideQuest() || entity.IsSigil() || entity.IsSecret() || entity.IsObjective())
		{
			return true;
		}
		if (entity.IsCardButton())
		{
			return true;
		}
		if (GameMgr.Get().IsSpectator() && entity.GetZone() == TAG_ZONE.HAND && entity.GetController().IsOpposingSide())
		{
			return true;
		}
		return false;
	}

	private bool ShouldActorUseEntityDef(Entity entity)
	{
		if (entity.IsHidden())
		{
			return false;
		}
		if (entity.IsCardButton())
		{
			return false;
		}
		if (entity.IsDormant())
		{
			return false;
		}
		if (entity.GetZone() == TAG_ZONE.SECRET)
		{
			return false;
		}
		if (GameMgr.Get().IsSpectator() && entity.GetZone() == TAG_ZONE.HAND && entity.GetController().IsOpposingSide())
		{
			return false;
		}
		return true;
	}
}
