using System.Collections.Generic;
using UnityEngine;

public class BoardDbfAsset : ScriptableObject
{
	public List<BoardDbfRecord> Records = new List<BoardDbfRecord>();
}
