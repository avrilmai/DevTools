using System;

[Serializable]
[CustomEditClass]
public class BaconCosmeticPreviewAction
{
	[CustomEditField(SortPopupByName = true)]
	public BaconCosmeticPreviewActionType actionType;

	public float delay;

	public float duration;

	public bool waitUntilFinished;

	[CustomEditField(HidePredicate = "ShouldHideBoardState")]
	public TAG_BOARD_VISUAL_STATE boardState;

	[CustomEditField(HidePredicate = "ShouldHideFsmParameter")]
	public string fsmParameter;

	[CustomEditField(SortPopupByName = true, HidePredicate = "ShouldHideFinisherParams")]
	public KeyboardFinisherSettings.DamageLevel strikeDamageLevel;

	[CustomEditField(SortPopupByName = true, HidePredicate = "ShouldHideFinisherParams")]
	public KeyboardFinisherSettings.LethalLevel strikeLethalLevel;

	[CustomEditField(HidePredicate = "ShouldHideFinisherParams")]
	public int strikeImpactDamage;

	public string displayText;
}
