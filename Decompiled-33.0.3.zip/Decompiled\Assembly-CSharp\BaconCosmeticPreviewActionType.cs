public enum BaconCosmeticPreviewActionType
{
	SWAP_BOARD_STATE,
	TRIGGER_FSM_EVENT,
	LAUNCH_STRIKE
}
