using System;

[Serializable]
public class AllyAttackDef
{
	public float m_MoveToTargetDuration = 0.12f;

	public iTween.EaseType m_MoveToTargetEaseType = iTween.EaseType.linear;
}
