using Blizzard.GameService.SDK.Client.Integration;

public class BnetInvitation
{
	private BnetInvitationId m_id;

	private BnetEntityId m_inviterId;

	private string m_inviterName;

	private BnetEntityId m_inviteeId;

	private string m_inviteeName;

	private string m_message;

	private ulong m_creationTimeMicrosec;

	private ulong m_expirationTimeMicrosec;

	public static BnetInvitation CreateFromFriendsUpdate(FriendsUpdate src)
	{
		BnetInvitation bnetInvitation = new BnetInvitation();
		bnetInvitation.m_id = new BnetInvitationId(src.long1);
		if (src.entity1 != null)
		{
			bnetInvitation.m_inviterId = src.entity1.Clone();
		}
		if (src.entity2 != null)
		{
			bnetInvitation.m_inviteeId = src.entity2.Clone();
		}
		bnetInvitation.m_inviterName = src.string1;
		bnetInvitation.m_inviteeName = src.string2;
		bnetInvitation.m_message = src.string3;
		bnetInvitation.m_creationTimeMicrosec = src.long2;
		bnetInvitation.m_expirationTimeMicrosec = src.long3;
		return bnetInvitation;
	}

	public BnetInvitationId GetId()
	{
		return m_id;
	}

	public BnetEntityId GetInviterId()
	{
		return m_inviterId;
	}

	public string GetInviterName()
	{
		return m_inviterName;
	}

	public ulong GetCreationTimeMicrosec()
	{
		return m_creationTimeMicrosec;
	}

	public override bool Equals(object obj)
	{
		if (obj == null)
		{
			return false;
		}
		BnetInvitation bnetInvitation = obj as BnetInvitation;
		if ((object)bnetInvitation == null)
		{
			return false;
		}
		return m_id.Equals(bnetInvitation.m_id);
	}

	public override int GetHashCode()
	{
		return m_id.GetHashCode();
	}

	public static bool operator ==(BnetInvitation a, BnetInvitation b)
	{
		if ((object)a == b)
		{
			return true;
		}
		if ((object)a == null || (object)b == null)
		{
			return false;
		}
		return a.m_id == b.m_id;
	}

	public override string ToString()
	{
		if (m_id == null)
		{
			return "UNKNOWN INVITATION";
		}
		return $"[id={m_id} inviterId={m_inviterId} inviterName={m_inviterName} inviteeId={m_inviteeId} inviteeName={m_inviteeName} message={m_message}]";
	}
}
