using System.Collections.Generic;
using UnityEngine;

public class AccountLicenseDbfAsset : ScriptableObject
{
	public List<AccountLicenseDbfRecord> Records = new List<AccountLicenseDbfRecord>();
}
