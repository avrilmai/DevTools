using System.Collections.Generic;
using UnityEngine;

public class Banner : MonoBehaviour
{
	public UberText m_headline;

	public UberText m_caption;

	public GameObject m_bannerDefault;

	public UberText m_headlineDefault;

	public UberText m_captionDefault;

	public GameObject m_glowObject;

	public GameObject m_bannerMurlocHolmes;

	public UberText m_headlineMurlocHolmes;

	public UberText m_captionMurlocHolmes;

	public GameObject m_bannerSuspicious;

	public UberText m_headlineSuspicious;

	public UberText m_captionSuspicious;

	private const string MURLOC_HOLMES = "REV_022";

	private const string SUSPICOUS_CARD = "REV_000e";

	private const string MURLOC_HOMES_BACON_HEROPOWER = "BG23_HERO_303p2";

	public void SetText(string headline)
	{
		m_headline.Text = headline;
		m_caption.gameObject.SetActive(value: false);
	}

	public void SetText(string headline, string caption)
	{
		m_headline.Text = headline;
		m_caption.gameObject.SetActive(value: true);
		m_caption.Text = caption;
	}

	public void MoveGlowForBottomPlacement()
	{
		m_glowObject.transform.localPosition = new Vector3(m_glowObject.transform.localPosition.x, m_glowObject.transform.localPosition.y, 0f);
	}

	public void SetupBanner(Network.EntityChoices choices, List<Card> cards)
	{
		Entity entity = GameState.Get().GetEntity(choices.Source);
		switch (entity.GetCardId())
		{
		case "REV_022":
		{
			m_bannerDefault.SetActive(value: false);
			m_bannerMurlocHolmes.SetActive(value: true);
			m_headline = m_headlineMurlocHolmes;
			m_caption = m_captionMurlocHolmes;
			string headline2 = "";
			int num = entity.GetTag(GAME_TAG.TAG_SCRIPT_DATA_NUM_1);
			switch (num)
			{
			case 1:
				headline2 = GameStrings.Get("GAMEPLAY_MURLOC_HOLMES_QUESTION_1");
				break;
			case 2:
				headline2 = GameStrings.Get("GAMEPLAY_MURLOC_HOLMES_QUESTION_2");
				break;
			case 3:
				headline2 = GameStrings.Get("GAMEPLAY_MURLOC_HOLMES_QUESTION_3");
				break;
			}
			string caption2 = string.Format("{0} {1}/3", GameStrings.Get("GAMEPLAY_MURLOC_HOLMES_CLUE"), num.ToString());
			SetText(headline2, caption2);
			return;
		}
		case "REV_000e":
		{
			m_bannerDefault.SetActive(value: false);
			m_bannerSuspicious.SetActive(value: true);
			m_headline = m_headlineSuspicious;
			m_caption = m_captionSuspicious;
			string headline = GameStrings.Get("GAMEPLAY_SUSPICIOUS_GUESS_HEADLINE");
			string caption = "";
			SetText(headline, caption);
			return;
		}
		case "BG23_HERO_303p2":
		{
			m_bannerDefault.SetActive(value: false);
			m_bannerMurlocHolmes.SetActive(value: true);
			m_headline = m_headlineMurlocHolmes;
			m_caption = m_captionMurlocHolmes;
			string headline3 = GameStrings.Get("GAMEPLAY_MURLOC_HOLMES_WARBAND_QUESTION");
			string caption3 = GameStrings.Get("GAMEPLAY_MURLOC_HOLMES_CLUE");
			SetText(headline3, caption3);
			return;
		}
		}
		m_bannerDefault.SetActive(value: true);
		m_bannerMurlocHolmes.SetActive(value: false);
		m_headline = m_headlineDefault;
		m_caption = m_captionDefault;
		string text = GameState.Get().GetGameEntity().CustomChoiceBannerText();
		if (text == null)
		{
			if (choices.IsSingleChoice())
			{
				if (entity != null)
				{
					string cardDiscoverString = GameDbf.GetIndex().GetCardDiscoverString(entity.GetCardId());
					if (cardDiscoverString != null)
					{
						text = GameStrings.Get(cardDiscoverString);
					}
				}
				if (text == null)
				{
					text = GameStrings.Get("GAMEPLAY_CHOOSE_ONE");
					foreach (Card card in cards)
					{
						if (null != card && card.GetEntity().IsHeroPower())
						{
							text = GameStrings.Get("GAMEPLAY_CHOOSE_ONE_HERO_POWER");
							break;
						}
					}
				}
			}
			else
			{
				text = $"[PH] Choose {choices.CountMin} to {choices.CountMax}";
			}
		}
		SetText(text);
	}
}
