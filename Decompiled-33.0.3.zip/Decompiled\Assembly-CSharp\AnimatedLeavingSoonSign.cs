public class AnimatedLeavingSoonSign : AnimatedLowPolyPack
{
	public UIBButton m_leavingSoonButton;
}
