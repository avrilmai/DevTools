using System;
using System.Collections.Generic;
using Blizzard.T5.Jobs;
using UnityEngine;

[Serializable]
public class AchievementCategoryDbfRecord : DbfRecord
{
	[SerializeField]
	private DbfLocValue m_name;

	[SerializeField]
	private string m_icon;

	[SerializeField]
	private int m_sortOrder;

	[DbfField("NAME")]
	public DbfLocValue Name => m_name;

	[DbfField("ICON")]
	public string Icon => m_icon;

	[DbfField("SORT_ORDER")]
	public int SortOrder => m_sortOrder;

	public List<AchievementSubcategoryDbfRecord> Subcategories
	{
		get
		{
			int iD = base.ID;
			List<AchievementSubcategoryDbfRecord> list = new List<AchievementSubcategoryDbfRecord>();
			List<AchievementSubcategoryDbfRecord> records = GameDbf.AchievementSubcategory.GetRecords();
			int i = 0;
			for (int count = records.Count; i < count; i++)
			{
				AchievementSubcategoryDbfRecord achievementSubcategoryDbfRecord = records[i];
				if (achievementSubcategoryDbfRecord.AchievementCategoryId == iD)
				{
					list.Add(achievementSubcategoryDbfRecord);
				}
			}
			return list;
		}
	}

	public override object GetVar(string name)
	{
		switch (name)
		{
		case "ID":
			return base.ID;
		case "NAME":
			return m_name;
		case "ICON":
			return m_icon;
		case "SORT_ORDER":
			return m_sortOrder;
		default:
			return null;
		}
	}

	public override void SetVar(string name, object val)
	{
		switch (name)
		{
		case "ID":
			SetID((int)val);
			break;
		case "NAME":
			m_name = (DbfLocValue)val;
			break;
		case "ICON":
			m_icon = (string)val;
			break;
		case "SORT_ORDER":
			m_sortOrder = (int)val;
			break;
		}
	}

	public override Type GetVarType(string name)
	{
		switch (name)
		{
		case "ID":
			return typeof(int);
		case "NAME":
			return typeof(DbfLocValue);
		case "ICON":
			return typeof(string);
		case "SORT_ORDER":
			return typeof(int);
		default:
			return null;
		}
	}

	public override IEnumerator<IAsyncJobResult> Job_LoadRecordsFromAssetAsync<T>(string resourcePath, Action<List<T>> resultHandler)
	{
		LoadAchievementCategoryDbfRecords loadRecords = new LoadAchievementCategoryDbfRecords(resourcePath);
		yield return loadRecords;
		resultHandler?.Invoke(loadRecords.GetRecords() as List<T>);
	}

	public override bool LoadRecordsFromAsset<T>(string resourcePath, out List<T> records)
	{
		AchievementCategoryDbfAsset achievementCategoryDbfAsset = DbfShared.GetAssetBundle().LoadAsset(resourcePath, typeof(AchievementCategoryDbfAsset)) as AchievementCategoryDbfAsset;
		if (achievementCategoryDbfAsset == null)
		{
			records = new List<T>();
			Debug.LogError($"AchievementCategoryDbfAsset.LoadRecordsFromAsset() - failed to load records from assetbundle: {resourcePath}");
			return false;
		}
		for (int i = 0; i < achievementCategoryDbfAsset.Records.Count; i++)
		{
			achievementCategoryDbfAsset.Records[i].StripUnusedLocales();
		}
		records = achievementCategoryDbfAsset.Records as List<T>;
		return true;
	}

	public override bool SaveRecordsToAsset<T>(string assetPath, List<T> records, Locale locale)
	{
		return false;
	}

	public override void StripUnusedLocales()
	{
		m_name.StripUnusedLocales();
	}
}
