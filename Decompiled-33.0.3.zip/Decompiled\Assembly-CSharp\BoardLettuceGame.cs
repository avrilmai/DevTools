public class BoardLettuceGame : BoardLayout
{
}
