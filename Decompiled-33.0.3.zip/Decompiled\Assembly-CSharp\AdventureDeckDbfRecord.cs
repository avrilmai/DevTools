using System;
using System.Collections.Generic;
using Blizzard.T5.Jobs;
using UnityEngine;

[Serializable]
public class AdventureDeckDbfRecord : DbfRecord
{
	[SerializeField]
	private int m_adventureId;

	[SerializeField]
	private int m_classId;

	[SerializeField]
	private int m_deckId;

	[SerializeField]
	private int m_sortOrder;

	[SerializeField]
	private DbfLocValue m_unlockCriteriaText;

	[SerializeField]
	private DbfLocValue m_unlockedDescriptionText;

	[SerializeField]
	private int m_unlockGameSaveSubkeyId;

	[SerializeField]
	private int m_unlockValue;

	[SerializeField]
	private string m_displayTexture;

	[DbfField("ADVENTURE_ID")]
	public int AdventureId => m_adventureId;

	[DbfField("CLASS_ID")]
	public int ClassId => m_classId;

	[DbfField("DECK_ID")]
	public int DeckId => m_deckId;

	[DbfField("SORT_ORDER")]
	public int SortOrder => m_sortOrder;

	[DbfField("UNLOCK_CRITERIA_TEXT")]
	public DbfLocValue UnlockCriteriaText => m_unlockCriteriaText;

	[DbfField("UNLOCKED_DESCRIPTION_TEXT")]
	public DbfLocValue UnlockedDescriptionText => m_unlockedDescriptionText;

	[DbfField("UNLOCK_GAME_SAVE_SUBKEY")]
	public int UnlockGameSaveSubkey => m_unlockGameSaveSubkeyId;

	[DbfField("UNLOCK_VALUE")]
	public int UnlockValue => m_unlockValue;

	[DbfField("DISPLAY_TEXTURE")]
	public string DisplayTexture => m_displayTexture;

	public override object GetVar(string name)
	{
		switch (name)
		{
		case "ID":
			return base.ID;
		case "ADVENTURE_ID":
			return m_adventureId;
		case "CLASS_ID":
			return m_classId;
		case "DECK_ID":
			return m_deckId;
		case "SORT_ORDER":
			return m_sortOrder;
		case "UNLOCK_CRITERIA_TEXT":
			return m_unlockCriteriaText;
		case "UNLOCKED_DESCRIPTION_TEXT":
			return m_unlockedDescriptionText;
		case "UNLOCK_GAME_SAVE_SUBKEY":
			return m_unlockGameSaveSubkeyId;
		case "UNLOCK_VALUE":
			return m_unlockValue;
		case "DISPLAY_TEXTURE":
			return m_displayTexture;
		default:
			return null;
		}
	}

	public override void SetVar(string name, object val)
	{
		switch (name)
		{
		case "ID":
			SetID((int)val);
			break;
		case "ADVENTURE_ID":
			m_adventureId = (int)val;
			break;
		case "CLASS_ID":
			m_classId = (int)val;
			break;
		case "DECK_ID":
			m_deckId = (int)val;
			break;
		case "SORT_ORDER":
			m_sortOrder = (int)val;
			break;
		case "UNLOCK_CRITERIA_TEXT":
			m_unlockCriteriaText = (DbfLocValue)val;
			break;
		case "UNLOCKED_DESCRIPTION_TEXT":
			m_unlockedDescriptionText = (DbfLocValue)val;
			break;
		case "UNLOCK_GAME_SAVE_SUBKEY":
			m_unlockGameSaveSubkeyId = (int)val;
			break;
		case "UNLOCK_VALUE":
			m_unlockValue = (int)val;
			break;
		case "DISPLAY_TEXTURE":
			m_displayTexture = (string)val;
			break;
		}
	}

	public override Type GetVarType(string name)
	{
		switch (name)
		{
		case "ID":
			return typeof(int);
		case "ADVENTURE_ID":
			return typeof(int);
		case "CLASS_ID":
			return typeof(int);
		case "DECK_ID":
			return typeof(int);
		case "SORT_ORDER":
			return typeof(int);
		case "UNLOCK_CRITERIA_TEXT":
			return typeof(DbfLocValue);
		case "UNLOCKED_DESCRIPTION_TEXT":
			return typeof(DbfLocValue);
		case "UNLOCK_GAME_SAVE_SUBKEY":
			return typeof(int);
		case "UNLOCK_VALUE":
			return typeof(int);
		case "DISPLAY_TEXTURE":
			return typeof(string);
		default:
			return null;
		}
	}

	public override IEnumerator<IAsyncJobResult> Job_LoadRecordsFromAssetAsync<T>(string resourcePath, Action<List<T>> resultHandler)
	{
		LoadAdventureDeckDbfRecords loadRecords = new LoadAdventureDeckDbfRecords(resourcePath);
		yield return loadRecords;
		resultHandler?.Invoke(loadRecords.GetRecords() as List<T>);
	}

	public override bool LoadRecordsFromAsset<T>(string resourcePath, out List<T> records)
	{
		AdventureDeckDbfAsset adventureDeckDbfAsset = DbfShared.GetAssetBundle().LoadAsset(resourcePath, typeof(AdventureDeckDbfAsset)) as AdventureDeckDbfAsset;
		if (adventureDeckDbfAsset == null)
		{
			records = new List<T>();
			Debug.LogError($"AdventureDeckDbfAsset.LoadRecordsFromAsset() - failed to load records from assetbundle: {resourcePath}");
			return false;
		}
		for (int i = 0; i < adventureDeckDbfAsset.Records.Count; i++)
		{
			adventureDeckDbfAsset.Records[i].StripUnusedLocales();
		}
		records = adventureDeckDbfAsset.Records as List<T>;
		return true;
	}

	public override bool SaveRecordsToAsset<T>(string assetPath, List<T> records, Locale locale)
	{
		return false;
	}

	public override void StripUnusedLocales()
	{
		m_unlockCriteriaText.StripUnusedLocales();
		m_unlockedDescriptionText.StripUnusedLocales();
	}
}
