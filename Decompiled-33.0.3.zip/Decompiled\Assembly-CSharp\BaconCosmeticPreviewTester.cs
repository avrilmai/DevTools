using System.Collections;
using System.Collections.Generic;
using Blizzard.T5.Jobs;
using Blizzard.T5.Services;
using Hearthstone.Core;
using Hearthstone.Util.Services;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BaconCosmeticPreviewTester : MonoBehaviour
{
	private const string PREVIEW_SCENE_NAME = "BaconCosmeticPreview";

	public BaconCosmeticPreviewRunnerConfig m_config;

	[HideInInspector]
	public bool m_dbfLoaded;

	[HideInInspector]
	public bool m_assetResolverServiceLoaded;

	public void Awake()
	{
		m_dbfLoaded = false;
		Processor.QueueJob("CosmeticTester.LoadDBF", LoadDBF()).AddJobFinishedEventListener(OnDBFLoadFinished);
		StartCoroutine(WaitForAssetResolver());
		ServicesBootstrapper.SetupForStandaloneScenes();
		ServiceManager.InitializeDynamicServicesIfNeeded(out var serviceDependencies, DynamicServiceSets.UberText());
		ServiceManager.InitializeDynamicServicesIfNeeded(out serviceDependencies, typeof(IAssetLoader), typeof(IAliasedAssetResolver), typeof(SpellManager));
	}

	private void OnDBFLoadFinished(JobDefinition job, bool success)
	{
		m_dbfLoaded = success;
	}

	public IEnumerator<IAsyncJobResult> LoadDBF()
	{
		yield return GameDbf.CreateLoadDbfJob();
	}

	public IEnumerator WaitForAssetResolver()
	{
		yield return new WaitUntil(() => ServiceManager.AreDependenciesSet());
		m_assetResolverServiceLoaded = true;
	}

	public void LoadScene()
	{
		StartCoroutine(LoadSceneCoroutine());
	}

	public IEnumerator LoadSceneCoroutine()
	{
		if (SceneManager.GetSceneByName("BaconCosmeticPreview").isLoaded)
		{
			AsyncOperation unloadOp = SceneManager.UnloadSceneAsync("BaconCosmeticPreview");
			while (!unloadOp.isDone)
			{
				yield return null;
			}
		}
		AsyncOperation loadOp = SceneManager.LoadSceneAsync("BaconCosmeticPreview", LoadSceneMode.Additive);
		while (!loadOp.isDone)
		{
			yield return null;
		}
	}
}
