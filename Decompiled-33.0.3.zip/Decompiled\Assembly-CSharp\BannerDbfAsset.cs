using System.Collections.Generic;
using UnityEngine;

public class BannerDbfAsset : ScriptableObject
{
	public List<BannerDbfRecord> Records = new List<BannerDbfRecord>();
}
