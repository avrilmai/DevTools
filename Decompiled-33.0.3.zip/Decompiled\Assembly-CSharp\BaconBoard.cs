using System;
using System.Collections;
using System.Collections.Generic;
using Blizzard.T5.AssetManager;
using Blizzard.T5.Core.Utils;
using UnityEngine;

public class BaconBoard : Board
{
	private class BoardSkinStatus
	{
		public GameObject m_CombatPrefab;

		public GameObject m_TavernPrefab;

		public AssetHandle<GameObject> m_AssetHandleCombat;

		public AssetHandle<GameObject> m_AssetHandleTavern;

		public BaconBoardSkinBehaviour m_CombatInstance;

		public BaconBoardSkinBehaviour m_TavernInstance;
	}

	private class BoardSkinStatusAndRound
	{
		public BoardSkinStatus m_Skin;

		public int m_Round;

		public BoardSkinStatusAndRound(BoardSkinStatus skin, int round)
		{
			m_Skin = skin;
			m_Round = round;
		}
	}

	public delegate void StateChangeCallback(TAG_BOARD_VISUAL_STATE newState);

	public float m_ShopAmbientTransitionDelay = 0.5f;

	public float m_ShopAmbientTransitionTime = 0.25f;

	public GameObject m_LeaderboardFrame;

	public GameObject m_TableTop;

	private const int BOARD_SKIN_UNINITIALIZED = 0;

	private const int BOARD_SKIN_DEFAULT = 1;

	private readonly BoardSkinStatus m_FullBoardSkin = new BoardSkinStatus();

	private int m_ChosenBoardSkinId;

	private int m_ChosenCombatBoardSkinId;

	private bool m_InBattle;

	private int m_BattleRound;

	private int m_PendingLoads;

	private bool m_StartedLoadingChosenBoardThisRound;

	private TAG_BOARD_VISUAL_STATE m_currentBoardState;

	private HashSet<string> m_minionsDefeatedByPlayer = new HashSet<string>();

	private HashSet<TAG_RACE> m_racesDefeatedByPlayer = new HashSet<TAG_RACE>();

	private int m_minionsDefeatedCount;

	private static BaconBoard s_Instance;

	private int m_CheatWinstreak;

	private bool m_CheatHasDefeatedOpponent;

	private StateChangeCallback m_stateChangeCallback;

	private DateTime m_LastBoardVisualStateChangeDateTime;

	public void CheatSetWinstreak(int streak)
	{
		m_CheatWinstreak = streak;
	}

	public void CheatSetDefeatedMinionCount(int count)
	{
		m_minionsDefeatedCount = count;
	}

	public void CheatSetHasDefeatedOpponent()
	{
		m_CheatHasDefeatedOpponent = true;
	}

	public void CheatAddDefeatedRace(TAG_RACE race)
	{
		m_racesDefeatedByPlayer.Add(race);
	}

	public void CheatAddDefeatedMinion(string cardID)
	{
		m_minionsDefeatedByPlayer.Add(cardID);
	}

	public bool CheatTriggerDefeatedMinion(string cardID)
	{
		if (m_FullBoardSkin.m_CombatInstance != null)
		{
			m_FullBoardSkin.m_CombatInstance.CheatTriggerDefeatMinion(cardID);
			return true;
		}
		return false;
	}

	public bool CheatTriggerHeroHeavyHitEffects()
	{
		if (m_FullBoardSkin.m_CombatInstance != null)
		{
			m_FullBoardSkin.m_CombatInstance.CheatTriggerHeroHeavyHitBoardEffects();
			return true;
		}
		return false;
	}

	public bool CheatTriggerMinionHeavyHitEffects()
	{
		if (m_FullBoardSkin.m_CombatInstance != null)
		{
			m_FullBoardSkin.m_CombatInstance.CheatTriggerMinionHeavyHitBoardEffects();
			return true;
		}
		return false;
	}

	public bool CheatTriggerAllBoardEffects()
	{
		if (m_FullBoardSkin.m_CombatInstance != null)
		{
			m_FullBoardSkin.m_CombatInstance.CheatTriggerAllBoardEffects();
			return true;
		}
		return false;
	}

	public new static BaconBoard Get()
	{
		return s_Instance;
	}

	public override void Start()
	{
		base.Start();
		s_Instance = this;
		m_LastBoardVisualStateChangeDateTime = DateTime.Now;
		m_currentBoardState = TAG_BOARD_VISUAL_STATE.SHOP;
	}

	protected override void OnDestroy()
	{
		base.OnDestroy();
		s_Instance = null;
		m_InBattle = false;
		UnloadSkinAssets();
	}

	public void AddStateChangeCallback(StateChangeCallback newCallback)
	{
		m_stateChangeCallback = (StateChangeCallback)Delegate.Combine(m_stateChangeCallback, newCallback);
	}

	public void RemoveStateChangeCallback(StateChangeCallback oldCallback)
	{
		m_stateChangeCallback = (StateChangeCallback)Delegate.Remove(m_stateChangeCallback, oldCallback);
	}

	public override bool AreAllAssetsLoaded()
	{
		return m_PendingLoads <= 0;
	}

	public override void ChangeBoardVisualState(TAG_BOARD_VISUAL_STATE boardState)
	{
		SendBoardVisualStatChangeTelmetry(m_currentBoardState, boardState, m_LastBoardVisualStateChangeDateTime);
		m_LastBoardVisualStateChangeDateTime = DateTime.Now;
		m_currentBoardState = boardState;
		if (m_currentBoardState == TAG_BOARD_VISUAL_STATE.COMBAT)
		{
			OnTransitionToBattle();
		}
		if (m_currentBoardState == TAG_BOARD_VISUAL_STATE.SHOP)
		{
			OnTransitionToShop();
		}
	}

	public void LoadInitialTavernBoard(int chosenBoardSkinId)
	{
		m_ChosenBoardSkinId = chosenBoardSkinId;
		TryToLoadTavernPrefab(m_FullBoardSkin);
	}

	public void OnBoardSkinChosen(int chosenBoardSkinId)
	{
		m_ChosenCombatBoardSkinId = chosenBoardSkinId;
		TryLoadChosenBoardSkinPrefabs();
	}

	public void ProcessUnloadRequest(BaconBoardSkinBehaviour sourceBehavior)
	{
		UnloadSkinAssets();
	}

	public void NotifyOfMinionDied(Entity minion)
	{
		if (m_InBattle && !(m_FullBoardSkin.m_CombatInstance == null) && minion.IsControlledByOpposingSidePlayer())
		{
			m_minionsDefeatedCount++;
			EntityDef entityDef = minion.GetEntityDef();
			m_minionsDefeatedByPlayer.Add(entityDef.GetCardId());
			m_racesDefeatedByPlayer.Add(entityDef.GetRace());
			m_FullBoardSkin.m_CombatInstance.PlayOpponentMinionDefeatedCount(m_minionsDefeatedCount);
			m_FullBoardSkin.m_CombatInstance.PlayOpponentMinionDefeated(entityDef);
		}
	}

	private void ToggleLeaderboardFrame(bool visible)
	{
		if (m_LeaderboardFrame != null)
		{
			m_LeaderboardFrame.SetActive(visible);
		}
	}

	private void ToggleTableTop(bool visible)
	{
		if (m_TableTop != null)
		{
			m_TableTop.SetActive(visible);
		}
	}

	private void OnTransitionToBattle()
	{
		m_InBattle = true;
		TryLoadChosenBoardSkinPrefabs();
	}

	private void OnTransitionToShop()
	{
		m_InBattle = false;
		m_BattleRound++;
		m_StartedLoadingChosenBoardThisRound = false;
		m_ChosenCombatBoardSkinId = 0;
		RunVisualStateAnimators(TAG_BOARD_VISUAL_STATE.SHOP);
		SetShopLighting();
		ToggleLeaderboardFrame(!m_FullBoardSkin.m_TavernInstance.HasOwnLeaderboardFrame());
		ToggleTableTop(!m_FullBoardSkin.m_TavernInstance.HasOwnTableTop());
		RunShopAnimation(m_FullBoardSkin);
	}

	public void ChangeBoardVisualStateForPreview(TAG_BOARD_VISUAL_STATE boardState, BaconBoardSkinBehaviour combatSkin, BaconBoardSkinBehaviour tavernSkin)
	{
		RunVisualStateAnimators(boardState);
		BaconBoardSkinBehaviour baconBoardSkinBehaviour = ((boardState == TAG_BOARD_VISUAL_STATE.COMBAT) ? combatSkin : tavernSkin);
		ToggleLeaderboardFrame(!baconBoardSkinBehaviour.HasOwnLeaderboardFrame());
		ToggleTableTop(!baconBoardSkinBehaviour.HasOwnTableTop());
		if (boardState == TAG_BOARD_VISUAL_STATE.COMBAT)
		{
			combatSkin.CopyCornersFromSkin(tavernSkin);
		}
		combatSkin.SetBoardState(boardState);
		tavernSkin.SetBoardState(boardState);
	}

	public void SetShopLighting()
	{
		Action<object> action = delegate(object amount)
		{
			RenderSettings.ambientLight = (Color)amount;
		};
		Hashtable args = iTween.Hash("from", RenderSettings.ambientLight, "to", m_AmbientColor, "delay", m_ShopAmbientTransitionDelay, "time", m_ShopAmbientTransitionTime, "easeType", iTween.EaseType.easeInOutQuad, "onupdate", action, "onupdatetarget", base.gameObject);
		iTween.ValueTo(base.gameObject, args);
	}

	private void TryLoadChosenBoardSkinPrefabs()
	{
		if (m_InBattle && m_ChosenCombatBoardSkinId != 0 && !m_StartedLoadingChosenBoardThisRound)
		{
			m_StartedLoadingChosenBoardThisRound = true;
			TryToLoadPrefab(m_FullBoardSkin);
		}
	}

	private void TryToLoadPrefab(BoardSkinStatus skin)
	{
		if (m_ChosenCombatBoardSkinId == 0)
		{
			m_ChosenCombatBoardSkinId = 1;
		}
		BattlegroundsBoardSkinDbfRecord record = GameDbf.BattlegroundsBoardSkin.GetRecord(m_ChosenCombatBoardSkinId);
		string text = ((PlatformSettings.Screen != ScreenCategory.Phone) ? record.FullBoardPrefab : record.FullBoardPrefabPhone);
		m_PendingLoads++;
		AssetLoader.Get().LoadAsset<GameObject>(text, OnSkinLoaded, new BoardSkinStatusAndRound(skin, m_BattleRound));
	}

	private void TryToLoadTavernPrefab(BoardSkinStatus skin)
	{
		if (m_ChosenBoardSkinId == 0)
		{
			m_ChosenBoardSkinId = 1;
		}
		BattlegroundsBoardSkinDbfRecord record = GameDbf.BattlegroundsBoardSkin.GetRecord(m_ChosenBoardSkinId);
		string text = ((PlatformSettings.Screen != ScreenCategory.Phone) ? record.FullTavernBoardPrefab : record.FullTavernBoardPrefabPhone);
		m_PendingLoads++;
		AssetLoader.Get().LoadAsset<GameObject>(text, OnTavernSkinLoaded, skin);
	}

	private void OnTavernSkinLoaded(AssetReference assetRef, AssetHandle<GameObject> asset, object callbackData)
	{
		m_PendingLoads--;
		BoardSkinStatus boardSkinStatus = (BoardSkinStatus)callbackData;
		boardSkinStatus.m_AssetHandleTavern = asset;
		boardSkinStatus.m_TavernPrefab = asset.Asset;
		if (!AreAllAssetsLoaded())
		{
			return;
		}
		GameObject gameObject = UnityEngine.Object.Instantiate(boardSkinStatus.m_TavernPrefab);
		if (!gameObject.TryGetComponent<BaconBoardSkinBehaviour>(out boardSkinStatus.m_TavernInstance))
		{
			Debug.LogError("Attempting to get component BaconBoardSkinBehaviour but not found on " + gameObject);
			return;
		}
		ToggleLeaderboardFrame(!boardSkinStatus.m_TavernInstance.HasOwnLeaderboardFrame());
		ToggleTableTop(!boardSkinStatus.m_TavernInstance.HasOwnTableTop());
		if (m_AllAssetsLoadedCallback != null)
		{
			m_AllAssetsLoadedCallback();
		}
	}

	private void OnSkinLoaded(AssetReference assetRef, AssetHandle<GameObject> asset, object callbackData)
	{
		m_PendingLoads--;
		BoardSkinStatusAndRound obj = (BoardSkinStatusAndRound)callbackData;
		BoardSkinStatus boardSkinStatus = obj?.m_Skin;
		if (obj == null || boardSkinStatus == null)
		{
			Log.All.PrintWarning($"[BaconBoard.OnSkinLoaded] skin or skinWithRound is null, assetRef:{assetRef}");
		}
		if (obj.m_Round != m_BattleRound)
		{
			asset.Dispose();
			return;
		}
		boardSkinStatus.m_AssetHandleCombat = asset;
		boardSkinStatus.m_CombatPrefab = asset.Asset;
		if (AreAllAssetsLoaded())
		{
			TryStartBattleTransitionAnimations();
			if (m_AllAssetsLoadedCallback != null)
			{
				m_AllAssetsLoadedCallback();
			}
		}
	}

	private void RunShopAnimation(BoardSkinStatus skin)
	{
		if (skin.m_CombatInstance != null)
		{
			skin.m_CombatInstance.SetBoardState(TAG_BOARD_VISUAL_STATE.SHOP);
			skin.m_CombatInstance.QueueToUnload(this);
		}
		if (skin.m_TavernInstance != null)
		{
			skin.m_TavernInstance.SetBoardState(TAG_BOARD_VISUAL_STATE.SHOP);
		}
	}

	public void FriendlyPlayerFinisherCalled()
	{
		Entity hero = GameState.Get().GetOpposingSidePlayer().GetHero();
		if (m_currentBoardState == TAG_BOARD_VISUAL_STATE.COMBAT && hero.HasTag((GAME_TAG)1493) && hero.GetCurrentHealth() < 0)
		{
			SetOpponentHeroDefeated();
		}
	}

	public bool SetOpponentHeroDefeated()
	{
		if (m_FullBoardSkin.m_CombatInstance != null)
		{
			m_FullBoardSkin.m_CombatInstance.PlayOpponentHeroDefeated();
			return true;
		}
		return false;
	}

	private void TryStartBattleTransitionAnimations()
	{
		if (m_InBattle && !(m_FullBoardSkin.m_CombatInstance != null))
		{
			StartBattleTransitionAnimation(m_FullBoardSkin);
			ToggleLeaderboardFrame(!m_FullBoardSkin.m_CombatInstance.HasOwnLeaderboardFrame());
			ToggleTableTop(!m_FullBoardSkin.m_CombatInstance.HasOwnTableTop());
			RunVisualStateAnimators(TAG_BOARD_VISUAL_STATE.COMBAT);
		}
	}

	private void StartBattleTransitionAnimation(BoardSkinStatus skin)
	{
		GameObject gameObject = UnityEngine.Object.Instantiate(skin.m_CombatPrefab);
		if (!gameObject.TryGetComponent<BaconBoardSkinBehaviour>(out skin.m_CombatInstance))
		{
			Debug.LogError("Attempting to get component BaconBoardSkinBehaviour but not found on " + gameObject);
			return;
		}
		PlayerLeaderboardManager playerLeaderboardManager = PlayerLeaderboardManager.Get();
		int friendlyPlayerId = GameState.Get().GetFriendlyPlayerId();
		int num = ((m_CheatWinstreak > 0) ? m_CheatWinstreak : playerLeaderboardManager.GetLatestWinStreakForPlayer(friendlyPlayerId));
		if (num > 0)
		{
			skin.m_CombatInstance.RequestWinStreak(num);
		}
		int latestLoseStreakForPlayer = playerLeaderboardManager.GetLatestLoseStreakForPlayer(friendlyPlayerId);
		if (latestLoseStreakForPlayer > 0)
		{
			skin.m_CombatInstance.RequestLoseStreak(latestLoseStreakForPlayer);
		}
		if (m_minionsDefeatedCount > 0)
		{
			skin.m_CombatInstance.RequestOpponentMinionPreviouslyDefeatedCount(m_minionsDefeatedCount);
		}
		foreach (string item in m_minionsDefeatedByPlayer)
		{
			skin.m_CombatInstance.RequestFriendlyPlayerHasDefeatedMinion(item);
		}
		foreach (TAG_RACE item2 in m_racesDefeatedByPlayer)
		{
			skin.m_CombatInstance.RequestFriendlyPlayerHasDefeatedRace(item2);
		}
		if (GameState.Get().GetFriendlySidePlayer().GetHero()
			.GetRealTimePlayerLeaderboardPlace() <= 4)
		{
			skin.m_CombatInstance.RequestTopFourPlacement();
		}
		if (m_CheatHasDefeatedOpponent)
		{
			skin.m_CombatInstance.RequestHasFriendlyPlayerDefeatedOpponent();
		}
		else
		{
			List<PlayerLeaderboardRecentCombatsPanel.RecentCombatInfo> recentCombatHistoryForPlayer = playerLeaderboardManager.GetRecentCombatHistoryForPlayer(friendlyPlayerId);
			if (recentCombatHistoryForPlayer != null)
			{
				foreach (PlayerLeaderboardRecentCombatsPanel.RecentCombatInfo item3 in recentCombatHistoryForPlayer)
				{
					if (item3.isDefeated)
					{
						skin.m_CombatInstance.RequestHasFriendlyPlayerDefeatedOpponent();
						break;
					}
				}
			}
		}
		Entity hero = GameState.Get().GetFriendlySidePlayer().GetHero();
		if (hero != null)
		{
			skin.m_CombatInstance.RequestFriendlyPlayerHealthAtOrBelow(hero.GetDefHealth(), hero.GetCurrentHealth());
		}
		if (skin.m_TavernInstance != null)
		{
			skin.m_CombatInstance.CopyCornersFromSkin(skin.m_TavernInstance);
			skin.m_TavernInstance.SetBoardState(TAG_BOARD_VISUAL_STATE.COMBAT);
		}
		skin.m_CombatInstance.SetBoardState(TAG_BOARD_VISUAL_STATE.COMBAT);
	}

	public void CheckForHeroHeavyHitBoardEffects(Card sourceCard, Card targetCard)
	{
		if (m_FullBoardSkin.m_CombatInstance != null)
		{
			m_FullBoardSkin.m_CombatInstance.CheckForHeroHeavyHitBoardEffects(sourceCard, targetCard);
		}
	}

	private void UnloadSkinAssets()
	{
		m_ChosenCombatBoardSkinId = 0;
		UnloadSkinAsset(m_FullBoardSkin);
	}

	private void UnloadSkinAsset(BoardSkinStatus skin)
	{
		if (skin.m_CombatInstance != null)
		{
			UnityEngine.Object.Destroy(skin.m_CombatInstance.gameObject);
			skin.m_CombatInstance = null;
		}
		skin.m_CombatPrefab = null;
		if (skin.m_AssetHandleCombat != null)
		{
			skin.m_AssetHandleCombat.Dispose();
			skin.m_AssetHandleCombat = null;
		}
	}

	public void RunVisualStateAnimators(TAG_BOARD_VISUAL_STATE boardState)
	{
		if (m_stateChangeCallback != null)
		{
			m_stateChangeCallback(boardState);
		}
		if (m_BoardStateChangingObjects == null || m_BoardStateChangingObjects.Count == 0)
		{
			return;
		}
		foreach (PlayMakerFSM boardStateChangingObject in m_BoardStateChangingObjects)
		{
			boardStateChangingObject.SetState(EnumUtils.GetString(boardState));
		}
	}

	protected void SendBoardVisualStatChangeTelmetry(TAG_BOARD_VISUAL_STATE fromBoardState, TAG_BOARD_VISUAL_STATE toBoardState, DateTime lastBoardStateChangeDateTime)
	{
		int timeInSeconds = (int)(DateTime.Now - lastBoardStateChangeDateTime).TotalSeconds;
		TelemetryManager.Client().SendBoardVisualStateChanged(fromBoardState.ToString(), toBoardState.ToString(), timeInSeconds);
	}
}
