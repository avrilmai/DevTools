using System.Collections.Generic;
using UnityEngine;

public class AdventureModeDbfAsset : ScriptableObject
{
	public List<AdventureModeDbfRecord> Records = new List<AdventureModeDbfRecord>();
}
