using System.Collections.Generic;
using UnityEngine;

public class AchieveConditionDbfAsset : ScriptableObject
{
	public List<AchieveConditionDbfRecord> Records = new List<AchieveConditionDbfRecord>();
}
