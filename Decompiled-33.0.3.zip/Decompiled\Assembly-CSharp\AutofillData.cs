public class AutofillData
{
	public bool m_isShiftTab;

	public string m_lastAutofillParamPrefix;

	public string m_lastAutofillParamMatch;
}
