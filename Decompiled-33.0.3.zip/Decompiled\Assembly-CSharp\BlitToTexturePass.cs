using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class BlitToTexturePass : ScriptableRenderPass
{
	private const string ProfilerTag = "BlitToTexture";

	private readonly Material m_blitMaterial;

	private static readonly int s_offsetAndScale = Shader.PropertyToID("uvOffsetAndScale");

	private static readonly int s_uvRotateMtx = Shader.PropertyToID("uvRotateMtx");

	private readonly List<BlitToTextureService.Request> m_requests = new List<BlitToTextureService.Request>();

	private readonly BlitToTextureRenderLatePass m_blitToTextureRenderLatePass;

	public RenderTargetIdentifier CameraColorTarget;

	public BlitToTexturePass(BlitToTextureRenderLatePass blitToTextureRenderLatePass)
	{
		m_blitToTextureRenderLatePass = blitToTextureRenderLatePass;
		Shader shader = Shader.Find("Hidden/HS_URP/BlitToTexture");
		if ((bool)shader)
		{
			m_blitMaterial = new Material(shader);
		}
	}

	public void EnqueueRequest(BlitToTextureService.Request request)
	{
		m_requests.Add(request);
	}

	public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
	{
		if (!m_blitMaterial)
		{
			return;
		}
		CommandBuffer commandBuffer = CommandBufferPool.Get("BlitToTexture");
		Camera camera = renderingData.cameraData.camera;
		foreach (BlitToTextureService.Request request in m_requests)
		{
			Vector3 vector = camera.ScreenToViewportPoint(request.Offset);
			Vector3 vector2 = camera.ScreenToViewportPoint(request.Size);
			m_blitMaterial.SetVector(s_offsetAndScale, new Vector4(vector.x, vector.y, vector2.x, vector2.y));
			float f = (float)Math.PI / 180f * request.RotationDeg;
			Vector4 value = new Vector4(Mathf.Cos(f), 0f - Mathf.Sin(f), Mathf.Sin(f), Mathf.Cos(f));
			m_blitMaterial.SetVector(s_uvRotateMtx, value);
			Blit(commandBuffer, CameraColorTarget, request.TargetTexture, m_blitMaterial);
			if (request.DrawAfterRenderer != null)
			{
				m_blitToTextureRenderLatePass.EnqueueRenderer(request.DrawAfterRenderer);
			}
		}
		m_requests.Clear();
		context.ExecuteCommandBuffer(commandBuffer);
		CommandBufferPool.Release(commandBuffer);
	}
}
