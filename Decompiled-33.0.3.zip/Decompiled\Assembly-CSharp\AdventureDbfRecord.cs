using System;
using System.Collections.Generic;
using Blizzard.T5.Jobs;
using UnityEngine;

[Serializable]
public class AdventureDbfRecord : DbfRecord
{
	[SerializeField]
	private string m_noteDesc;

	[SerializeField]
	private DbfLocValue m_name;

	[SerializeField]
	private int m_sortOrder;

	[SerializeField]
	private DbfLocValue m_storeBuyButtonLabel;

	[SerializeField]
	private DbfLocValue m_storeBuyWings1Headline;

	[SerializeField]
	private DbfLocValue m_storeBuyWings2Headline;

	[SerializeField]
	private DbfLocValue m_storeBuyWings3Headline;

	[SerializeField]
	private DbfLocValue m_storeBuyWings4Headline;

	[SerializeField]
	private DbfLocValue m_storeBuyWings5Headline;

	[SerializeField]
	private DbfLocValue m_storeOwnedHeadline;

	[SerializeField]
	private DbfLocValue m_storePreorderHeadline;

	[SerializeField]
	private DbfLocValue m_storeBuyWings1Desc;

	[SerializeField]
	private DbfLocValue m_storeBuyWings2Desc;

	[SerializeField]
	private DbfLocValue m_storeBuyWings3Desc;

	[SerializeField]
	private DbfLocValue m_storeBuyWings4Desc;

	[SerializeField]
	private DbfLocValue m_storeBuyWings5Desc;

	[SerializeField]
	private DbfLocValue m_storeBuyRemainingWingsDescTimelockedTrue;

	[SerializeField]
	private DbfLocValue m_storeBuyRemainingWingsDescTimelockedFalse;

	[SerializeField]
	private DbfLocValue m_storeOwnedDesc;

	[SerializeField]
	private DbfLocValue m_storePreorderWings1Desc;

	[SerializeField]
	private DbfLocValue m_storePreorderWings2Desc;

	[SerializeField]
	private DbfLocValue m_storePreorderWings3Desc;

	[SerializeField]
	private DbfLocValue m_storePreorderWings4Desc;

	[SerializeField]
	private DbfLocValue m_storePreorderWings5Desc;

	[SerializeField]
	private DbfLocValue m_storePreorderRadioText;

	[SerializeField]
	private DbfLocValue m_storePreviewRewardsText;

	[SerializeField]
	private string m_adventureDefPrefab;

	[SerializeField]
	private string m_storePrefab;

	[SerializeField]
	private bool m_leavingSoon;

	[SerializeField]
	private DbfLocValue m_leavingSoonText;

	[SerializeField]
	private string m_gameModeIcon;

	[SerializeField]
	private string m_productStringKey;

	[SerializeField]
	private SpecialEventType m_standardEvent = DbfShared.GetEventMap().ConvertStringToSpecialEvent("always");

	[SerializeField]
	private SpecialEventType m_comingSoonEvent = DbfShared.GetEventMap().ConvertStringToSpecialEvent("never");

	[SerializeField]
	private DbfLocValue m_comingSoonText;

	[SerializeField]
	private bool m_mapPageHasButtonsToChapters;

	[DbfField("NAME")]
	public DbfLocValue Name => m_name;

	[DbfField("SORT_ORDER")]
	public int SortOrder => m_sortOrder;

	[DbfField("STORE_BUY_BUTTON_LABEL")]
	public DbfLocValue StoreBuyButtonLabel => m_storeBuyButtonLabel;

	[DbfField("STORE_OWNED_HEADLINE")]
	public DbfLocValue StoreOwnedHeadline => m_storeOwnedHeadline;

	[DbfField("STORE_PREORDER_HEADLINE")]
	public DbfLocValue StorePreorderHeadline => m_storePreorderHeadline;

	[DbfField("STORE_BUY_REMAINING_WINGS_DESC_TIMELOCKED_TRUE")]
	public DbfLocValue StoreBuyRemainingWingsDescTimelockedTrue => m_storeBuyRemainingWingsDescTimelockedTrue;

	[DbfField("STORE_BUY_REMAINING_WINGS_DESC_TIMELOCKED_FALSE")]
	public DbfLocValue StoreBuyRemainingWingsDescTimelockedFalse => m_storeBuyRemainingWingsDescTimelockedFalse;

	[DbfField("STORE_OWNED_DESC")]
	public DbfLocValue StoreOwnedDesc => m_storeOwnedDesc;

	[DbfField("STORE_PREORDER_RADIO_TEXT")]
	public DbfLocValue StorePreorderRadioText => m_storePreorderRadioText;

	[DbfField("STORE_PREVIEW_REWARDS_TEXT")]
	public DbfLocValue StorePreviewRewardsText => m_storePreviewRewardsText;

	[DbfField("ADVENTURE_DEF_PREFAB")]
	public string AdventureDefPrefab => m_adventureDefPrefab;

	[DbfField("STORE_PREFAB")]
	public string StorePrefab => m_storePrefab;

	[DbfField("LEAVING_SOON")]
	public bool LeavingSoon => m_leavingSoon;

	[DbfField("LEAVING_SOON_TEXT")]
	public DbfLocValue LeavingSoonText => m_leavingSoonText;

	[DbfField("GAME_MODE_ICON")]
	public string GameModeIcon => m_gameModeIcon;

	[DbfField("PRODUCT_STRING_KEY")]
	public string ProductStringKey => m_productStringKey;

	[DbfField("STANDARD_EVENT")]
	public SpecialEventType StandardEvent => m_standardEvent;

	[DbfField("COMING_SOON_EVENT")]
	public SpecialEventType ComingSoonEvent => m_comingSoonEvent;

	[DbfField("COMING_SOON_TEXT")]
	public DbfLocValue ComingSoonText => m_comingSoonText;

	[DbfField("MAP_PAGE_HAS_BUTTONS_TO_CHAPTERS")]
	public bool MapPageHasButtonsToChapters => m_mapPageHasButtonsToChapters;

	public List<AdventureHeroPowerDbfRecord> AdventureHeroPowers
	{
		get
		{
			int iD = base.ID;
			List<AdventureHeroPowerDbfRecord> list = new List<AdventureHeroPowerDbfRecord>();
			List<AdventureHeroPowerDbfRecord> records = GameDbf.AdventureHeroPower.GetRecords();
			int i = 0;
			for (int count = records.Count; i < count; i++)
			{
				AdventureHeroPowerDbfRecord adventureHeroPowerDbfRecord = records[i];
				if (adventureHeroPowerDbfRecord.AdventureId == iD)
				{
					list.Add(adventureHeroPowerDbfRecord);
				}
			}
			return list;
		}
	}

	public List<AdventureLoadoutTreasuresDbfRecord> AdventureLoadoutTreasures
	{
		get
		{
			int iD = base.ID;
			List<AdventureLoadoutTreasuresDbfRecord> list = new List<AdventureLoadoutTreasuresDbfRecord>();
			List<AdventureLoadoutTreasuresDbfRecord> records = GameDbf.AdventureLoadoutTreasures.GetRecords();
			int i = 0;
			for (int count = records.Count; i < count; i++)
			{
				AdventureLoadoutTreasuresDbfRecord adventureLoadoutTreasuresDbfRecord = records[i];
				if (adventureLoadoutTreasuresDbfRecord.AdventureId == iD)
				{
					list.Add(adventureLoadoutTreasuresDbfRecord);
				}
			}
			return list;
		}
	}

	public List<WingDbfRecord> Wings
	{
		get
		{
			int iD = base.ID;
			List<WingDbfRecord> list = new List<WingDbfRecord>();
			List<WingDbfRecord> records = GameDbf.Wing.GetRecords();
			int i = 0;
			for (int count = records.Count; i < count; i++)
			{
				WingDbfRecord wingDbfRecord = records[i];
				if (wingDbfRecord.AdventureId == iD)
				{
					list.Add(wingDbfRecord);
				}
			}
			return list;
		}
	}

	public override object GetVar(string name)
	{
		switch (name)
		{
		case "ID":
			return base.ID;
		case "NOTE_DESC":
			return m_noteDesc;
		case "NAME":
			return m_name;
		case "SORT_ORDER":
			return m_sortOrder;
		case "STORE_BUY_BUTTON_LABEL":
			return m_storeBuyButtonLabel;
		case "STORE_BUY_WINGS_1_HEADLINE":
			return m_storeBuyWings1Headline;
		case "STORE_BUY_WINGS_2_HEADLINE":
			return m_storeBuyWings2Headline;
		case "STORE_BUY_WINGS_3_HEADLINE":
			return m_storeBuyWings3Headline;
		case "STORE_BUY_WINGS_4_HEADLINE":
			return m_storeBuyWings4Headline;
		case "STORE_BUY_WINGS_5_HEADLINE":
			return m_storeBuyWings5Headline;
		case "STORE_OWNED_HEADLINE":
			return m_storeOwnedHeadline;
		case "STORE_PREORDER_HEADLINE":
			return m_storePreorderHeadline;
		case "STORE_BUY_WINGS_1_DESC":
			return m_storeBuyWings1Desc;
		case "STORE_BUY_WINGS_2_DESC":
			return m_storeBuyWings2Desc;
		case "STORE_BUY_WINGS_3_DESC":
			return m_storeBuyWings3Desc;
		case "STORE_BUY_WINGS_4_DESC":
			return m_storeBuyWings4Desc;
		case "STORE_BUY_WINGS_5_DESC":
			return m_storeBuyWings5Desc;
		case "STORE_BUY_REMAINING_WINGS_DESC_TIMELOCKED_TRUE":
			return m_storeBuyRemainingWingsDescTimelockedTrue;
		case "STORE_BUY_REMAINING_WINGS_DESC_TIMELOCKED_FALSE":
			return m_storeBuyRemainingWingsDescTimelockedFalse;
		case "STORE_OWNED_DESC":
			return m_storeOwnedDesc;
		case "STORE_PREORDER_WINGS_1_DESC":
			return m_storePreorderWings1Desc;
		case "STORE_PREORDER_WINGS_2_DESC":
			return m_storePreorderWings2Desc;
		case "STORE_PREORDER_WINGS_3_DESC":
			return m_storePreorderWings3Desc;
		case "STORE_PREORDER_WINGS_4_DESC":
			return m_storePreorderWings4Desc;
		case "STORE_PREORDER_WINGS_5_DESC":
			return m_storePreorderWings5Desc;
		case "STORE_PREORDER_RADIO_TEXT":
			return m_storePreorderRadioText;
		case "STORE_PREVIEW_REWARDS_TEXT":
			return m_storePreviewRewardsText;
		case "ADVENTURE_DEF_PREFAB":
			return m_adventureDefPrefab;
		case "STORE_PREFAB":
			return m_storePrefab;
		case "LEAVING_SOON":
			return m_leavingSoon;
		case "LEAVING_SOON_TEXT":
			return m_leavingSoonText;
		case "GAME_MODE_ICON":
			return m_gameModeIcon;
		case "PRODUCT_STRING_KEY":
			return m_productStringKey;
		case "STANDARD_EVENT":
			return m_standardEvent;
		case "COMING_SOON_EVENT":
			return m_comingSoonEvent;
		case "COMING_SOON_TEXT":
			return m_comingSoonText;
		case "MAP_PAGE_HAS_BUTTONS_TO_CHAPTERS":
			return m_mapPageHasButtonsToChapters;
		default:
			return null;
		}
	}

	public override void SetVar(string name, object val)
	{
		switch (name)
		{
		case "ID":
			SetID((int)val);
			break;
		case "NOTE_DESC":
			m_noteDesc = (string)val;
			break;
		case "NAME":
			m_name = (DbfLocValue)val;
			break;
		case "SORT_ORDER":
			m_sortOrder = (int)val;
			break;
		case "STORE_BUY_BUTTON_LABEL":
			m_storeBuyButtonLabel = (DbfLocValue)val;
			break;
		case "STORE_BUY_WINGS_1_HEADLINE":
			m_storeBuyWings1Headline = (DbfLocValue)val;
			break;
		case "STORE_BUY_WINGS_2_HEADLINE":
			m_storeBuyWings2Headline = (DbfLocValue)val;
			break;
		case "STORE_BUY_WINGS_3_HEADLINE":
			m_storeBuyWings3Headline = (DbfLocValue)val;
			break;
		case "STORE_BUY_WINGS_4_HEADLINE":
			m_storeBuyWings4Headline = (DbfLocValue)val;
			break;
		case "STORE_BUY_WINGS_5_HEADLINE":
			m_storeBuyWings5Headline = (DbfLocValue)val;
			break;
		case "STORE_OWNED_HEADLINE":
			m_storeOwnedHeadline = (DbfLocValue)val;
			break;
		case "STORE_PREORDER_HEADLINE":
			m_storePreorderHeadline = (DbfLocValue)val;
			break;
		case "STORE_BUY_WINGS_1_DESC":
			m_storeBuyWings1Desc = (DbfLocValue)val;
			break;
		case "STORE_BUY_WINGS_2_DESC":
			m_storeBuyWings2Desc = (DbfLocValue)val;
			break;
		case "STORE_BUY_WINGS_3_DESC":
			m_storeBuyWings3Desc = (DbfLocValue)val;
			break;
		case "STORE_BUY_WINGS_4_DESC":
			m_storeBuyWings4Desc = (DbfLocValue)val;
			break;
		case "STORE_BUY_WINGS_5_DESC":
			m_storeBuyWings5Desc = (DbfLocValue)val;
			break;
		case "STORE_BUY_REMAINING_WINGS_DESC_TIMELOCKED_TRUE":
			m_storeBuyRemainingWingsDescTimelockedTrue = (DbfLocValue)val;
			break;
		case "STORE_BUY_REMAINING_WINGS_DESC_TIMELOCKED_FALSE":
			m_storeBuyRemainingWingsDescTimelockedFalse = (DbfLocValue)val;
			break;
		case "STORE_OWNED_DESC":
			m_storeOwnedDesc = (DbfLocValue)val;
			break;
		case "STORE_PREORDER_WINGS_1_DESC":
			m_storePreorderWings1Desc = (DbfLocValue)val;
			break;
		case "STORE_PREORDER_WINGS_2_DESC":
			m_storePreorderWings2Desc = (DbfLocValue)val;
			break;
		case "STORE_PREORDER_WINGS_3_DESC":
			m_storePreorderWings3Desc = (DbfLocValue)val;
			break;
		case "STORE_PREORDER_WINGS_4_DESC":
			m_storePreorderWings4Desc = (DbfLocValue)val;
			break;
		case "STORE_PREORDER_WINGS_5_DESC":
			m_storePreorderWings5Desc = (DbfLocValue)val;
			break;
		case "STORE_PREORDER_RADIO_TEXT":
			m_storePreorderRadioText = (DbfLocValue)val;
			break;
		case "STORE_PREVIEW_REWARDS_TEXT":
			m_storePreviewRewardsText = (DbfLocValue)val;
			break;
		case "ADVENTURE_DEF_PREFAB":
			m_adventureDefPrefab = (string)val;
			break;
		case "STORE_PREFAB":
			m_storePrefab = (string)val;
			break;
		case "LEAVING_SOON":
			m_leavingSoon = (bool)val;
			break;
		case "LEAVING_SOON_TEXT":
			m_leavingSoonText = (DbfLocValue)val;
			break;
		case "GAME_MODE_ICON":
			m_gameModeIcon = (string)val;
			break;
		case "PRODUCT_STRING_KEY":
			m_productStringKey = (string)val;
			break;
		case "STANDARD_EVENT":
			m_standardEvent = DbfShared.GetEventMap().ConvertStringToSpecialEvent((string)val);
			break;
		case "COMING_SOON_EVENT":
			m_comingSoonEvent = DbfShared.GetEventMap().ConvertStringToSpecialEvent((string)val);
			break;
		case "COMING_SOON_TEXT":
			m_comingSoonText = (DbfLocValue)val;
			break;
		case "MAP_PAGE_HAS_BUTTONS_TO_CHAPTERS":
			m_mapPageHasButtonsToChapters = (bool)val;
			break;
		}
	}

	public override Type GetVarType(string name)
	{
		switch (name)
		{
		case "ID":
			return typeof(int);
		case "NOTE_DESC":
			return typeof(string);
		case "NAME":
			return typeof(DbfLocValue);
		case "SORT_ORDER":
			return typeof(int);
		case "STORE_BUY_BUTTON_LABEL":
			return typeof(DbfLocValue);
		case "STORE_BUY_WINGS_1_HEADLINE":
			return typeof(DbfLocValue);
		case "STORE_BUY_WINGS_2_HEADLINE":
			return typeof(DbfLocValue);
		case "STORE_BUY_WINGS_3_HEADLINE":
			return typeof(DbfLocValue);
		case "STORE_BUY_WINGS_4_HEADLINE":
			return typeof(DbfLocValue);
		case "STORE_BUY_WINGS_5_HEADLINE":
			return typeof(DbfLocValue);
		case "STORE_OWNED_HEADLINE":
			return typeof(DbfLocValue);
		case "STORE_PREORDER_HEADLINE":
			return typeof(DbfLocValue);
		case "STORE_BUY_WINGS_1_DESC":
			return typeof(DbfLocValue);
		case "STORE_BUY_WINGS_2_DESC":
			return typeof(DbfLocValue);
		case "STORE_BUY_WINGS_3_DESC":
			return typeof(DbfLocValue);
		case "STORE_BUY_WINGS_4_DESC":
			return typeof(DbfLocValue);
		case "STORE_BUY_WINGS_5_DESC":
			return typeof(DbfLocValue);
		case "STORE_BUY_REMAINING_WINGS_DESC_TIMELOCKED_TRUE":
			return typeof(DbfLocValue);
		case "STORE_BUY_REMAINING_WINGS_DESC_TIMELOCKED_FALSE":
			return typeof(DbfLocValue);
		case "STORE_OWNED_DESC":
			return typeof(DbfLocValue);
		case "STORE_PREORDER_WINGS_1_DESC":
			return typeof(DbfLocValue);
		case "STORE_PREORDER_WINGS_2_DESC":
			return typeof(DbfLocValue);
		case "STORE_PREORDER_WINGS_3_DESC":
			return typeof(DbfLocValue);
		case "STORE_PREORDER_WINGS_4_DESC":
			return typeof(DbfLocValue);
		case "STORE_PREORDER_WINGS_5_DESC":
			return typeof(DbfLocValue);
		case "STORE_PREORDER_RADIO_TEXT":
			return typeof(DbfLocValue);
		case "STORE_PREVIEW_REWARDS_TEXT":
			return typeof(DbfLocValue);
		case "ADVENTURE_DEF_PREFAB":
			return typeof(string);
		case "STORE_PREFAB":
			return typeof(string);
		case "LEAVING_SOON":
			return typeof(bool);
		case "LEAVING_SOON_TEXT":
			return typeof(DbfLocValue);
		case "GAME_MODE_ICON":
			return typeof(string);
		case "PRODUCT_STRING_KEY":
			return typeof(string);
		case "STANDARD_EVENT":
			return typeof(string);
		case "COMING_SOON_EVENT":
			return typeof(string);
		case "COMING_SOON_TEXT":
			return typeof(DbfLocValue);
		case "MAP_PAGE_HAS_BUTTONS_TO_CHAPTERS":
			return typeof(bool);
		default:
			return null;
		}
	}

	public override IEnumerator<IAsyncJobResult> Job_LoadRecordsFromAssetAsync<T>(string resourcePath, Action<List<T>> resultHandler)
	{
		LoadAdventureDbfRecords loadRecords = new LoadAdventureDbfRecords(resourcePath);
		yield return loadRecords;
		resultHandler?.Invoke(loadRecords.GetRecords() as List<T>);
	}

	public override bool LoadRecordsFromAsset<T>(string resourcePath, out List<T> records)
	{
		AdventureDbfAsset adventureDbfAsset = DbfShared.GetAssetBundle().LoadAsset(resourcePath, typeof(AdventureDbfAsset)) as AdventureDbfAsset;
		if (adventureDbfAsset == null)
		{
			records = new List<T>();
			Debug.LogError($"AdventureDbfAsset.LoadRecordsFromAsset() - failed to load records from assetbundle: {resourcePath}");
			return false;
		}
		for (int i = 0; i < adventureDbfAsset.Records.Count; i++)
		{
			adventureDbfAsset.Records[i].StripUnusedLocales();
		}
		records = adventureDbfAsset.Records as List<T>;
		return true;
	}

	public override bool SaveRecordsToAsset<T>(string assetPath, List<T> records, Locale locale)
	{
		return false;
	}

	public override void StripUnusedLocales()
	{
		m_name.StripUnusedLocales();
		m_storeBuyButtonLabel.StripUnusedLocales();
		m_storeBuyWings1Headline.StripUnusedLocales();
		m_storeBuyWings2Headline.StripUnusedLocales();
		m_storeBuyWings3Headline.StripUnusedLocales();
		m_storeBuyWings4Headline.StripUnusedLocales();
		m_storeBuyWings5Headline.StripUnusedLocales();
		m_storeOwnedHeadline.StripUnusedLocales();
		m_storePreorderHeadline.StripUnusedLocales();
		m_storeBuyWings1Desc.StripUnusedLocales();
		m_storeBuyWings2Desc.StripUnusedLocales();
		m_storeBuyWings3Desc.StripUnusedLocales();
		m_storeBuyWings4Desc.StripUnusedLocales();
		m_storeBuyWings5Desc.StripUnusedLocales();
		m_storeBuyRemainingWingsDescTimelockedTrue.StripUnusedLocales();
		m_storeBuyRemainingWingsDescTimelockedFalse.StripUnusedLocales();
		m_storeOwnedDesc.StripUnusedLocales();
		m_storePreorderWings1Desc.StripUnusedLocales();
		m_storePreorderWings2Desc.StripUnusedLocales();
		m_storePreorderWings3Desc.StripUnusedLocales();
		m_storePreorderWings4Desc.StripUnusedLocales();
		m_storePreorderWings5Desc.StripUnusedLocales();
		m_storePreorderRadioText.StripUnusedLocales();
		m_storePreviewRewardsText.StripUnusedLocales();
		m_leavingSoonText.StripUnusedLocales();
		m_comingSoonText.StripUnusedLocales();
	}
}
