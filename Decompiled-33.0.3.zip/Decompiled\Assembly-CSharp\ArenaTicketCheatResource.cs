public class ArenaTicketCheatResource : CheatResource
{
	public int? TicketCount;
}
