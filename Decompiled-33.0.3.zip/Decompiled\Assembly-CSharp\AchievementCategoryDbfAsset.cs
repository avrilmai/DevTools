using System.Collections.Generic;
using UnityEngine;

public class AchievementCategoryDbfAsset : ScriptableObject
{
	public List<AchievementCategoryDbfRecord> Records = new List<AchievementCategoryDbfRecord>();
}
