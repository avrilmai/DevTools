public enum AdventureBookPageMoralAlignment
{
	NEUTRAL = -1,
	GOOD,
	EVIL
}
