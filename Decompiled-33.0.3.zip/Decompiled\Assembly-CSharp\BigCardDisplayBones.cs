using UnityEngine;

public class BigCardDisplayBones : MonoBehaviour
{
	public GameObject_MobileOverride m_BoneRigs;

	public void GetRigForCurrentPlatform(out GameObject rig, out BigCardBoneLayout.ScaleSettings scale)
	{
		if (m_BoneRigs == null)
		{
			rig = null;
			scale = null;
			return;
		}
		GameObject valueForScreen = m_BoneRigs.GetValueForScreen(PlatformSettings.Screen, null);
		if (valueForScreen == null)
		{
			rig = null;
			scale = null;
			return;
		}
		BigCardBoneLayout component = valueForScreen.GetComponent<BigCardBoneLayout>();
		if (component == null || !component.HasAllBones())
		{
			rig = null;
			scale = null;
		}
		else
		{
			rig = valueForScreen;
			scale = component.m_scaleSettings;
		}
	}

	public bool HasBonesForCurrentPlatform()
	{
		GetRigForCurrentPlatform(out var rig, out var _);
		if (rig == null)
		{
			return false;
		}
		BigCardBoneLayout component = rig.GetComponent<BigCardBoneLayout>();
		if (component == null)
		{
			return false;
		}
		return component.HasAllBones();
	}
}
