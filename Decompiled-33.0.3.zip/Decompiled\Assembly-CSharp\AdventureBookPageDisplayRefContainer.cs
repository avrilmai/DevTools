using Hearthstone.UI;
using UnityEngine;

public class AdventureBookPageDisplayRefContainer : MonoBehaviour
{
	public AsyncReference m_AdventureBookMapReference;

	public AsyncReference m_BasePageRendererReference;
}
