using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackSpellController : SpellController
{
	public HeroAttackDef m_HeroInfo;

	public AllyAttackDef m_AllyInfo;

	public float m_ImpactStagingPoint = 1f;

	public float m_SourceImpactOffset = -0.25f;

	public SpellHandleValueRange[] m_ImpactDefHandles;

	public SpellHandleValueRange[] m_CriticalImpactDefHandles;

	public string m_DefaultImpactSpellPrefabHandle;

	private const float PROPOSED_ATTACK_IMPACT_POINT_SCALAR = 0.5f;

	private const float WINDFURY_REMINDER_WAIT_SEC = 1.2f;

	private const int FINISHER_DAMAGE_THRESHOLD = 15;

	private AttackType m_attackType;

	private Spell m_sourceAttackSpell;

	private Coroutine m_finisherTrackingCoroutine;

	private readonly WaitForSeconds MAX_FINISHER_DURATION = new WaitForSeconds(15f);

	private Vector3 m_sourcePos;

	private Vector3 m_sourceToTarget;

	private Vector3 m_sourceFacing;

	private bool m_repeatProposed;

	protected override bool AddPowerSourceAndTargets(PowerTaskList taskList)
	{
		m_attackType = taskList.GetAttackType();
		m_repeatProposed = taskList.IsRepeatProposedAttack();
		if (m_attackType == AttackType.INVALID)
		{
			return false;
		}
		Entity attacker = taskList.GetAttacker();
		if (attacker != null)
		{
			SetSource(attacker.GetCard());
		}
		Entity defender = taskList.GetDefender();
		if (defender != null)
		{
			AddTarget(defender.GetCard());
		}
		return true;
	}

	protected override void OnProcessTaskList()
	{
		if (m_attackType == AttackType.ONLY_PROPOSED_ATTACKER || m_attackType == AttackType.ONLY_PROPOSED_DEFENDER || m_attackType == AttackType.ONLY_ATTACKER || m_attackType == AttackType.ONLY_DEFENDER || m_attackType == AttackType.WAITING_ON_PROPOSED_ATTACKER || m_attackType == AttackType.WAITING_ON_PROPOSED_DEFENDER || m_attackType == AttackType.WAITING_ON_ATTACKER || m_attackType == AttackType.WAITING_ON_DEFENDER)
		{
			FinishEverything();
			return;
		}
		if (m_repeatProposed)
		{
			FinishEverything();
			return;
		}
		Card source = GetSource();
		if (source == null || source.GetActor() == null)
		{
			FinishEverything();
			return;
		}
		Entity entity = source.GetEntity();
		if (entity == null)
		{
			FinishEverything();
			return;
		}
		Zone zone = source.GetZone();
		if (zone == null)
		{
			zone = ZoneMgr.Get().FindZoneOfType<ZonePlay>(source.GetControllerSide());
		}
		if ((GameMgr.Get().IsBattlegrounds() || GameMgr.Get().IsBattlegroundsTutorial() || GameMgr.Get().IsFriendlyBattlegrounds()) && entity.IsHero())
		{
			FinisherGameplaySettings finisherGameplaySettings = FinisherGameplaySettings.GetFinisherGameplaySettings(entity);
			Card target = GetTarget();
			Entity entity2 = target.GetEntity();
			bool flag = entity.IsControlledByOpposingSidePlayer();
			string text = GetSpellPath(entity, entity2, flag, finisherGameplaySettings);
			if (string.IsNullOrEmpty(text))
			{
				AssetReference assetReference = AssetReference.CreateFromAssetString(GameDbf.BattlegroundsFinisher.GetRecord(1).GameplaySettings);
				finisherGameplaySettings = AssetLoader.Get().LoadAsset<FinisherGameplaySettings>(assetReference).Asset;
				int num = entity.GetTag(GAME_TAG.BATTLEGROUNDS_FAVORITE_FINISHER);
				if (flag)
				{
					Log.Spells.PrintError($"Finisher ID {num} is missing a small opponent finisher prefab entry in its gameplay settings. Using default finisher.");
					text = finisherGameplaySettings.SmallOpponentPrefab;
				}
				else
				{
					Log.Spells.PrintError($"Finisher ID {num} is missing a small finisher prefab entry in its gameplay settings. Using default finisher.");
					text = finisherGameplaySettings.SmallPrefab;
				}
				if (string.IsNullOrEmpty(text))
				{
					string text2 = (flag ? "Small Opponent" : "Small");
					Error.AddDevWarning("Missing Default Finisher Path", "Unable to get spellpath for the " + text2 + " Default Finisher. Make sure " + assetReference.FileName + " contains a prefab for " + text2 + " Prefab.");
				}
			}
			m_sourceAttackSpell = InstantiateFinisherSpell(source.gameObject, text);
			if (m_sourceAttackSpell != null)
			{
				m_sourceAttackSpell.SetSource(source.gameObject);
				m_sourceAttackSpell.AddTarget(target.gameObject);
				m_sourceAttackSpell.AddFinishedCallback(OnBattlegroundsFinisherFinished, finisherGameplaySettings);
				m_finisherTrackingCoroutine = StartCoroutine(EnsureFinisherCompletes(m_sourceAttackSpell));
				SuperSpell superSpell = m_sourceAttackSpell as SuperSpell;
				if (superSpell != null)
				{
					superSpell.ActivateFinisher(flag);
				}
				else
				{
					m_sourceAttackSpell.Activate();
				}
				return;
			}
			int num2 = entity.GetTag(GAME_TAG.BATTLEGROUNDS_FAVORITE_FINISHER);
			Log.Spells.PrintError($"Finisher ID {num2} failed to instantiate finisher spell at {text}. No spell will be played.");
		}
		bool flag2 = zone.m_Side == Player.Side.FRIENDLY;
		m_sourceAttackSpell = GetSourceAttackSpell(source, flag2);
		if (m_attackType == AttackType.CANCELED)
		{
			CancelAttackSpell(entity, m_sourceAttackSpell);
			source.SetDoNotSort(on: false);
			zone.UpdateLayout();
			source.EnableAttacking(enable: false);
			FinishEverything();
			return;
		}
		if (m_sourceAttackSpell == null)
		{
			FinishEverything();
			return;
		}
		source.EnableAttacking(enable: true);
		if (entity.GetTag(GAME_TAG.IMMUNE_WHILE_ATTACKING) != 0)
		{
			source.ActivateActorSpell(SpellType.IMMUNE);
		}
		else if (!source.ShouldShowImmuneVisuals())
		{
			SpellUtils.ActivateDeathIfNecessary(source.GetActor().GetSpellIfLoaded(SpellType.IMMUNE));
		}
		m_sourceAttackSpell.AddStateStartedCallback(OnSourceAttackStateStarted);
		if (GameState.Get().GetBooleanGameOption(GameEntityOption.USE_FASTER_ATTACK_SPELL_BIRTH_STATE))
		{
			List<SpellState> spellStates = m_sourceAttackSpell.GetSpellStates(SpellStateType.BIRTH);
			if (spellStates != null)
			{
				foreach (SpellState item in spellStates)
				{
					if (item.m_ExternalAnimatedObjects == null)
					{
						continue;
					}
					foreach (SpellStateAnimObject externalAnimatedObject in item.m_ExternalAnimatedObjects)
					{
						externalAnimatedObject.m_AnimSpeed = 2f;
					}
				}
			}
		}
		if (flag2)
		{
			if (m_sourceAttackSpell.GetActiveState() != SpellStateType.IDLE && m_sourceAttackSpell.GetActiveState() != SpellStateType.ACTION)
			{
				m_sourceAttackSpell.ActivateState(SpellStateType.BIRTH);
			}
			else
			{
				m_sourceAttackSpell.ActivateState(SpellStateType.ACTION);
			}
		}
		else if (m_sourceAttackSpell.GetActiveState() != SpellStateType.IDLE && m_sourceAttackSpell.GetActiveState() != SpellStateType.ACTION)
		{
			m_sourceAttackSpell.ActivateState(SpellStateType.BIRTH);
		}
		else
		{
			m_sourceAttackSpell.ActivateState(SpellStateType.ACTION);
		}
	}

	private void OnSourceAttackStateStarted(Spell spell, SpellStateType prevStateType, object userData)
	{
		switch (spell.GetActiveState())
		{
		case SpellStateType.IDLE:
			spell.ActivateState(SpellStateType.ACTION);
			break;
		case SpellStateType.ACTION:
			spell.RemoveStateStartedCallback(OnSourceAttackStateStarted);
			LaunchAttack();
			break;
		}
	}

	private void LaunchAttack()
	{
		Card source = GetSource();
		Entity entity = source.GetEntity();
		Card target = GetTarget();
		bool flag = m_attackType == AttackType.PROPOSED;
		if (flag && entity.IsHero())
		{
			m_sourceAttackSpell.ActivateState(SpellStateType.IDLE);
			FinishEverything();
			return;
		}
		m_sourcePos = source.transform.position;
		m_sourceToTarget = target.transform.position - m_sourcePos;
		Vector3 impactPos = ComputeImpactPos();
		source.SetDoNotSort(!flag);
		MoveSourceToTarget(source, entity, impactPos);
		if (entity.IsHero())
		{
			OrientSourceHeroToTarget(source);
		}
		if (!flag)
		{
			target.SetDoNotSort(on: true);
			MoveTargetToSource(target, entity, impactPos);
		}
	}

	private bool HasFinishAttackSpellOnDamage()
	{
		Card source = GetSource();
		if (source == null)
		{
			return false;
		}
		Entity entity = source.GetEntity();
		if (entity == null)
		{
			return false;
		}
		if (!entity.IsHero())
		{
			return entity.HasTag(GAME_TAG.FINISH_ATTACK_SPELL_ON_DAMAGE);
		}
		Player controller = entity.GetController();
		if (controller == null)
		{
			return false;
		}
		Card weaponCard = controller.GetWeaponCard();
		if (weaponCard == null)
		{
			return false;
		}
		return weaponCard.GetEntity()?.HasTag(GAME_TAG.FINISH_ATTACK_SPELL_ON_DAMAGE) ?? false;
	}

	private void UpdateTargetOnMoveToTargetFinished(Card targetCard)
	{
		targetCard.SetDoNotSort(on: false);
		Zone zone = targetCard.GetZone();
		if (zone == null)
		{
			zone = targetCard.GetPrevZone();
			if (!targetCard.GetEntity().IsHero())
			{
				Log.Spells.PrintWarning("AttackSpellController.UpdateTargetOnMoveToTargetFinished() - Non-hero target ({0}) was moved from {1} to SETASIDE before the attack was resolved.", targetCard.name, zone.name);
			}
		}
		zone.UpdateLayout();
	}

	private void OnMoveToTargetFinished()
	{
		Card source = GetSource();
		Entity entity = source.GetEntity();
		Card target = GetTarget();
		bool flag = m_attackType == AttackType.PROPOSED;
		DoTasks(source, target);
		if (!flag)
		{
			ActivateImpactEffects(source, target);
		}
		if (entity.IsHero())
		{
			MoveSourceHeroBack(source);
			OrientSourceHeroBack(source);
			UpdateTargetOnMoveToTargetFinished(target);
			if (HasFinishAttackSpellOnDamage())
			{
				FinishHeroAttack();
			}
			return;
		}
		if (flag)
		{
			FinishEverything();
			return;
		}
		source.SetDoNotSort(on: false);
		source.GetZone().UpdateLayout();
		UpdateTargetOnMoveToTargetFinished(target);
		if (HasFinishAttackSpellOnDamage())
		{
			FinishAttackSpellController();
		}
		else
		{
			m_sourceAttackSpell.AddStateFinishedCallback(OnMinionSourceAttackStateFinished);
		}
		m_sourceAttackSpell.ActivateState(SpellStateType.DEATH);
	}

	private void DoTasks(Card sourceCard, Card targetCard)
	{
		GameUtils.DoDamageTasks(m_taskList, sourceCard, targetCard);
	}

	private void MoveSourceHeroBack(Card sourceCard)
	{
		Hashtable args = iTween.Hash("position", m_sourcePos, "time", m_HeroInfo.m_MoveBackDuration, "easetype", m_HeroInfo.m_MoveBackEaseType, "oncomplete", "OnHeroMoveBackFinished", "oncompletetarget", base.gameObject);
		iTween.MoveTo(sourceCard.gameObject, args);
	}

	private void OrientSourceHeroBack(Card sourceCard)
	{
		Quaternion quaternion = Quaternion.LookRotation(m_sourceFacing);
		Hashtable args = iTween.Hash("rotation", quaternion.eulerAngles, "time", m_HeroInfo.m_OrientBackDuration, "easetype", m_HeroInfo.m_OrientBackEaseType);
		iTween.RotateTo(sourceCard.gameObject, args);
	}

	private void OnHeroMoveBackFinished()
	{
		Card source = GetSource();
		Entity entity = source.GetEntity();
		source.SetDoNotSort(on: false);
		source.EnableAttacking(enable: false);
		if (!HasFinishAttackSpellOnDamage())
		{
			if (entity.GetController().IsLocalUser() || m_sourceAttackSpell.GetActiveState() == SpellStateType.NONE)
			{
				FinishHeroAttack();
			}
			else
			{
				m_sourceAttackSpell.AddStateFinishedCallback(OnHeroSourceAttackStateFinished);
			}
		}
	}

	private void OnHeroSourceAttackStateFinished(Spell spell, SpellStateType prevStateType, object userData)
	{
		if (spell.GetActiveState() == SpellStateType.NONE)
		{
			spell.RemoveStateFinishedCallback(OnHeroSourceAttackStateFinished);
			FinishHeroAttack();
		}
	}

	private void FinishHeroAttack()
	{
		Card source = GetSource();
		Entity entity = source.GetEntity();
		PlayWindfuryReminderIfPossible(entity, source);
		FinishEverything();
	}

	private IEnumerator EnsureFinisherCompletes(Spell spell)
	{
		yield return MAX_FINISHER_DURATION;
		m_finisherTrackingCoroutine = null;
		Log.Spells.PrintError("Finisher spell " + spell.gameObject.name + " did not terminate and was killed to prevent game hang. Run the finisher in the authoring scene to diagnose potential problems.");
		spell.ReleaseSpell();
	}

	private void OnBattlegroundsFinisherFinished(Spell spell, object favoriteFinisherRecordObject)
	{
		if (m_finisherTrackingCoroutine != null)
		{
			StopCoroutine(m_finisherTrackingCoroutine);
			m_finisherTrackingCoroutine = null;
		}
		Card source = GetSource();
		Card target = GetTarget();
		bool showImpactEffects = ((FinisherGameplaySettings)favoriteFinisherRecordObject).ShowImpactEffects;
		ActivateSpellDeathState();
		OnFinishedTaskList();
		if (showImpactEffects)
		{
			ActivateImpactEffects(source, target);
		}
		spell.RemoveAllTargets();
		BaconBoard baconBoard = BaconBoard.Get();
		if (baconBoard != null)
		{
			baconBoard.FriendlyPlayerFinisherCalled();
		}
		StartCoroutine(WaitThenDestroySpellAndFinish());
	}

	private void ActivateSpellDeathState()
	{
		Card source = GetSource();
		if (source != null && !source.ShouldShowImmuneVisuals() && (source.GetEntity() == null || !source.GetEntity().HasTag(GAME_TAG.IMMUNE_WHILE_ATTACKING) || m_attackType != AttackType.PROPOSED))
		{
			source.GetActor().ActivateSpellDeathState(SpellType.IMMUNE);
		}
	}

	private IEnumerator WaitThenDestroySpellAndFinish()
	{
		yield return new WaitForSeconds(10f);
		SpellUtils.PurgeSpell(m_sourceAttackSpell);
		OnFinished();
	}

	private void OnMinionSourceAttackStateFinished(Spell spell, SpellStateType prevStateType, object userData)
	{
		if (spell.GetActiveState() == SpellStateType.NONE)
		{
			spell.RemoveStateFinishedCallback(OnMinionSourceAttackStateFinished);
			FinishAttackSpellController();
		}
	}

	private void FinishAttackSpellController()
	{
		Card source = GetSource();
		Entity entity = source.GetEntity();
		source.EnableAttacking(enable: false);
		if (!CanPlayWindfuryReminder(entity, source))
		{
			FinishEverything();
			return;
		}
		OnFinishedTaskList();
		StartCoroutine(WaitThenPlayWindfuryReminder(entity, source));
	}

	private void FinishEverything()
	{
		ActivateSpellDeathState();
		OnFinishedTaskList();
		OnFinished();
	}

	private IEnumerator WaitThenPlayWindfuryReminder(Entity entity, Card card)
	{
		yield return new WaitForSeconds(1.2f);
		PlayWindfuryReminderIfPossible(entity, card);
		OnFinished();
	}

	private bool CanPlayWindfuryReminder(Entity entity, Card card)
	{
		if (!entity.HasWindfury())
		{
			return false;
		}
		if (entity.IsExhausted())
		{
			return false;
		}
		if (entity.GetZone() != TAG_ZONE.PLAY)
		{
			return false;
		}
		if (!entity.GetController().IsCurrentPlayer())
		{
			return false;
		}
		if (card.GetActorSpell(SpellType.WINDFURY_BURST) == null)
		{
			return false;
		}
		return true;
	}

	private void PlayWindfuryReminderIfPossible(Entity entity, Card card)
	{
		if (CanPlayWindfuryReminder(entity, card))
		{
			card.ActivateActorSpell(SpellType.WINDFURY_BURST);
		}
	}

	private void MoveSourceToTarget(Card sourceCard, Entity sourceEntity, Vector3 impactPos)
	{
		Vector3 vector = ComputeImpactOffset(sourceCard, impactPos);
		Vector3 vector2 = impactPos + vector;
		float num = 0f;
		iTween.EaseType easeType = iTween.EaseType.linear;
		if (sourceEntity.IsHero())
		{
			num = m_HeroInfo.m_MoveToTargetDuration;
			easeType = m_HeroInfo.m_MoveToTargetEaseType;
		}
		else
		{
			num = m_AllyInfo.m_MoveToTargetDuration;
			easeType = m_AllyInfo.m_MoveToTargetEaseType;
		}
		Hashtable args = iTween.Hash("position", vector2, "time", num, "easetype", easeType, "oncomplete", "OnMoveToTargetFinished", "oncompletetarget", base.gameObject);
		iTween.MoveTo(sourceCard.gameObject, args);
	}

	private void OrientSourceHeroToTarget(Card sourceCard)
	{
		m_sourceFacing = sourceCard.transform.forward;
		Quaternion quaternion = ((m_sourceAttackSpell.GetSpellType() != SpellType.OPPONENT_ATTACK) ? Quaternion.LookRotation(m_sourceToTarget) : Quaternion.LookRotation(-m_sourceToTarget));
		Hashtable args = iTween.Hash("rotation", quaternion.eulerAngles, "time", m_HeroInfo.m_OrientToTargetDuration, "easetype", m_HeroInfo.m_OrientToTargetEaseType);
		iTween.RotateTo(sourceCard.gameObject, args);
	}

	private void MoveTargetToSource(Card targetCard, Entity sourceEntity, Vector3 impactPos)
	{
		float num = 0f;
		iTween.EaseType easeType = iTween.EaseType.linear;
		if (sourceEntity.IsHero())
		{
			num = m_HeroInfo.m_MoveToTargetDuration;
			easeType = m_HeroInfo.m_MoveToTargetEaseType;
		}
		else
		{
			num = m_AllyInfo.m_MoveToTargetDuration;
			easeType = m_AllyInfo.m_MoveToTargetEaseType;
		}
		Hashtable args = iTween.Hash("position", impactPos, "time", num, "easetype", easeType);
		iTween.MoveTo(targetCard.gameObject, args);
	}

	private Vector3 ComputeImpactPos()
	{
		float num = 1f;
		if (m_attackType == AttackType.PROPOSED)
		{
			num = 0.5f;
		}
		Vector3 vector = num * m_ImpactStagingPoint * m_sourceToTarget;
		return m_sourcePos + vector;
	}

	private Vector3 ComputeImpactOffset(Card sourceCard, Vector3 impactPos)
	{
		if (Mathf.Approximately(m_SourceImpactOffset, 0.5f))
		{
			return Vector3.zero;
		}
		if (sourceCard.GetActor().GetMeshRenderer() == null)
		{
			return Vector3.zero;
		}
		Bounds bounds = sourceCard.GetActor().GetMeshRenderer().bounds;
		bounds.center = m_sourcePos;
		Ray ray = new Ray(impactPos, bounds.center - impactPos);
		if (!bounds.IntersectRay(ray, out var distance))
		{
			return Vector3.zero;
		}
		Vector3 vector = ray.origin + distance * ray.direction;
		Vector3 vector2 = 2f * bounds.center - vector - vector;
		return 0.5f * vector2 - m_SourceImpactOffset * vector2;
	}

	private void ActivateImpactEffects(Card sourceCard, Card targetCard)
	{
		string text = DetermineImpactSpellPrefab(sourceCard, targetCard);
		if (!string.IsNullOrEmpty(text))
		{
			Spell spell = SpellManager.Get().GetSpell(text);
			spell.transform.parent = null;
			spell.SetSource(sourceCard.gameObject);
			spell.AddTarget(targetCard.gameObject);
			Vector3 position = targetCard.transform.position;
			spell.SetPosition(position);
			Quaternion orientation = Quaternion.LookRotation(m_sourceToTarget);
			spell.SetOrientation(orientation);
			spell.AddStateFinishedCallback(OnImpactSpellStateFinished);
			spell.Activate();
			BaconBoard baconBoard = BaconBoard.Get();
			if (baconBoard != null)
			{
				baconBoard.CheckForHeroHeavyHitBoardEffects(sourceCard, targetCard);
			}
		}
	}

	private string DetermineImpactSpellPrefab(Card sourceCard, Card targetCard)
	{
		int aTK = sourceCard.GetEntity().GetATK();
		SpellHandleValueRange appropriateElementAccordingToRanges = SpellUtils.GetAppropriateElementAccordingToRanges((WasAttackCriticalHit(sourceCard, targetCard) && m_CriticalImpactDefHandles != null && m_CriticalImpactDefHandles.Length != 0) ? m_CriticalImpactDefHandles : m_ImpactDefHandles, (SpellHandleValueRange x) => x.m_range, aTK);
		if (appropriateElementAccordingToRanges != null && !string.IsNullOrEmpty(appropriateElementAccordingToRanges.m_spellPrefabName))
		{
			return appropriateElementAccordingToRanges.m_spellPrefabName;
		}
		return m_DefaultImpactSpellPrefabHandle;
	}

	private bool WasAttackCriticalHit(Card sourceCard, Card targetCard)
	{
		bool result = false;
		if (sourceCard == null || targetCard == null)
		{
			return result;
		}
		Player.Side controllerSide = sourceCard.GetControllerSide();
		Player.Side controllerSide2 = targetCard.GetControllerSide();
		if (controllerSide != 0 && controllerSide2 != 0)
		{
			result = controllerSide != controllerSide2 && sourceCard.GetEntity().IsLettuceMercenary() && sourceCard.GetEntity().IsMyLettuceRoleStrongAgainst(targetCard.GetEntity());
		}
		return result;
	}

	private void OnImpactSpellStateFinished(Spell spell, SpellStateType prevStateType, object userData)
	{
		if (spell.GetActiveState() == SpellStateType.NONE)
		{
			SpellManager.Get().ReleaseSpell(spell);
		}
	}

	protected override float GetLostFrameTimeCatchUpSeconds()
	{
		Card source = GetSource();
		if (source != null && source.GetEntity() != null && source.GetEntity().IsHero())
		{
			return 0f;
		}
		Card target = GetTarget();
		if (target != null && target.GetEntity() != null && target.GetEntity().IsHero())
		{
			return 0f;
		}
		return 0.8f;
	}

	protected override void OnFinishedTaskList()
	{
		if (m_attackType != AttackType.PROPOSED)
		{
			Card source = GetSource();
			source.SetDoNotSort(on: false);
			if (!source.GetEntity().IsHero())
			{
				Zone zone = source.GetZone();
				if (zone != null)
				{
					zone.UpdateLayout();
					if (m_sourceAttackSpell == null)
					{
						bool isSourceFriendly = zone.m_Side == Player.Side.FRIENDLY;
						m_sourceAttackSpell = GetSourceAttackSpell(source, isSourceFriendly);
					}
				}
				if (m_sourceAttackSpell != null && (m_sourceAttackSpell.GetActiveState() == SpellStateType.BIRTH || m_sourceAttackSpell.GetActiveState() == SpellStateType.IDLE || m_sourceAttackSpell.GetActiveState() == SpellStateType.ACTION))
				{
					CancelAttackSpell(source.GetEntity(), m_sourceAttackSpell);
				}
			}
		}
		base.OnFinishedTaskList();
	}

	private void CancelAttackSpell(Entity sourceEntity, Spell attackSpell)
	{
		if (!(attackSpell == null))
		{
			if (sourceEntity == null)
			{
				attackSpell.ActivateState(SpellStateType.DEATH);
			}
			else if (sourceEntity.IsHero())
			{
				attackSpell.ActivateState(SpellStateType.CANCEL);
			}
			else
			{
				attackSpell.ActivateState(SpellStateType.DEATH);
			}
		}
	}

	private Spell GetSourceAttackSpell(Card sourceCard, bool isSourceFriendly)
	{
		if (GameState.Get().GetGameEntity().HasTag(GAME_TAG.HIGHLIGHT_ATTACKING_MINION_DURING_COMBAT))
		{
			Spell actorSpell = sourceCard.GetActorSpell(SpellType.AUTO_ATTACK_WITH_HIGHLIGHT);
			if (actorSpell != null)
			{
				return actorSpell;
			}
			return null;
		}
		if (isSourceFriendly)
		{
			return sourceCard.GetActorSpell(SpellType.FRIENDLY_ATTACK);
		}
		return sourceCard.GetActorSpell(SpellType.OPPONENT_ATTACK);
	}

	private Spell InstantiateFinisherSpell(GameObject sourceObject, string spellPrefabName)
	{
		if (string.IsNullOrEmpty(spellPrefabName))
		{
			return null;
		}
		Spell spell = SpellManager.Get().GetSpell(spellPrefabName);
		if (spell == null)
		{
			return null;
		}
		TransformUtil.AttachAndPreserveLocalTransform(spell.transform, sourceObject.transform);
		return spell;
	}

	private string GetSpellPath(Entity sourceEntity, Entity targetEntity, bool opponentFinisher, FinisherGameplaySettings finisherSettings)
	{
		if (sourceEntity.GetATK() >= targetEntity.GetCurrentDefense())
		{
			if (GameState.Get().CountPlayersAlive() == 1)
			{
				if (opponentFinisher && !string.IsNullOrEmpty(finisherSettings.FirstPlaceVictoryOpponentPrefab))
				{
					return finisherSettings.FirstPlaceVictoryOpponentPrefab;
				}
				if (!string.IsNullOrEmpty(finisherSettings.FirstPlaceVictoryPrefab))
				{
					return finisherSettings.FirstPlaceVictoryPrefab;
				}
			}
			if (opponentFinisher && !string.IsNullOrEmpty(finisherSettings.LethalOpponentPrefab))
			{
				return finisherSettings.LethalOpponentPrefab;
			}
			if (!string.IsNullOrEmpty(finisherSettings.LethalPrefab))
			{
				return finisherSettings.LethalPrefab;
			}
		}
		if (sourceEntity.GetATK() >= 15)
		{
			if (opponentFinisher)
			{
				if (string.IsNullOrEmpty(finisherSettings.LargeOpponentPrefab))
				{
					return finisherSettings.SmallOpponentPrefab;
				}
				return finisherSettings.LargeOpponentPrefab;
			}
			if (string.IsNullOrEmpty(finisherSettings.LargePrefab))
			{
				return finisherSettings.SmallPrefab;
			}
			return finisherSettings.LargePrefab;
		}
		if (opponentFinisher)
		{
			return finisherSettings.SmallOpponentPrefab;
		}
		return finisherSettings.SmallPrefab;
	}
}
