using System.Collections.Generic;
using UnityEngine;

public class BattlegroundsSeasonDbfAsset : ScriptableObject
{
	public List<BattlegroundsSeasonDbfRecord> Records = new List<BattlegroundsSeasonDbfRecord>();
}
