using System.Collections;
using Blizzard.T5.AssetManager;
using UnityEngine;

public class BaconCosmeticPreviewManager : MonoBehaviour
{
	private class BoardSkin
	{
		public GameObject m_CombatPrefab;

		public GameObject m_TavernPrefab;

		public AssetHandle<GameObject> m_AssetHandleCombat;

		public AssetHandle<GameObject> m_AssetHandleTavern;

		public BaconBoardSkinBehaviour m_CombatInstance;

		public BaconBoardSkinBehaviour m_TavernInstance;
	}

	public GameObject m_root;

	public GameObject m_boardBase;

	public GameObject m_boardBasePhone;

	public UberText m_displayText;

	public GameObject m_friendlyHeroHolder;

	public GameObject m_opposingHeroHolder;

	public Actor m_friendlyHeroActor;

	public Actor m_opposingHeroActor;

	private BoardSkin m_boardSkin = new BoardSkin();

	private FinisherGameplaySettings m_strikeSettings;

	private int m_pendingLoads;

	private BaconCosmeticPreviewRunnerConfig m_config;

	private int m_currentAction;

	private int m_blockingActionFunctionsInProgress;

	private SpellHandleValueRange[] m_ImpactDefs;

	private string m_DefaultImpactSpellPrefab;

	private const string ATTACK_SPELL_CONTROLLER_PREFAB_PATH = "AttackSpellController_Battlegrounds_Hero.prefab:922da2c91f4cca1458b5901204d1d26c";

	private const string DEFAULT_SHATTER_SPELL = "Bacon_EndRound_HeroImpact.prefab:34d052b6989dcea4c8b7d22adcb31368";

	public void Start()
	{
		AttackSpellController component = AssetLoader.Get().InstantiatePrefab("AttackSpellController_Battlegrounds_Hero.prefab:922da2c91f4cca1458b5901204d1d26c").GetComponent<AttackSpellController>();
		m_ImpactDefs = component.m_ImpactDefHandles;
		m_DefaultImpactSpellPrefab = component.m_DefaultImpactSpellPrefabHandle;
	}

	private void Awake()
	{
		m_displayText.Hide();
		m_config = BaconCosmeticPreviewLoadInfo.s_runnerConfig;
		LoadStrikeSettings(m_config.strikeId);
		LoadBoardSkin(m_config.boardId);
		LoadHero(m_config.friendlyHeroCardId, Player.Side.FRIENDLY);
		LoadHero(m_config.opposingHeroCardId, Player.Side.OPPOSING);
	}

	private void LoadHero(string heroId, Player.Side side)
	{
		if (string.IsNullOrEmpty(heroId))
		{
			if (side == Player.Side.FRIENDLY)
			{
				m_friendlyHeroActor.gameObject.SetActive(value: false);
			}
			else
			{
				m_opposingHeroActor.gameObject.SetActive(value: false);
			}
		}
		else
		{
			m_pendingLoads++;
			DefLoader.Get().LoadFullDef(heroId, OnHeroLoaded, side);
		}
	}

	private void LoadStrikeSettings(int id)
	{
		BattlegroundsFinisherDbfRecord record = GameDbf.BattlegroundsFinisher.GetRecord(id);
		if (record != null)
		{
			AssetReference assetReference = AssetReference.CreateFromAssetString(record.GameplaySettings);
			if (assetReference != null)
			{
				m_pendingLoads++;
				AssetLoader.Get().LoadAsset<FinisherGameplaySettings>(assetReference, OnStrikeLoaded);
			}
		}
	}

	private void LoadBoardSkin(int id)
	{
		BattlegroundsBoardSkinDbfRecord record = GameDbf.BattlegroundsBoardSkin.GetRecord(id);
		if (record == null)
		{
			record = GameDbf.BattlegroundsBoardSkin.GetRecord(1);
		}
		string text;
		string text2;
		if (PlatformSettings.Screen == ScreenCategory.Phone)
		{
			text = record.FullBoardPrefabPhone;
			text2 = record.FullTavernBoardPrefabPhone;
		}
		else
		{
			text = record.FullBoardPrefab;
			text2 = record.FullTavernBoardPrefab;
		}
		m_pendingLoads += 2;
		AssetLoader.Get().LoadAsset<GameObject>(text, OnSkinLoaded, TAG_BOARD_VISUAL_STATE.COMBAT);
		AssetLoader.Get().LoadAsset<GameObject>(text2, OnSkinLoaded, TAG_BOARD_VISUAL_STATE.SHOP);
	}

	private void OnSkinLoaded(AssetReference assetRef, AssetHandle<GameObject> asset, object callbackData)
	{
		m_pendingLoads--;
		switch ((TAG_BOARD_VISUAL_STATE)callbackData)
		{
		case TAG_BOARD_VISUAL_STATE.COMBAT:
		{
			m_boardSkin.m_AssetHandleCombat = asset;
			m_boardSkin.m_CombatPrefab = asset.Asset;
			GameObject gameObject2 = Object.Instantiate(m_boardSkin.m_CombatPrefab, m_root.transform);
			if (!gameObject2.TryGetComponent<BaconBoardSkinBehaviour>(out m_boardSkin.m_CombatInstance))
			{
				Debug.LogError("Attempting to get component BaconBoardSkinBehaviour but not found on " + gameObject2);
				return;
			}
			m_boardSkin.m_CombatInstance.SetBoardState(m_config.initialState);
			break;
		}
		case TAG_BOARD_VISUAL_STATE.SHOP:
		{
			m_boardSkin.m_AssetHandleTavern = asset;
			m_boardSkin.m_TavernPrefab = asset.Asset;
			GameObject gameObject = Object.Instantiate(m_boardSkin.m_TavernPrefab, m_root.transform);
			if (!gameObject.TryGetComponent<BaconBoardSkinBehaviour>(out m_boardSkin.m_TavernInstance))
			{
				Debug.LogError("Attempting to get component BaconBoardSkinBehaviour but not found on " + gameObject);
				return;
			}
			m_boardSkin.m_TavernInstance.SetBoardState(m_config.initialState);
			break;
		}
		}
		if (m_pendingLoads == 0)
		{
			StartRunning();
		}
	}

	private void OnHeroLoaded(string cardId, DefLoader.DisposableFullDef fullDef, object callbackData)
	{
		m_pendingLoads--;
		if ((Player.Side)callbackData == Player.Side.FRIENDLY)
		{
			m_friendlyHeroActor.SetCardDef(fullDef.DisposableCardDef);
			m_friendlyHeroActor.UpdateAllComponents();
		}
		else
		{
			m_opposingHeroActor.SetCardDef(fullDef.DisposableCardDef);
			m_opposingHeroActor.UpdateAllComponents();
		}
		if (m_pendingLoads == 0)
		{
			StartRunning();
		}
	}

	private void OnStrikeLoaded(AssetReference assetRef, AssetHandle<FinisherGameplaySettings> asset, object callbackData)
	{
		m_pendingLoads--;
		m_strikeSettings = asset.Asset;
		if (m_pendingLoads == 0)
		{
			StartRunning();
		}
	}

	private void StartRunning()
	{
		StartCoroutine(RunPreview());
	}

	private IEnumerator RunPreview()
	{
		BaconCosmeticPreviewAction action = m_config.actions[m_currentAction];
		yield return new WaitForSeconds(action.delay);
		if (string.IsNullOrEmpty(action.displayText))
		{
			m_displayText.Hide();
		}
		else
		{
			m_displayText.Show();
			m_displayText.Text = action.displayText;
		}
		switch (action.actionType)
		{
		case BaconCosmeticPreviewActionType.SWAP_BOARD_STATE:
			m_boardBase.GetComponentInChildren<BaconBoard>().ChangeBoardVisualStateForPreview(action.boardState, m_boardSkin.m_CombatInstance, m_boardSkin.m_TavernInstance);
			break;
		case BaconCosmeticPreviewActionType.TRIGGER_FSM_EVENT:
			if (action.boardState == TAG_BOARD_VISUAL_STATE.COMBAT)
			{
				m_boardSkin.m_CombatInstance.DebugTriggerFSMState(action.fsmParameter);
			}
			else
			{
				m_boardSkin.m_TavernInstance.DebugTriggerFSMState(action.fsmParameter);
			}
			break;
		case BaconCosmeticPreviewActionType.LAUNCH_STRIKE:
			m_blockingActionFunctionsInProgress++;
			LoadAndLaunchStrike(action);
			break;
		}
		yield return new WaitForSeconds(action.duration);
		m_currentAction = (m_currentAction + 1) % m_config.actions.Count;
		yield return RunPreview();
	}

	private void LoadAndLaunchStrike(BaconCosmeticPreviewAction action)
	{
		string text = ((action.strikeLethalLevel == KeyboardFinisherSettings.LethalLevel.Lethal && !string.IsNullOrEmpty(m_strikeSettings.LethalPrefab)) ? m_strikeSettings.LethalPrefab : ((action.strikeLethalLevel == KeyboardFinisherSettings.LethalLevel.FirstPlaceVictory && !string.IsNullOrEmpty(m_strikeSettings.FirstPlaceVictoryPrefab)) ? m_strikeSettings.FirstPlaceVictoryPrefab : ((action.strikeDamageLevel != 0) ? m_strikeSettings.LargePrefab : m_strikeSettings.SmallPrefab)));
		if (string.IsNullOrEmpty(text))
		{
			Log.CosmeticPreview.PrintError(string.Concat("Tried to play an empty finisher spell prefab for finisher ", m_strikeSettings.name, ": ", action.strikeDamageLevel, ", ", action.strikeLethalLevel));
			m_blockingActionFunctionsInProgress--;
		}
		else
		{
			AssetLoader.Get().LoadAsset<GameObject>(text, OnFinisherSpellLoaded, action);
		}
	}

	private void OnFinisherSpellLoaded(AssetReference assetRef, AssetHandle<GameObject> asset, object callbackData)
	{
		BaconCosmeticPreviewAction baconCosmeticPreviewAction = (BaconCosmeticPreviewAction)callbackData;
		Spell component = Object.Instantiate(asset.Asset).GetComponent<Spell>();
		component.SetSource(m_friendlyHeroHolder);
		component.AddTarget(m_opposingHeroHolder);
		component.transform.parent = m_friendlyHeroHolder.transform;
		component.AddFinishedCallback(OnFinisherFinished, baconCosmeticPreviewAction);
		if (baconCosmeticPreviewAction.strikeLethalLevel != 0)
		{
			m_blockingActionFunctionsInProgress++;
			component.AddFinishedCallback(DestroyOpposingPlayerHero, baconCosmeticPreviewAction);
		}
		SuperSpell superSpell = component as SuperSpell;
		if (superSpell == null)
		{
			component.Activate();
		}
		else
		{
			superSpell.ActivateFinisher();
		}
	}

	private void DestroyOpposingPlayerHero(Spell spell, object callbackData)
	{
		string text = ((((BaconCosmeticPreviewAction)callbackData).strikeLethalLevel != KeyboardFinisherSettings.LethalLevel.FirstPlaceVictory || string.IsNullOrEmpty(m_strikeSettings.FirstPlaceVictoryDestroyOpponentPrefab)) ? m_strikeSettings.DestroyOpponentPrefab : m_strikeSettings.FirstPlaceVictoryDestroyOpponentPrefab);
		Spell spell2 = (string.IsNullOrEmpty(text) ? SpellManager.Get().GetSpell("Bacon_EndRound_HeroImpact.prefab:34d052b6989dcea4c8b7d22adcb31368") : SpellManager.Get().GetSpell(text));
		spell2.AddFinishedCallback(OnFinishedCallback);
		spell2.SetSource(m_opposingHeroHolder);
		spell2.AddTarget(m_friendlyHeroHolder);
		spell2.transform.parent = m_opposingHeroHolder.transform;
		spell2.Activate();
	}

	private void OnFinisherFinished(Spell spell, object userData)
	{
		ActivateImpactEffects(spell, (BaconCosmeticPreviewAction)userData);
	}

	private void OnFinished(Spell spell)
	{
		m_blockingActionFunctionsInProgress--;
		if (spell != null)
		{
			Object.Destroy(spell, 5f);
		}
	}

	private void OnFinishedCallback(Spell spell, object userData)
	{
		OnFinished(spell);
	}

	private void ActivateImpactEffects(Spell spell, BaconCosmeticPreviewAction action)
	{
		m_blockingActionFunctionsInProgress++;
		if (!m_strikeSettings.ShowImpactEffects)
		{
			OnFinished(spell);
			return;
		}
		string text = DetermineImpactSpellPrefab(action.strikeImpactDamage);
		if (string.IsNullOrEmpty(text))
		{
			OnFinished(spell);
			return;
		}
		Spell spell2 = SpellManager.Get().GetSpell(text);
		spell2.SetSource(m_friendlyHeroHolder);
		spell2.AddTarget(m_opposingHeroHolder);
		Vector3 position = m_opposingHeroHolder.transform.position;
		spell2.SetPosition(position);
		Quaternion orientation = Quaternion.LookRotation(position - m_friendlyHeroHolder.transform.position);
		spell2.SetOrientation(orientation);
		spell2.AddStateFinishedCallback(OnImpactSpellStateFinished, spell);
		spell2.Activate();
	}

	private string DetermineImpactSpellPrefab(int impactDamage)
	{
		SpellHandleValueRange appropriateElementAccordingToRanges = SpellUtils.GetAppropriateElementAccordingToRanges(m_ImpactDefs, (SpellHandleValueRange x) => x.m_range, impactDamage);
		if (appropriateElementAccordingToRanges != null && !string.IsNullOrEmpty(appropriateElementAccordingToRanges.m_spellPrefabName))
		{
			return appropriateElementAccordingToRanges.m_spellPrefabName;
		}
		return m_DefaultImpactSpellPrefab;
	}

	private void OnImpactSpellStateFinished(Spell spell, SpellStateType prevStateType, object userData)
	{
		OnFinished((Spell)userData);
		OnFinished(spell);
	}

	public void OnDestroy()
	{
		StopAllCoroutines();
	}
}
